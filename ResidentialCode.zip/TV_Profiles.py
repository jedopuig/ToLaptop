import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# =========================
# PART 1 — DAILY PROFILE
# =========================

time_labels = [
    "00:00-00:30", "01:00-01:29", "02:00-02:29", "03:00-03:29", "04:00-04:29", "05:00-05:29",
    "06:00-06:29", "07:00-07:29", "08:00-08:29", "09:00-09:29",
    "10:00-10:29", "11:00-11:29", "12:00-12:29", "13:00-13:29",
    "14:00-14:29", "15:00-15:29", "16:00-16:29", "17:00-17:29",
    "18:00-18:29", "19:00-19:29", "20:00-20:29", "21:00-21:29",
    "22:00-22:29", "23:00-23:29"
]

kdh_2022 = [
    10.0, 4.0, 2.4, 2.1, 1.8, 1.9,
    2.3, 3.0, 4.0, 4.2,
    4.5, 4.7, 5.0, 5.2,
    5.5, 6.0, 7.0, 9.0,
    14.0, 20.0, 28.0, 37.0,
    33.0, 20.0
]

kdh = np.array(kdh_2022)
dx = 0.5

slot_labels = ["00:00–06:00", "06:00–12:00", "12:00–18:00", "18:00–24:00"]
slot_ranges = [(0, 6), (6, 12), (12, 18), (18, 24)]

avg_values = []

for (start, end) in slot_ranges:
    segment = kdh[start:end]
    integral = np.trapezoid(segment, dx=dx)
    duration = (end - start) * dx
    avg = integral / duration
    avg_values.append(avg)

# ---- PRINT DAILY SLOT AVERAGES ----
print("\nAverage viewing density (KDH) per time block:\n")
for label, value in zip(slot_labels, avg_values):
    print(f"{label:>13}: {value:6.2f}")

# =========================
# PART 2 — PLOTS
# =========================

plt.figure(figsize=(12, 6))
plt.plot(time_labels, kdh, linewidth=3, color='#005DAA', label='2022')
plt.xlabel("Time of Day (half-hour blocks)")
plt.ylabel("Kijkdichtheid (KDH)")
plt.title("Kijkdichtheid per half uur – 2022")
plt.xticks(rotation=65, ha="right")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.legend()
plt.show()

plt.figure(figsize=(8, 5))
bars = plt.bar(slot_labels, avg_values)
plt.ylabel("Average KDH")
plt.title("Average Viewing Density per Time Block")
plt.grid(axis='y', alpha=0.3)

for bar, val in zip(bars, avg_values):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height(),
             f"{val:.1f}", ha='center', va='bottom')

plt.show()

# =========================
# PART 3 — MONTHLY MODEL
# =========================

months = [
    "January","February","March","April","May","June",
    "July","August","September","October","November","December"
]

daily_avg = [9.3, 9.0, 8.5, 7.9, 7.8, 7.3, 7.5, 7.2, 8.0, 8.4, 8.8, 9.0]
evening_avg = [25, 24.5, 23.3, 21.7, 21.1, 19.1, 18.6, 18.6, 21.4, 23.2, 24, 23.4]

# Use computed proportions
p_00_06, p_06_12, p_12_18, _ = avg_values
sum_first3 = p_00_06 + p_06_12 + p_12_18

prop_00_06 = p_00_06 / sum_first3
prop_06_12 = p_06_12 / sum_first3
prop_12_18 = p_12_18 / sum_first3

rows = []

for m, d_avg, eve in zip(months, daily_avg, evening_avg):
    k = (4 * d_avg - eve)

    slot_00_06 = k * prop_00_06
    slot_06_12 = k * prop_06_12
    slot_12_18 = k * prop_12_18
    slot_18_24 = eve

    rows.append([m, d_avg, slot_00_06, slot_06_12, slot_12_18, slot_18_24])

# Include DAILY AVERAGE in dataframe
df = pd.DataFrame(rows, columns=[
    "Month", "Daily Avg", "00–06", "06–12", "12–18", "18–24"
])

# ---- PRINT MONTHLY RESULTS ----
print("\nMonthly viewing density (including daily averages):\n")
print(df)

# ---- OPTIONAL: print nicely formatted ----
print("\nDetailed monthly overview:\n")
for _, row in df.iterrows():
    print(f"{row['Month']:>9} | Daily Avg: {row['Daily Avg']:4.1f} | "
          f"00–06: {row['00–06']:5.2f} | "
          f"06–12: {row['06–12']:5.2f} | "
          f"12–18: {row['12–18']:5.2f} | "
          f"18–24: {row['18–24']:5.2f}")