import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# =========================
# LaTeX-like font WITHOUT usetex
# =========================

mpl.rcParams.update({
    "text.usetex": True,
    "font.family": "serif",
    "font.serif": ["Computer Modern Roman"],
    "axes.labelsize": 12,
    "axes.titlesize": 14,
    "legend.fontsize": 11,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
})


# =========================
# Data
# =========================
hours = np.arange(0, 24.5, 0.5)

june = np.array([
0.065,0.053,0.042,0.033,0.027,0.022,0.020,0.017,
0.016,0.016,0.016,0.015,0.016,0.020,0.027,0.031,
0.031,0.021,0.015,0.013,0.013,0.013,0.012,0.012,
0.012,0.012,0.013,0.013,0.013,0.013,0.014,0.015,
0.017,0.021,0.021,0.026,0.029,0.029,0.035,0.048,
0.075,0.115,0.144,0.118,0.093,0.068,0.045,0.035,0.028
])

september = np.array([
0.070,0.057,0.045,0.036,0.030,0.025,0.023,0.021,
0.022,0.024,0.026,0.028,0.031,0.045,0.067,0.066,
0.058,0.032,0.025,0.020,0.018,0.018,0.018,0.018,
0.018,0.018,0.018,0.018,0.018,0.018,0.018,0.022,
0.031,0.038,0.046,0.057,0.075,0.120,0.178,0.193,
0.193,0.193,0.172,0.138,0.105,0.078,0.050,0.040,0.032
])

december = np.array([
0.083,0.063,0.048,0.039,0.033,0.028,0.025,0.023,
0.022,0.021,0.023,0.026,0.032,0.055,0.115,0.162,
0.166,0.115,0.082,0.067,0.059,0.054,0.050,0.046,
0.044,0.045,0.044,0.042,0.046,0.053,0.067,0.106,
0.178,0.218,0.241,0.256,0.263,0.256,0.248,0.235,
0.223,0.212,0.193,0.152,0.118,0.088,0.055,0.043,0.035
])

march = np.array([
0.070,0.057,0.044,0.034,0.027,0.023,0.020,0.018,
0.017,0.017,0.018,0.021,0.028,0.045,0.065,0.062,
0.055,0.032,0.025,0.020,0.018,0.018,0.017,0.018,
0.019,0.020,0.021,0.020,0.020,0.019,0.019,0.023,
0.033,0.043,0.075,0.140,0.210,0.228,0.231,0.225,
0.223,0.208,0.185,0.148,0.112,0.083,0.052,0.041,0.033
])

# Normalize
divisor = 0.263
june /= divisor
september /= divisor
december /= divisor
march /= divisor

# =========================
# Plot
# =========================
plt.figure(figsize=(12, 6))

plt.plot(hours, june, '--', linewidth=2, marker='o', markersize=4,
         color='black', label='June')

plt.plot(hours, september, '-', linewidth=2, marker='s', markersize=4,
         color='gray', label='September')

plt.plot(hours, march, ':', linewidth=2, marker='^', markersize=4,
         color='black', label='March')

plt.plot(hours, december, '-', linewidth=2, marker='D', markersize=4,
         color='black', label='December')


plt.xlabel(r'\textbf{Time of Day}')
plt.ylabel(r'\textbf{Normalized Lighting Power Demand}')
plt.title(r'\textbf{Residential Lighting Demand Profiles for the UK}')


plt.xticks(
    ticks=np.arange(0, 25, 2),
    labels=[f'{h:02.0f}:00' for h in np.arange(0, 25, 2)],
    rotation=45,
    ha='right'
)

plt.grid(True, which='both', linewidth=0.4, color='gray', alpha=0.4)
plt.xlim(0, 24)
plt.ylim(bottom=0)

plt.legend(loc='upper left')
plt.tight_layout()
plt.show()
