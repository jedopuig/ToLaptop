import matplotlib.pyplot as plt
import numpy as np

# -----------------------------
# Raw hourly labels (extended to 01:00)
# -----------------------------
hours = [
    "06:00", "07:00", "08:00", "09:00", "10:00", "11:00", "12:00",
    "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00",
    "20:00", "21:00", "22:00", "23:00", "00:00", "01:00"
]

# Original start-time data
start_time_winter = np.array([2, 4, 5.5, 5.5, 4, 6, 5, 7.5, 3, 3.5, 2, 3, 11, 15, 15, 4, 2, 2, 0])
start_time_summer = np.array([0.5, 1.5, 7, 4, 5, 3, 4, 4.5, 6, 2, 4.25, 4.25, 8, 13, 16, 4, 6, 7, 0])

# Extend for 01:00
start_time_winter = np.append(start_time_winter, [0])
start_time_summer = np.append(start_time_summer, [0])

# -----------------------------
# Compute ON-time (2-hour duration)
# -----------------------------
on_time_winter = np.zeros(len(hours))
on_time_summer = np.zeros(len(hours))

for i in range(len(hours)):
    on_time_winter[i] = start_time_winter[i]
    on_time_summer[i] = start_time_summer[i]

    if i > 0:
        on_time_winter[i] += start_time_winter[i - 1]
        on_time_summer[i] += start_time_summer[i - 1]

# -----------------------------
# PRINT DATA POINTS
# -----------------------------
print("\nWinter points (x, y):")
for h, v in zip(hours, on_time_winter):
    print(f"{h}: {v:.2f}")

print("\nSummer points (x, y):")
for h, v in zip(hours, on_time_summer):
    print(f"{h}: {v:.2f}")

# -----------------------------
# BUILD FULL 24h PROFILE
# Missing hours = 0
# -----------------------------
full_hours = [f"{h:02d}:00" for h in range(24)]

winter_dict = {h: v for h, v in zip(hours, on_time_winter)}
summer_dict = {h: v for h, v in zip(hours, on_time_summer)}

winter_full = []
summer_full = []

for h in full_hours:
    winter_full.append(winter_dict.get(h, 0))
    summer_full.append(summer_dict.get(h, 0))

winter_full = np.array(winter_full)
summer_full = np.array(summer_full)

# -----------------------------
# DEFINE TIME SLOTS
# -----------------------------
slots = {
    "Overnight (00–06)": list(range(0, 6)),
    "Morning (06–12)": list(range(6, 12)),
    "Afternoon (12–18)": list(range(12, 18)),
    "Evening (18–00)": list(range(18, 24)),
}

# -----------------------------
# COMPUTE AVERAGES
# -----------------------------
print("\n=== AVERAGE VALUES PER TIME SLOT ===")

for name, idx in slots.items():
    w_avg = np.mean(winter_full[idx])
    s_avg = np.mean(summer_full[idx])

    print(f"{name}:")
    print(f"  Winter: {w_avg:.2f}")
    print(f"  Summer: {s_avg:.2f}")

# -----------------------------
# PLOT
# -----------------------------
plt.figure(figsize=(12, 5))

plt.step(hours, on_time_winter, where='post',
         linewidth=2, label='Winter')
plt.step(hours, on_time_summer, where='post',
         linewidth=2, label='Summer')
plt.xticks(rotation=45, ha='right')
plt.ylabel("Number ON (%)")
plt.xlabel("Hour of Day")
plt.title("Dishwasher – Estimated Number ON Over the Day (2h ON duration)")
plt.grid(True, linestyle='--', alpha=0.4)
plt.legend()
plt.tight_layout()
plt.show()