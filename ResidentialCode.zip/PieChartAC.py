import matplotlib.pyplot as plt
import numpy as np

# Fixed total and components
TOTAL = 1361
fixed_ac = 239
mobile_ac = 156
residential_ventilation = 690

# Calculate leftover (other uses)
other = TOTAL - (fixed_ac + mobile_ac + residential_ventilation)

values = [fixed_ac, mobile_ac, residential_ventilation, other]
labels = ["Fixed AC", "Mobile AC", "Residential Ventilation", "Other"]
colors = ["#4C78A8", "#F58518", "#7A5195", "#999999"]

# Precompute percentages for legend
perc = [v / TOTAL * 100 for v in values]
legend_labels = [f"{lbl}: {val} GWh ({p:.1f}%)" for lbl, val, p in zip(labels, values, perc)]

fig, ax = plt.subplots(figsize=(7, 7), dpi=160)

wedges, _ = ax.pie(
    values,
    labels=None,
    colors=colors,
    startangle=90,
    counterclock=False,
    wedgeprops=dict(width=0.45, edgecolor="white")
)

ax.set_title("Residential Ventilation & Cooling — Netherlands", fontsize=13, pad=14)

ax.text(0, -1.12, f"Total: {TOTAL} GWh (AC total: {fixed_ac + mobile_ac} GWh)",
        ha="center", va="center", fontsize=10, color="#555")

ax.set(aspect="equal")
for spine in ax.spines.values():
    spine.set_visible(False)
ax.set_xticks([])
ax.set_yticks([])

centre_circle = plt.Circle((0, 0), 0.55, fc="white")
fig.gca().add_artist(centre_circle)

ax.legend(
    wedges,
    legend_labels,
    loc="center left",
    bbox_to_anchor=(1.02, 0.5),
    frameon=False,
    fontsize=10
)

plt.tight_layout()
plt.savefig("ventilation_cooling_pie.png", bbox_inches="tight")
plt.show()
