
import numpy as np
import matplotlib.pyplot as plt

# ==================================================
# CLM components and base profiles (Spring/Fall)
# ==================================================
components = ["A", "B", "C", "D", "PE", "Z", "I"]

base_profiles = {
    "Overnight": np.array([0.0, 0.047884986, 0.0366065238, 0.3288868440,
                            0.1357191062, 0.4200157163, 0.0308868234]),
    "Morning":   np.array([0.0, 0.1071536578, 0.0237953606, 0.2106615792,
                            0.1117060670, 0.5366446453, 0.0100386902]),
    "Afternoon": np.array([0.0, 0.0685349437, 0.0215003742, 0.1950498491,
                            0.1561176585, 0.5043742311, 0.0544229435]),
    "Evening":   np.array([0.0, 0.0643194267, 0.0175237735, 0.1551388885,
                            0.2486640178, 0.4330324507, 0.0813214428]),
}

times = list(base_profiles.keys())

# ==================================================
# Helpers
# ==================================================
def adjust_and_normalize(base, scale_dict):
    v = base.copy()
    for comp, factor in scale_dict.items():
        idx = components.index(comp)
        v[idx] *= factor
    return v / v.sum()

# ==================================================
# Seasonal profiles
# ==================================================
spring_fall = {t: base_profiles[t] for t in times}
summer = {t: adjust_and_normalize(base_profiles[t], {"D": 1.20}) for t in times}
winter = {t: adjust_and_normalize(base_profiles[t], {"Z": 1.20, "D": 1.10}) for t in times}

# ==================================================
# Colors for CLM components
# ==================================================
colors = {
    "A":  "#dddddd",
    "B":  "#457b9d",
    "C":  "#2a9d8f",
    "D":  "#e76f51",
    "PE": "#f4a261",
    "Z":  "#6d9dc5",
    "I":  "#9e2a2b",
}

# ==================================================
# Plot layout
# ==================================================
fig, axes = plt.subplots(1, 3, figsize=(18, 6), constrained_layout=True)

# -----------------------------
# 1) Spring & Fall (base)
# -----------------------------
ax = axes[0]
bottom = np.zeros(len(times))

for i, comp in enumerate(components):
    vals = [spring_fall[t][i] for t in times]
    ax.bar(times, vals, bottom=bottom, color=colors[comp], label=comp)
    bottom += vals

ax.set_title("Spring & Fall (CLM Fractions)")
ax.set_ylim(0, 1)
ax.set_ylabel("CLM fraction")
ax.grid(True, axis="y", alpha=0.3)

# -----------------------------
# 2) Summer vs Winter (side-by-side with INNER separation)
# -----------------------------
ax = axes[1]

# Group centers (one per time-of-day)
x_centers = np.arange(len(times)) * 1.2  # group spacing between time-of-day groups
width = 0.32                             # bar width
inner_sep = 0.08                         # extra space BETWEEN Summer and Winter within each group

# Compute positions
pos_summer = x_centers - (width/2 + inner_sep/2)
pos_winter = x_centers + (width/2 + inner_sep/2)

# Stacking baselines
bottom_s = np.zeros(len(times))
bottom_w = np.zeros(len(times))

for i, comp in enumerate(components):
    s_vals = [summer[t][i] for t in times]
    w_vals = [winter[t][i] for t in times]

    ax.bar(pos_summer, s_vals, width, bottom=bottom_s, color=colors[comp])
    ax.bar(pos_winter, w_vals, width, bottom=bottom_w, color=colors[comp])

    bottom_s += s_vals
    bottom_w += w_vals

ax.set_xticks(x_centers)
ax.set_xticklabels(times)
ax.set_title("Summer vs Winter (CLM fractions)")
ax.set_ylim(0, 1)
ax.grid(True, axis="y", alpha=0.3)

# Annotate pair labels under first group for clarity (optional)
ax.text(pos_summer[0], -0.08, "Summer", ha="center", va="top", fontsize=10)
ax.text(pos_winter[0], -0.08, "Winter", ha="center", va="top", fontsize=10)

# -----------------------------
# 3) Legend panel
# -----------------------------
axes[2].axis("off")
handles, labels = axes[0].get_legend_handles_labels()
axes[2].legend(handles, labels, title="CLM Component", loc="center")

# ==================================================
# Title
# ==================================================
fig.suptitle(
    "Residential CLM profiles — Spring/Fall base and Summer vs Winter comparison",
    fontsize=16
)

plt.show()
