
import matplotlib.pyplot as plt
import numpy as np

# Hours from 06:00 to 22:00 + overnight
hours = [
    "06:00", "07:00", "08:00", "09:00", "10:00", "11:00", "12:00",
    "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00",
    "20:00", "21:00", "22:00", "overnight"
]

# Data (percent per hour)
start_time_sp1 = [2, 4, 5.5, 5.5, 4, 6, 5, 7.5, 3, 3.5, 2, 3, 11, 15, 15, 4, 2, 2]
start_time_sp2 = [0.5, 1.5, 7, 4, 5, 3, 4, 4.5, 6, 2, 4.25, 4.25, 8, 13, 16, 4, 6, 7]

# Compute ON percentages (each start lasts 2 hours)
on_time_sp1 = []
on_time_sp2 = []
for i in range(len(hours)):
    val_sp1 = start_time_sp1[i]
    val_sp2 = start_time_sp2[i]
    if i > 0:
        val_sp1 += start_time_sp1[i-1]
        val_sp2 += start_time_sp2[i-1]
    on_time_sp1.append(val_sp1)
    on_time_sp2.append(val_sp2)

# Convert hours to positions
x = np.arange(len(hours))

# Compute sums
sum_sp1 = np.sum(start_time_sp1)
sum_sp2 = np.sum(start_time_sp2)

plt.figure(figsize=(10, 6))

# Plot discrete data using step with shift (where='post')
plt.step(x, start_time_sp1, where='post', color='blue', linewidth=2, label=f'Start time (SP 1) — total: {sum_sp1:.1f}%')
plt.step(x, start_time_sp2, where='post', color='orange', linewidth=2, label=f'Start time (SP 2) — total: {sum_sp2:.1f}%')

# Plot ON curves as dashed steps
plt.step(x, on_time_sp1, where='post', color='blue', linestyle='--', linewidth=2, label='ON time (SP 1)')
plt.step(x, on_time_sp2, where='post', color='orange', linestyle='--', linewidth=2, label='ON time (SP 2)')

# Add markers for clarity
plt.scatter(x, start_time_sp1, color='blue', s=40)
plt.scatter(x, start_time_sp2, color='orange', s=40)
plt.scatter(x, on_time_sp1, color='blue', s=40, marker='x')
plt.scatter(x, on_time_sp2, color='orange', s=40, marker='x')

# Customize x-axis
plt.xticks(x, hours, rotation=45)
plt.xlabel("Dishwasher start times")
plt.ylabel("Percentage (%)")
plt.title("Dishwasher Start and ON Time Distribution (Discrete, Shifted Steps)")

# Add grid and legend
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.legend()

# Add counters as text boxes inside the axes
plt.text(
    0.02, 0.95, f"SP 1 total: {sum_sp1:.1f}%",
    transform=plt.gca().transAxes,
    fontsize=10, color='blue',
    bbox=dict(facecolor='white', edgecolor='blue', boxstyle='round,pad=0.3', alpha=0.8)
)
plt.text(
    0.02, 0.88, f"SP 2 total: {sum_sp2:.1f}%",
    transform=plt.gca().transAxes,
    fontsize=10, color='orange',
    bbox=dict(facecolor='white', edgecolor='orange', boxstyle='round,pad=0.3', alpha=0.8)
)

plt.tight_layout()
plt.show()

