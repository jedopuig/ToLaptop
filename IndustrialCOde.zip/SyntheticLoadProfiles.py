import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os


"--------------------------------------------"
"""MANUAL SETTINGS"""
"--------------------------------------------"
"""Enter WZ_Code of industry type:
10	    Food, beverages and tabac
10.11	Slaughtering excluding poultry
10.13	Meat processing
10.5	Dairy products
10.7	Baked goods
11.05	Beer production
25.1	Steel and light metal production
25.5	Prod. of forgings, etc.
25.61	Surface finishing and heat treatment
25.62	Mechanics
25.7	Manufacture of cutlery, tools etc.
25.9	Manufacture of other products
28	    Machinery"""

industry_type = 25.1

"""Enter local path, where Excel files and Code is stored"""
path = r"/"
"--------------------------------------------"


"--------------------------------------------"
"""GENERAL DATA"""
"--------------------------------------------"
"""Uploads the synthetical load profiles for the enduser and converts them into dataframe"""
load_prof_enduser = pd.read_excel(path+'\\Load_profiles_enduser.xlsx', usecols=('A:J'), index_col=(0))
load_prof_enduser = load_prof_enduser.round(2)
load_prof_enduser.drop('Sum', axis=0 ,inplace=True)
load_prof_enduser.dropna(axis=0,inplace=True)
load_prof_enduser.index = pd.to_datetime(load_prof_enduser.index, format ='%H:%M:%S')
load_prof_enduser.index = load_prof_enduser.index.time
load_prof_enduser =load_prof_enduser.iloc[1:]
"""Uploads the energy distribution for enduser and industry types"""
all_info_wz = pd.read_excel(path+'\\All_data_industry_types.xlsx'.format())
all_info_wz.dropna(how='all',axis=0, inplace=True)
all_info_wz.dropna(how='all',axis=1, inplace=True)
all_info_wz.fillna(0, inplace=True)
"--------------------------------------------"


"--------------------------------------------"
"""GENERATION OF SYNTHETIC LOAD PROFILES"""
"--------------------------------------------"
"""Step 2: Generating a basic load profile """
#data_industry_type = all_info_wz[all_info_wz.WZ_Code.eq(industry_type)] #filters the row with specific industry_wz


data_industry_type = all_info_wz[all_info_wz.WZ_Code.eq(industry_type)].copy()

if float(data_industry_type['Fluctuations'].iloc[0]) == 0:
    data_industry_type.loc[:, 'Fluctuations'] = 19.0


energy_enduser_industry_type = data_industry_type[['Space heating', 'Hot water', 'Process heat', 'Space cooling',
       'Process cooling', 'Lighting', 'ICT', 'Mechanical drive']].values #extracts columns with specific industry_wz
#energy_enduser_industry_type = energy_enduser_industry_type.astype(np.float)
energy_enduser_industry_type = energy_enduser_industry_type.astype(float)

industry_name = str(data_industry_type.iloc[0]['Industry_name']) #filters the row with specific industry_wz
"""Step 3: Classifying mechanical drive processes"""
y=pd.DataFrame()
if data_industry_type['Percentage of discontinuous mechanical drive'].item() != 0:

    pct_disc = float(data_industry_type['Percentage of discontinuous mechanical drive'].iloc[0])
    mechanical_1 = pct_disc / 100.0 * energy_enduser_industry_type.item(7)

    mechanical_2 = energy_enduser_industry_type.item(7) - mechanical_1  #float mechanical2
    energy_enduser_industry_type2 = np.delete(energy_enduser_industry_type, [7]) #remove 'Mechanische Antriebe'
    energy_enduser_industry_type2 = np.append(energy_enduser_industry_type2, [mechanical_2, mechanical_1]) #add 'stetig# und 'unstetig'
    
    y = load_prof_enduser.mul(energy_enduser_industry_type2, axis=1) #Multiplying daily profile with industry type data
    y=y.round(2)

elif data_industry_type['Percentage of discontinuous mechanical drive'].item() == 0:
    load_prof_enduser2 = load_prof_enduser.drop(columns= 'Discontinuous mechanical drive')
    load_prof_enduser2 = load_prof_enduser2.rename(columns={'Continuous mechanical drive': 'Mechanical drive'})
    
    y = load_prof_enduser2.mul(energy_enduser_industry_type, axis=1) #Multiplying daily profile with industry type data
    y=y.round(2)
    
"""Step 4: Applying a fluctuation rate"""
if data_industry_type['Fluctuations'].item()  == 0:
    data_industry_type['Fluctuations'] = 19
    
#fluc_industry_type = float(data_industry_type['Fluctuations'])
fluc_industry_type = float(data_industry_type['Fluctuations'].iloc[0])
s = np.random.normal(0, fluc_industry_type, len(y.index)).round(2) #random numbers generated and saved as s. Always refresh this, to gain new numbers

if data_industry_type['Percentage of discontinuous mechanical drive'].item() !=0:
    y['Discontinuous mechanical drive'] = y['Discontinuous mechanical drive'] + s
      
    sec_row = [{'Space heating' : 'in kW', 'Hot water' : 'in kW',	
               'Process heat' : 'in kW',	'Space cooling' : 'in kW',	
               'Process cooling' : 'in kW',	'Lighting' : 'in kW',	
               'ICT' : 'in kW',	'Continuous mechanical drive' : 'in kW',	
               'Discontinuous mechanical drive' : 'in kW'}]    
    
elif data_industry_type['Percentage of discontinuous mechanical drive'].item()  == 0:
    y['Mechanical drive'] = y['Mechanical drive'] + s
      
    sec_row = [{'Space heating' : 'in kW', 'Hot water' : 'in kW',	
               'Process heat' : 'in kW',	'Space cooling' : 'in kW',	
               'Process cooling' : 'in kW',	'Lighting' : 'in kW',	
               'ICT' : 'in kW',	'Mechanical drive' : 'in kW'}]
"--------------------------------------------"


"--------------------------------------------"
'''Plotting and saving diagram'''
"--------------------------------------------"
if data_industry_type['Percentage of discontinuous mechanical drive'].item() !=0:
    
    new_colors = [ (254/255, 188/255, 195/255),     #Farbe Raumwärme RGB/255
                (255/255, 89/255, 105/255),                    #Farbe Warmwasser 
                (172/255, 0/255, 16/255),                      #Farbe Prozesswärme
                (82/255, 203/255, 190/255),                    #Farbe Klimakälte
                (49/255, 164/255, 151/255),                    #Farbe Prozesskälte
                (254/255, 198/255, 48/255),                    #Farbe Beleuchtung
                (146/255, 208/255, 80/255),                    #Farbe IKT
                (93/255, 115/255, 115/255),                    #Farbe Mechanische Antriebe
                (200/255, 200/255, 200/255)]                   #Farbe unstetige mechanische Antriebe

    labels = ['Space heating', 'Hot water', 'Process heat', 'Space cooling',
   'Process cooling', 'Lighting', 'ICT', 'Continuous mechanical drive',
   'Discontinuous mechanical drive']
    
    y_plot = np.vstack([y['Space heating'].tolist(), 
                y['Hot water'].tolist(),
                y['Process heat'].tolist(),
                y['Space cooling'].tolist(),
                y['Process cooling'].tolist(),
                y['Lighting'].tolist(),
                y['ICT'].tolist(),
                y['Continuous mechanical drive'].tolist(),
                y['Discontinuous mechanical drive'].tolist()])

elif data_industry_type['Percentage of discontinuous mechanical drive'].item() ==0:
    
    new_colors = [ (254/255, 188/255, 195/255),     #Farbe Raumwärme RGB/255
                (255/255, 89/255, 105/255),                    #Farbe Warmwasser 
                (172/255, 0/255, 16/255),                      #Farbe Prozesswärme
                (82/255, 203/255, 190/255),                    #Farbe Klimakälte
                (49/255, 164/255, 151/255),                    #Farbe Prozesskälte
                (254/255, 198/255, 48/255),                    #Farbe Beleuchtung
                (146/255, 208/255, 80/255),                    #Farbe IKT
                (93/255, 115/255, 115/255),]                   #Farbe mechanische Antriebe

    labels = ['Space heating', 'Hot water', 'Process heat', 'Space cooling',
   'Process cooling', 'Lighting', 'ICT', 'Mechanical drive']
    
    y_plot = np.vstack([y['Space heating'].tolist(), 
                y['Hot water'].tolist(),
                y['Process heat'].tolist(),
                y['Space cooling'].tolist(),
                y['Process cooling'].tolist(),
                y['Lighting'].tolist(),
                y['ICT'].tolist(),
                y['Mechanical drive'].tolist()])



def diagram(y, industry_type):
    # Convert the index (datetime.time) to strings for plotting
    x_plot = [x.strftime('%H:%M') for x in y.index]

    fig, ax = plt.subplots(figsize=(15, 10))

    # stackplot expects sequences for each layer; y_plot and labels/new_colors are defined above
    ax.stackplot(x_plot, y_plot, labels=labels, colors=new_colors)

    ax.set_xlabel('Time', fontsize=18)
    ax.set_ylabel('Normalized Power in kW', fontsize=18)
    ax.grid(True)

    # Set sparse x ticks (every 16th label)
    ax.set_xticks(x_plot[::16])
    ax.set_xticklabels(x_plot[::16], fontsize=18)
    ax.tick_params(axis='y', labelsize=18)

    # ===== Legend (robust) =====
    handles, legend_labels = ax.get_legend_handles_labels()
    ax.legend(handles[::-1], legend_labels[::-1], loc='upper right', fontsize=16)

    # Optional: with string x, skip xlim (let Matplotlib handle it)
    # If you really want bounds, use indices:
    # ax.set_xlim(0, len(x_plot) - 1)

    ax.set_ylim(bottom=0, top=160)

    ax.set_title('Synthetical load profile of WZ08 ' + str(industry_type) + ' ' + industry_name, fontsize=20)

    # Ensure Results directory exists
    results_dir = os.path.join(path, '../../Results')
    os.makedirs(results_dir, exist_ok=True)

    fig.savefig(os.path.join(results_dir, f"{industry_type} {industry_name[0:10]} Diagram.png"), bbox_inches='tight')
    plt.show()
()

# --- Composite Load Model mapping of end-use -> motor/electronic fractions ---
# Fractions here apply to *that end-use’s* power at a given time.
# The unmapped remainder is treated as Static (ZIP).
ENDUSE_TO_CLM = {
    'Space heating': {'MotorB': 0.30},  # fans, air handlers; rest static heating
    'Hot water': {'MotorC': 0.10},  # circulation pumps; rest resistive/static
    'Process heat': {'Electronic': 0.05},  # small VSD/control; rest static
    'Space cooling': {'MotorA': 0.60, 'MotorB': 0.40},  # compressors + fans
    'Process cooling': {'MotorA': 0.50, 'MotorB': 0.30, 'MotorC': 0.20},
    'Lighting': {'Electronic': 1.00},  # LED/ballasts/inverters
    'ICT': {'Electronic': 1.00},  # servers, electronics
    'Mechanical drive': {'MotorA': 0.60, 'MotorB': 0.30, 'MotorC': 0.10}
    # 'MotorD' defaults to 0 here (industrial context). Add if relevant.
}


# Utility: collapse continuous/discontinuous mechanical drive if present
def _unify_mechanical_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    mech_cols = [c for c in ['Continuous mechanical drive', 'Discontinuous mechanical drive'] if c in df.columns]
    if mech_cols:
        df['Mechanical drive'] = df[mech_cols].sum(axis=1)
        df.drop(columns=mech_cols, inplace=True)
    return df


def clm_fractions_at_time(y: pd.DataFrame, time_str: str,
                          enduse_to_clm: dict = ENDUSE_TO_CLM,
                          enforce_sum_le_1: bool = True) -> pd.Series:
    """
    Returns WECC CLM fractions at a given HH:MM (index contains datetime.time).
    Output keys: FmA, FmB, FmC, FmD, Fel, Fstat.
    - Fractions of motors/electronic are computed from mapped portions of each end-use.
    - Static (ZIP) fraction is the remainder so that total sums to 1 (or <=1 if enforce_sum_le_1==False).
    """
    df = _unify_mechanical_columns(y)

    # Select the row at given time
    try:
        t = pd.to_datetime(time_str, format='%H:%M').time()
        row = df.loc[t]
    except Exception as e:
        raise ValueError(f"Time '{time_str}' not found; ensure format 'HH:MM' and index is datetime.time.") from e

    total = float(row.sum())
    if total <= 0:
        return pd.Series({'FmA': 0.0, 'FmB': 0.0, 'FmC': 0.0, 'FmD': 0.0, 'Fel': 0.0, 'Fstat': 1.0})

    # Accumulate component *powers* from mapped portions
    comp_power = {'MotorA': 0.0, 'MotorB': 0.0, 'MotorC': 0.0, 'MotorD': 0.0, 'Electronic': 0.0}
    for enduse, power in row.items():
        if enduse in enduse_to_clm:
            for comp, frac in enduse_to_clm[enduse].items():
                comp_power[comp] += float(power) * float(frac)

    # If mapped motors+electronic exceed total (over-aggressive mapping), normalize them to total
    motor_elec_total = sum(comp_power.values())
    if motor_elec_total > total and enforce_sum_le_1:
        scale = total / motor_elec_total
        for k in comp_power:
            comp_power[k] *= scale
        motor_elec_total = total

    # Fractions
    FmA = comp_power['MotorA'] / total
    FmB = comp_power['MotorB'] / total
    FmC = comp_power['MotorC'] / total
    FmD = comp_power['MotorD'] / total
    Fel = comp_power['Electronic'] / total

    # Static is the remainder (CLM practice): 1 - (motors + electronic)
    Fstat = max(0.0, 1.0 - (FmA + FmB + FmC + FmD + Fel))

    # Final renormalization if numerical drift made sum slightly > 1
    s = FmA + FmB + FmC + FmD + Fel + Fstat
    if abs(s - 1.0) > 1e-6 and enforce_sum_le_1:
        FmA, FmB, FmC, FmD, Fel, Fstat = [v / s for v in [FmA, FmB, FmC, FmD, Fel, Fstat]]

    return pd.Series({'FmA': round(FmA, 4),
                      'FmB': round(FmB, 4),
                      'FmC': round(FmC, 4),
                      'FmD': round(FmD, 4),
                      'Fel': round(Fel, 4),
                      'Fstat': round(Fstat, 4)})



#----------------------GET CLM FRACTIONS----------------------

fractions_1015 = clm_fractions_at_time(y, '06:30') # 15-minute timesteps only
print(fractions_1015)
# FmA, FmB, FmC, FmD, Fel, Fstat (sum ≈ 1.0)


#--------PLOT DAILY PROFILE OF SELECTED INDUSTRY TYPE---------

diagram(y, industry_type)
sec_row = pd.DataFrame(sec_row)
data=pd.concat([sec_row, y])
if not os.path.exists(path +'\\Results\\'):    
    os.mkdir(path +'\\Results')    
data.to_excel(path +'\\Results\\' +str(industry_type)+" "+ str(industry_name[0:10])+" "+' Dataframe.xlsx')
"--------------------------------------------"



