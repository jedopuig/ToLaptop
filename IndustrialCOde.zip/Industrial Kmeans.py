import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from matplotlib.patches import Patch

# ============================================================
# USER SETTINGS
# ============================================================
industry_type = 25.1  # e.g., 25.1 Steel and light metal production

BASE_OUT = Path(
    r"C:\Users\308892\OneDrive - TenneT TSO B.V"
    r"\Documents\Aggregated Load\Load Profiles\Industrial Sector"
)
BASE_OUT.mkdir(parents=True, exist_ok=True)

RANDOM_STATE = 42
K_RANGE = [2, 3, 4, 5]
N_INIT = 20
MAX_ITER = 300
TOL = 1e-4

SCRIPTS_DIR = Path(
    r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Scripts\Load Profiles\Industrial"
)

# ============================================================
# LOAD DATA
# ============================================================
load_prof_enduser = pd.read_excel(
    SCRIPTS_DIR / "Load_profiles_enduser.xlsx",
    usecols="A:J",
    index_col=0
).round(2)

load_prof_enduser.drop('Sum', axis=0, inplace=True)
load_prof_enduser.dropna(inplace=True)
load_prof_enduser.index = pd.to_datetime(
    load_prof_enduser.index, format='%H:%M:%S'
).time
load_prof_enduser = load_prof_enduser.iloc[1:]

all_info_wz = pd.read_excel(SCRIPTS_DIR / "All_data_industry_types.xlsx").fillna(0)
data_industry_type = all_info_wz[all_info_wz.WZ_Code.eq(industry_type)].copy()

if data_industry_type.empty:
    raise ValueError(f"WZ_Code '{industry_type}' not found")

industry_name = data_industry_type.iloc[0]['Industry_name']

# ============================================================
# BUILD INDUSTRIAL LOAD PROFILE y
# ============================================================
energy = data_industry_type[
    ['Space heating','Hot water','Process heat','Space cooling',
     'Process cooling','Lighting','ICT','Mechanical drive']
].astype(float).values.flatten()

if data_industry_type['Percentage of discontinuous mechanical drive'].item() != 0:
    pct = data_industry_type['Percentage of discontinuous mechanical drive'].item() / 100
    mech_disc = pct * energy[7]
    mech_cont = energy[7] - mech_disc
    e2 = np.delete(energy, 7)
    e2 = np.append(e2, [mech_cont, mech_disc])
    y = load_prof_enduser.mul(e2, axis=1)
else:
    y = load_prof_enduser.drop(columns='Discontinuous mechanical drive', errors='ignore')
    y = y.rename(columns={'Continuous mechanical drive': 'Mechanical drive'})
    y = y.mul(energy, axis=1)

fluc = float(data_industry_type['Fluctuations'].iloc[0] or 19)
np.random.seed(RANDOM_STATE)
y.iloc[:, -1] += np.random.normal(0, fluc, len(y))
y = y.clip(lower=0)

# ============================================================
# CLM MAPPING
# ============================================================
ENDUSE_TO_CLM = {
    'Space heating': {'MotorB': 0.30},
    'Hot water': {'MotorC': 0.10},
    'Process heat': {'Electronic': 0.05},
    'Space cooling': {'MotorA': 0.60, 'MotorB': 0.40},
    'Process cooling': {'MotorA': 0.50, 'MotorB': 0.30, 'MotorC': 0.20},
    'Lighting': {'Electronic': 1.00},
    'ICT': {'Electronic': 1.00},
    'Mechanical drive': {'MotorA': 0.60, 'MotorB': 0.30, 'MotorC': 0.10}
}

def unify_mech(df):
    df = df.copy()
    for c in ['Continuous mechanical drive', 'Discontinuous mechanical drive']:
        if c in df.columns:
            df['Mechanical drive'] = df.get('Mechanical drive', 0) + df[c]
            df.drop(columns=c, inplace=True)
    return df

def clm_fractions_at_time(y, tstr):
    row = unify_mech(y).loc[pd.to_datetime(tstr).time()]
    total = row.sum()
    comp = dict(MotorA=0, MotorB=0, MotorC=0, MotorD=0, Electronic=0)
    for eu, p in row.items():
        for k, f in ENDUSE_TO_CLM.get(eu, {}).items():
            comp[k] += p * f

    vals = {
        'FmA': comp['MotorA']/total,
        'FmB': comp['MotorB']/total,
        'FmC': comp['MotorC']/total,
        'FmD': 0.0,
        'Fel': comp['Electronic']/total,
    }
    vals['Fstat'] = max(0.0, 1 - sum(vals.values()))
    s = sum(vals.values())
    return pd.Series({k: v/s for k, v in vals.items()})

rows = []
for t in pd.date_range('00:00','23:45',freq='15min'):
    r = clm_fractions_at_time(y, t.strftime('%H:%M'))
    r['timestamp'] = t
    rows.append(r)

df_clm = pd.DataFrame(rows).set_index('timestamp')

# ============================================================
# K-MEANS + SILHOUETTE
# ============================================================
X = df_clm[['FmA','FmB','FmC','FmD','Fel','Fstat']].values

def kmeans_numpy(X, K, seed):
    rs = np.random.RandomState(seed)
    centroids = X[rs.choice(len(X), K, replace=False)]
    for _ in range(MAX_ITER):
        d2 = ((X[:,None,:]-centroids[None,:,:])**2).sum(2)
        labels = d2.argmin(1)
        new = np.array([X[labels==k].mean(0) for k in range(K)])
        if np.linalg.norm(new-centroids) < TOL:
            break
        centroids = new
    inertia = ((X-centroids[labels])**2).sum()
    return labels, centroids, inertia

def silhouette_numpy(X, labels):
    D = np.linalg.norm(X[:,None,:]-X[None,:,:],axis=2)
    np.fill_diagonal(D,0)
    s=[]
    for i in range(len(X)):
        a = D[i][labels==labels[i]].mean()
        b = min(D[i][labels==k].mean() for k in set(labels) if k!=labels[i])
        s.append((b-a)/max(a,b))
    return np.mean(s)

best = None
for K in K_RANGE:
    for r in range(N_INIT):
        lbl, c, _ = kmeans_numpy(X, K, RANDOM_STATE+r)
        sil = silhouette_numpy(X, lbl)
        if best is None or sil > best['sil']:
            best = dict(K=K, labels=lbl, cents=c, sil=sil)

labels = best['labels']
df_clm['cluster'] = labels

# ============================================================
# PRINT CLUSTER INTERPRETATION (CONSOLE ONLY)
# ============================================================
print("\n✅ INTERPRETATION OF CLUSTERS")

for cl in sorted(df_clm.cluster.unique()):
    dfc = df_clm[df_clm.cluster == cl]
    mean = dfc[['FmA','FmB','FmC','FmD','Fel','Fstat']].mean()
    share = len(dfc)/len(df_clm)*100
    dominant = mean.idxmax()

    if dominant == 'Fstat':
        regime = "Static / low industrial activity"
    elif dominant.startswith('Fm'):
        regime = "Motor-dominated / high industrial activity"
    else:
        regime = "Mixed load regime"

    print(f"\nCluster {cl}:")
    print(f"  • Regime: {regime}")
    print(f"  • Share of day: {share:.1f} %")
    print("  • Mean CLM fractions:")
    print("    " + "  ".join(f"{k}={mean[k]:.2f}" for k in mean.index))