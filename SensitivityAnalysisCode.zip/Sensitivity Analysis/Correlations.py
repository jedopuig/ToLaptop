import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

# ✅ Correct folder path
folder = r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Sensitivity Analysis\IndividualPowers"

# File names
files = ["AggregatedResults_Fma_1.csv", "AggregatedResults_Fmb_1.csv", "AggregatedResults_Fmc_1.csv"]

# Output folder for plots
plot_folder = os.path.join(folder, "Plots")
os.makedirs(plot_folder, exist_ok=True)

# Prepare a list to store summary data
summary_data = []

# Loop through each file
for file in files:
    path = os.path.join(folder, file)
    if not os.path.exists(path):
        print(f"⚠️ File not found: {path}")
        continue

    df = pd.read_csv(path)

    # Extract Psetpoint and other columns
    x = df['Psetpoint']
    columns_to_fit = df.columns[1:]  # All except Psetpoint

    # Fit and plot for each column
    for col in columns_to_fit:
        y = df[col]

        # Fit a polynomial (degree 2)
        coeffs = np.polyfit(x, y, deg=2)
        poly = np.poly1d(coeffs)
        y_fit = poly(x)

        # Compute derivative at midpoint of Psetpoint range
        midpoint = (x.min() + x.max()) / 2
        derivative_mid = 2 * coeffs[0] * midpoint + coeffs[1]

        # Save summary info
        summary_data.append({
            'File': file,
            'Column': col,
            'Coeff_a2': coeffs[0],
            'Coeff_a1': coeffs[1],
            'Coeff_a0': coeffs[2],
            'Derivative_at_midpoint': derivative_mid
        })

        # Plot
        plt.figure(figsize=(8, 5))
        plt.scatter(x, y, color='blue', label='Data')
        plt.plot(x, y_fit, color='red', label=f'Fit: {poly}')
        plt.title(f"{col} vs Psetpoint ({file})")
        plt.xlabel("Psetpoint")
        plt.ylabel(col)
        plt.legend()
        plt.grid(True)

        # Save plot
        plot_name = f"{file.replace('.csv','')}_{col}.png"
        plt.savefig(os.path.join(plot_folder, plot_name))
        plt.close()

# ✅ Save summary table
summary_df = pd.DataFrame(summary_data)
summary_file = os.path.join(plot_folder, "Polynomial_Fit_Summary.csv")
summary_df.to_csv(summary_file, index=False)

print(f"✅ Plots saved in: {plot_folder}")
print(f"✅ Summary table saved as: {summary_file}")