import sys
import pandas as pd
import matplotlib.pyplot as plt

# PowerFactory setup
import powerfactory
app = powerfactory.GetApplication()
app.ClearOutputWindow()
app.PrintPlain("Starting to run the script.")

ActiveProject = app.GetActiveProject()
if not ActiveProject:
    app.PrintError('No project active !!!')
    sys.exit()
app.ResetCalculation()

# Get study case commands
ini = app.GetFromStudyCase('ComInc')
sim = app.GetFromStudyCase('ComSim')
Results = app.GetFromStudyCase('ComRes')

load = app.GetCalcRelevantObjects('*.ElmLod')

# Lists to store results
fma_values = []
max_P, min_P = [], []
max_Q, min_Q = [], []
max_V, min_V = [], []
max_I, min_I = [], []
max_f, min_f = [], []
recovery_times = []

# Sweep Fma
for fma_value in [round(i * 0.01, 2) for i in range(101)]:
    load[0].Fel = fma_value
    ini.Execute()
    sim.Execute()

    # File path
    file_path = rf'C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Sensitivity Analysis\SensitivityAnalysis_Fma_{fma_value:.2f}.csv'
    Results.f_name = file_path
    Results.Execute()

    # Read CSV and skip first row
    df = pd.read_csv(file_path, skiprows=1)
    df.columns = ['Time', 'V', 'P', 'Q', 'I', 'f']

    # Compute max/min
    max_P.append(df['P'].max()); min_P.append(df['P'].min())
    max_Q.append(df['Q'].max()); min_Q.append(df['Q'].min())
    max_V.append(df['V'].max()); min_V.append(df['V'].min())
    max_I.append(df['I'].max()); min_I.append(df['I'].min())
    max_f.append(df['f'].max()); min_f.append(df['f'].min())
    fma_values.append(fma_value)

    # --- NEW: Calculate recovery time ---
    df_after = df[df['Time'] > 1.01]  # Only consider time after 1.01 s
    recovery_time = None

    for i in range(len(df_after)):
        if df_after.iloc[i]['V'] >= 0.99:
            # Check if it stays >= 0.99 for at least 0.2 s
            start_time = df_after.iloc[i]['Time']
            end_time = start_time + 0.2
            # Slice next 0.2 s window
            window = df_after[(df_after['Time'] >= start_time) & (df_after['Time'] <= end_time)]
            if (window['V'] >= 0.99).all():
                recovery_time = start_time
                break

    recovery_times.append(recovery_time if recovery_time is not None else float('nan'))


recovery_times = [t - 1.25 if not pd.isna(t) else float('nan') for t in recovery_times]

# --- NEW Plot 3: Recovery Time vs Fma ---
plt.figure(figsize=(10, 6))
plt.plot(fma_values, recovery_times, color='brown')
plt.title('Voltage Recovery Time vs Fel')
plt.xlabel('Fel')
plt.ylabel('Recovery Time (s)')
plt.grid(True)
plt.tight_layout()
plt.show()

'''
# Plot 1: P and Q vs Fma
plt.figure(figsize=(10, 6))
plt.plot(fma_values, max_P, label='Max P', color='blue')
plt.plot(fma_values, min_P, label='Min P', color='blue', linestyle='--')
plt.plot(fma_values, max_Q, label='Max Q', color='green')
plt.plot(fma_values, min_Q, label='Min Q', color='green', linestyle='--')
plt.title('Max and Min P and Q vs Fma')
plt.xlabel('Fma')
plt.ylabel('Values')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# Plot 2: V, I, and f vs Fma
plt.figure(figsize=(10, 6))
plt.plot(fma_values, max_V, label='Max V', color='orange')
plt.plot(fma_values, min_V, label='Min V', color='orange', linestyle='--')
plt.plot(fma_values, max_I, label='Max I', color='purple')
plt.plot(fma_values, min_I, label='Min I', color='purple', linestyle='--')
plt.plot(fma_values, max_f, label='Max f', color='red')
plt.plot(fma_values, min_f, label='Min f', color='red', linestyle='--')
plt.title('Max and Min V, I, and f vs Fma')
plt.xlabel('Fma')
plt.ylabel('Values')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

'''

app.PrintPlain("Script run until the end.")
