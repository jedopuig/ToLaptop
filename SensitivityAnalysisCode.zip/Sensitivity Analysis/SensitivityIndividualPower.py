import sys
import pandas as pd
import os
import math
import matplotlib.pyplot as plt
import plotly.express as px


# PowerFactory setup
import powerfactory
app = powerfactory.GetApplication()
app.ClearOutputWindow()
app.PrintPlain("Starting to run the script.")

ActiveProject = app.GetActiveProject()
if not ActiveProject:
    app.PrintError('No project active !!!')
    sys.exit()
app.ResetCalculation()

# Get study case commands
ini = app.GetFromStudyCase('ComInc')
sim = app.GetFromStudyCase('ComSim')
Results = app.GetFromStudyCase('ComRes')


#------------------------- GETTING THE LOADS -------------------------

loads = app.GetCalcRelevantObjects('*.ElmLod')
# Assign loads to variables by name
loadA = next((l for l in loads if l.loc_name == "Composite Model Industrial A"), None)
loadB = next((l for l in loads if l.loc_name == "Composite Model Industrial B"), None)

# Check if found
if not loadA or not loadB:
    app.PrintError("One or both loads not found!")


#------------------------- PREPARE DIRECTORY -------------------------

# Prepare output folder
output_folder = r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Sensitivity Analysis\IndividualPowers"
os.makedirs(output_folder, exist_ok=True)


# Lists to store results
V_initial_series = []
voltage_dips_V_A = []
voltage_dips_V_B = []
recovery_times_V_A_95 = []
recovery_times_V_A_98 = []
recovery_times_V_B_95 = []
recovery_times_V_B_98 = []
Psetpoints = []

loadA.Fma = 0
loadA.Fmb = 0
loadA.Fmc = 1
loadA.Fmd = 0
loadA.Fel = 0

loadB.Fma = 0
loadB.Fmb = 0
loadB.Fmc = 1
loadB.Fmd = 0
loadB.Fel = 0

fault_clearing_time = 0.75



for Psetpoint in range(1, 262, 10):
    loadA.plini = Psetpoint
    loadB.plini = Psetpoint

    PF = 0.95
    tan_phi = math.sqrt(1 - PF**2) / PF
    loadA.qlini = Psetpoint*tan_phi
    loadB.qlini = Psetpoint*tan_phi

    app.PrintPlain(f"Set Psetpoint of {loadA.loc_name} and {loadB.loc_name} to {Psetpoint}")

    ini.Execute()
    sim.Execute()

    # Export CSV with fractions in filename
    file_path = (
            output_folder + f"\\SensitivityAnalysisPower_Psetpoint_{Psetpoint:.2f}.csv"
    )

    Results.f_name = file_path
    Results.Execute()

    # Read CSV and skip first row
    df = pd.read_csv(file_path, skiprows=1)
    df.columns = ['Time', 'V_A', 'I_A', 'V_B', 'I_B', 'P_A', 'Q_A','P_B', 'Q_B']

    time_zero_row = df[df['Time'] == 0]
    V_A_at_zero = time_zero_row['V_A'].iloc[0]
    V_B_at_zero = time_zero_row['V_B'].iloc[0]
    V_initial_series.append(V_A_at_zero)

    # Store parameter combination
    Psetpoints.append(Psetpoint)

    # Calculate voltage dip
    voltage_dip_V_A = 1 - df['V_A'].min()
    voltage_dip_V_B = 1 - df['V_B'].min()

    voltage_dips_V_A.append(voltage_dip_V_A)
    voltage_dips_V_B.append(voltage_dip_V_B)

    # Calculate recovery time
    df_after = df[df['Time'] > 0.6]

    recovery_time_V_A_98 = None
    for i in range(len(df_after)):
        if df_after.iloc[i]['V_A'] >= V_A_at_zero*0.98:
            start_time = df_after.iloc[i]['Time']
            end_time = start_time + 0.2
            window = df_after[(df_after['Time'] >= start_time) & (df_after['Time'] <= end_time)]
            if (window['V_A'] >= V_A_at_zero * 0.98).all():
                recovery_time_V_A_98 = start_time - fault_clearing_time
                break
    recovery_times_V_A_98.append(recovery_time_V_A_98 if recovery_time_V_A_98 is not None else float('nan'))

    recovery_time_V_B_98 = None
    for i in range(len(df_after)):
        if df_after.iloc[i]['V_B'] >= V_B_at_zero*0.98:
            start_time = df_after.iloc[i]['Time']
            end_time = start_time + 0.2
            window = df_after[(df_after['Time'] >= start_time) & (df_after['Time'] <= end_time)]
            if (window['V_B'] >= V_B_at_zero * 0.98).all():
                recovery_time_V_B_98 = start_time - fault_clearing_time
                break
    recovery_times_V_B_98.append(recovery_time_V_B_98 if recovery_time_V_B_98 is not None else float('nan'))

    recovery_time_V_A_95 = None
    for i in range(len(df_after)):
        if df_after.iloc[i]['V_A'] >= V_A_at_zero*0.95:
            start_time = df_after.iloc[i]['Time']
            end_time = start_time + 0.2
            window = df_after[(df_after['Time'] >= start_time) & (df_after['Time'] <= end_time)]
            if (window['V_A'] >= V_A_at_zero * 0.95).all():
                recovery_time_V_A_95 = start_time - fault_clearing_time
                break
    recovery_times_V_A_95.append(recovery_time_V_A_95 if recovery_time_V_A_95 is not None else float('nan'))

    recovery_time_V_B_95 = None
    for i in range(len(df_after)):
        if df_after.iloc[i]['V_B'] >= V_A_at_zero*0.95:
            start_time = df_after.iloc[i]['Time']
            end_time = start_time + 0.2
            window = df_after[(df_after['Time'] >= start_time) & (df_after['Time'] <= end_time)]
            if (window['V_B'] >= V_A_at_zero * 0.95).all():
                recovery_time_V_B_95 = start_time - fault_clearing_time
                break
    recovery_times_V_B_95.append(recovery_time_V_B_95 if recovery_time_V_B_95 is not None else float('nan'))


app.PrintPlain("Simulation sweep completed.")

# Create aggregated DataFrame
results_df = pd.DataFrame(Psetpoints, columns=['Psetpoint'])
results_df['V_Initial'] = V_initial_series
results_df['VoltageDip_V_A'] = voltage_dips_V_A
results_df['VoltageDip_V_B'] = voltage_dips_V_B
results_df['RecoveryTime_V_A_98'] = recovery_times_V_A_98
results_df['RecoveryTime_V_B_98'] = recovery_times_V_B_98
results_df['RecoveryTime_V_A_95'] = recovery_times_V_A_95
results_df['RecoveryTime_V_B_95'] = recovery_times_V_B_95

# Save aggregated results
aggregated_file = output_folder + "\\AggregatedResults_Fmc_1.csv"
results_df.to_csv(aggregated_file, index=False)

app.PrintPlain(f"Aggregated results saved to {aggregated_file}")

app.PrintPlain("Script run until the end.")






