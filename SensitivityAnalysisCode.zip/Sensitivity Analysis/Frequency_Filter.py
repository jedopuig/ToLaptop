
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import butter, filtfilt

# --- File path ---
file_path = r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Sensitivity Analysis\IndividualPowers9bus\SensitivityAnalysisPower_9bus_f6_only.csv"

# --- Read CSV ---
df = pd.read_csv(file_path)

# Convert columns to numeric (handle strings)
time = pd.to_numeric(df.iloc[:, 0], errors='coerce')
frequency = pd.to_numeric(df.iloc[:, 1], errors='coerce')

# Drop NaN rows
mask = ~time.isna() & ~frequency.isna()
time = time[mask].values
frequency = frequency[mask].values

# --- Compute sampling rate ---
sampling_rate = 1 / (time[1] - time[0])  # Hz
nyquist = 0.5 * sampling_rate
cutoff = 15  # Hz (adjust if needed)
normal_cutoff = cutoff / nyquist

# --- Design Butterworth filter ---
order = 2  # Low order
b, a = butter(order, normal_cutoff, btype='low', analog=False)
# Apply zero-phase filtering
filtered_freq = filtfilt(b, a, frequency)

# --- Plot ---
plt.figure(figsize=(10, 6))
plt.plot(time, frequency, label='Original Frequency', color='blue')
plt.plot(time, filtered_freq, label='Filtered Frequency', color='red', linewidth=2)
plt.xlabel('Time (s)')
plt.ylabel('Electrical Frequency (p.u.)')
plt.title('Original vs Filtered Electrical Frequency')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# --- Print info ---
print(f"Sampling rate: {sampling_rate:.2f} Hz")
print(f"Filter cutoff: {cutoff} Hz")
