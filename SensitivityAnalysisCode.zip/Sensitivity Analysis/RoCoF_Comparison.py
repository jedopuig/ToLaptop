
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# --------------------------
# Configuration
# --------------------------
# Update this path if needed (use raw string for Windows paths)
excel_path = r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Sensitivity Analysis\IndividualPowers9bus\RoCoF_Comparison.xlsx"
sheet_name = 0  # or a string with the sheet name
output_dir = os.path.join(os.path.dirname(excel_path), "RoCoF_Fits")
os.makedirs(output_dir, exist_ok=True)

# --------------------------
# Helper functions
# --------------------------
def adjusted_r2(y_true, y_pred, p):
    """
    Compute adjusted R^2 given predictions.
    p = number of parameters in model (including intercept if applicable).
    """
    n = len(y_true)
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan
    # Adjusted R^2
    adj_r2 = 1 - (1 - r2) * (n - 1) / (n - p - 1) if n > p + 1 else np.nan
    return r2, adj_r2

def fit_best_poly(x, y, max_degree=3):
    """
    Fit polynomial models of degree 1..max_degree and select best by adjusted R^2.
    Returns a dict with details of the best model.
    """
    results = []
    # Clean data: drop NaNs and sort by x
    mask = (~pd.isna(x)) & (~pd.isna(y))
    x = np.asarray(x[mask], dtype=float)
    y = np.asarray(y[mask], dtype=float)
    order = np.argsort(x)
    x = x[order]
    y = y[order]

    # If not enough points, bail
    if len(x) < 3:
        return {
            "degree": None,
            "coeffs": None,
            "r2": np.nan,
            "adj_r2": np.nan,
            "x": x,
            "y": y,
            "y_fit": None
        }

    for deg in range(1, max_degree + 1):
        coeffs = np.polyfit(x, y, deg)  # highest power first
        poly = np.poly1d(coeffs)
        y_fit = poly(x)
        # parameters p = deg + 1 (including constant term)
        r2, adj_r2 = adjusted_r2(y, y_fit, p=deg + 1)
        results.append({
            "degree": deg,
            "coeffs": coeffs,
            "r2": r2,
            "adj_r2": adj_r2,
            "x": x,
            "y": y,
            "y_fit": y_fit,
            "poly": poly
        })

    # Pick the model with max adjusted R^2
    best = max(results, key=lambda d: (d["adj_r2"] if not np.isnan(d["adj_r2"]) else -np.inf))
    return best

def plot_fit(component_name, x, y, poly, save_path):
    """
    Plot scatter and polynomial fit curve over the x range.
    """
    plt.figure(figsize=(8, 5))
    plt.scatter(x, y, color="tab:blue", s=30, label="Data")
    # Create smooth x for curve
    x_min, x_max = np.min(x), np.max(x)
    x_smooth = np.linspace(x_min, x_max, 400)
    y_smooth = poly(x_smooth)
    plt.plot(x_smooth, y_smooth, color="tab:red", lw=2, label="Best fit")

    plt.title(f"RoCoF vs Psetpoint — {component_name}")
    plt.xlabel("Psetpoint")
    plt.ylabel("max_RoCoF")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=200)
    plt.close()

# --------------------------
# Load data
# --------------------------
# Read with openpyxl engine for .xlsx
df = pd.read_excel(excel_path, sheet_name=sheet_name, engine="openpyxl")

# Expect 6 columns: [P1, RoCoF1, P2, RoCoF2, P3, RoCoF3]
# If columns have repeated names, rename them explicitly:
if df.shape[1] < 6:
    raise ValueError("Expected at least 6 columns (Psetpoint/max_RoCoF repeated three times).")

# Build column groups robustly by pairing consecutive columns
# You can also hardcode names if needed:
col_pairs = []
cols = list(df.columns)
for i in range(0, 6, 2):
    col_pairs.append((cols[i], cols[i+1]))

# If the sheet has more columns beyond 6, slice them:
col_pairs = col_pairs[:3]

component_names = ["Component A", "Component B", "Component C"]

# --------------------------
# Fit models and export results
# --------------------------
summary_rows = []

for idx, (p_col, r_col) in enumerate(col_pairs):
    comp_name = component_names[idx] if idx < len(component_names) else f"Component {idx+1}"

    x = df[p_col]
    y = df[r_col]

    best = fit_best_poly(x, y, max_degree=3)

    if best["degree"] is None:
        print(f"[Warning] Not enough data to fit for {comp_name}.")
        continue

    # Plot and save
    fig_path = os.path.join(output_dir, f"{comp_name.replace(' ', '_')}_RoCoF_fit.png")
    plot_fit(comp_name, best["x"], best["y"], best["poly"], fig_path)

    # Build a dense x for export (optional)
    x_dense = np.linspace(np.min(best["x"]), np.max(best["x"]), 200)
    y_dense = best["poly

    # Record summary
    summary_rows.append({
        "Component": comp_name,
        "P_column": p_col,
        "RoCoF_column": r_col,
        "Model_degree": best["degree"],
        "Coefficients (highest power first)": ", ".join(f"{c:.8g}" for c in best["coeffs"]),
        "R2": best["r2"],
        "Adjusted R2": best["adj_r2"],
        "Figure_path": fig_path
    })

    # Save per-component fitted curve to CSV for inspection
    comp_curve_csv = os.path.join(output_dir, f"{comp_name.replace(' ', '_')}_fitted_curve.csv")
    pd.DataFrame({"Psetpoint": x_dense, "RoCoF_fit": y_dense}).to_csv(comp_curve_csv, index=False)

# Save summary to Excel
summary_df = pd.DataFrame(summary_rows)
summary_xlsx = os.path.join(output_dir, "RoCoF_fit_summary.xlsx")
with pd.ExcelWriter(summary_xlsx, engine="openpyxl") as writer:
    summary_df.to_excel(writer, sheet_name="Summary", index=False)

print("Done.")
print(f"Summary saved to: {summary_xlsx}")
print(f"Figures and per-component fitted curves saved to: {output_dir}")
