import sys
import pandas as pd
import io
import os
import math
import numpy as np


if sys.stderr is None:
    sys.stderr = io.StringIO()
if sys.stdout is None:
    sys.stdout = io.StringIO()


from scipy.signal import butter, filtfilt

import matplotlib.pyplot as plt
import plotly.express as px


# PowerFactory setup
import powerfactory
app = powerfactory.GetApplication()
app.ClearOutputWindow()
app.PrintPlain("Starting to run the script.")

ActiveProject = app.GetActiveProject()
if not ActiveProject:
    app.PrintError('No project active !!!')
    sys.exit()
app.ResetCalculation()

# Get study case commands
ini = app.GetFromStudyCase('ComInc')
sim = app.GetFromStudyCase('ComSim')
Results = app.GetFromStudyCase('ComRes')

# Prepare output folder
output_folder = r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Sensitivity Analysis\IndividualPowers9bus"
os.makedirs(output_folder, exist_ok=True)

# Final aggregated file where the results will be stored
aggregated_file = output_folder + "\\AggregatedResults_Fmc_1.csv"


try:
    # Try opening the file in append mode
    with open(aggregated_file, 'a'):
        pass
except PermissionError:
    # File is locked or open by another process
    raise SystemExit(f"ERROR: The file '{aggregated_file}' is currently open. Please close it and rerun the script.")




#------------------------- GETTING THE LOAD -------------------------

loads = app.GetCalcRelevantObjects('*.ElmLod')
# Assign loads to variables by name
CLM = next((l for l in loads if l.loc_name == "Industrial Composite Load Model"), None)



# Lists to store results
V_initial_series = []
voltage_dips = []
recovery_times_V_95 = []
Psetpoints = []
max_RoCoF_list = []
nadir_list = []

CLM.Fma = 0
CLM.Fmb = 0
CLM.Fmc = 1
CLM.Fmd = 0
CLM.Fel = 0

fault_clearing_time = 0.75



for Psetpoint in range(1, 141, 4):
    CLM.plini = Psetpoint

    PF = 0.9
    tan_phi = math.sqrt(1 - PF**2) / PF

    CLM.qlini = Psetpoint*tan_phi

    app.PrintPlain(f"Set Psetpoint of {CLM.loc_name} to {Psetpoint}")

    ini.Execute()
    sim.Execute()

    # Export CSV with fractions in filename
    file_path = (
            output_folder + f"\\SensitivityAnalysisPower_9bus_Psetpoint_{Psetpoint:.2f}.csv"
    )

    Results.f_name = file_path
    Results.Execute()


    # Read CSV and skip first row
    df = pd.read_csv(file_path, skiprows=1)
    df.columns = ['Time', 'I', 'P', 'Q', 'V', 'fpu','fhz','fpu_grid','V_grid']


    # window_s = 0.5
    # # Create 0.5s bin index (0-based)
    # bin_idx = (df['Time'] // window_s).astype(int)
    # df['bin_idx'] = bin_idx
    #
    # agg = df.groupby('bin_idx').agg(
    #     first_time=('Time', 'first'),
    #     last_time=('Time', 'last'),
    #     first_f=('fpu_grid', 'first'),
    #     last_f=('fpu_grid', 'last')
    # )
    #
    # dt = agg['last_time'] - agg['first_time']
    # agg['RoCoF_pu'] = np.where(dt > 0, (agg['last_f'] - agg['first_f']) / dt, 0.0)
    # # Map the bin RoCoF back to all rows in df (constant within each 0.5s bin)
    # df['RoCoF_pu_500ms'] = df['bin_idx'].map(agg['RoCoF_pu'])
    # # If you need NaNs as zeros:
    # df['RoCoF_pu_500ms'] = df['RoCoF_pu_500ms'].fillna(0.0)
    # # Compute max RoCoF over the 500 ms windows
    # max_RoCoF_500ms = agg['RoCoF_pu'].max()
    # max_RoCoF_list.append(max_RoCoF_500ms)

    #-------------------------------------------RoCoF-------------------------------------------




    freqs = pd.to_numeric(df['fpu_grid'], errors='coerce')
    mask = ~freqs.isna()
    freqs = freqs[mask].values

    times = pd.to_numeric(df['Time'], errors='coerce')  # Replace with actual column name
    times = times[mask].values
    sampling_rate = 1 / (times[1] - times[0])

    cutoff = 15.0  # Hz
    nyquist = 0.5 * sampling_rate
    normal_cutoff = cutoff / nyquist
    b, a = butter(2, normal_cutoff, btype='low', analog=False)
    filtered_freqs = filtfilt(b, a, freqs)

    window_s = 0.04
    step_s = 0.002
    start_times = np.arange(times.min(), times.max() - window_s, step_s)

    results_RoCoF_within_interation = []
    for start in start_times:
        end = start + window_s
        mask = (times >= start) & (times < end)
        if mask.sum() > 1:  # Need at least two points
            first_time = times[mask][0]
            last_time = times[mask][-1]
            first_f = filtered_freqs[mask][0]
            last_f = filtered_freqs[mask][-1]
            dt = last_time - first_time
            rocof = (last_f - first_f) / dt if dt > 0 else 0.0
        else:
            rocof = 0.0
        results_RoCoF_within_interation.append(rocof)

    # Convert to DataFrame for convenience
    rocof_df = pd.DataFrame({
        'start_time': start_times,
        'RoCoF_pu': results_RoCoF_within_interation
    })

    max_RoCoF_500ms = rocof_df['RoCoF_pu'].max()

    max_RoCoF_list.append(max_RoCoF_500ms)


    #----------------------------------------------------------------------------

    time_zero_row = df[df['Time'] == 0]
    V_at_zero = time_zero_row['V'].iloc[0]
    V_initial_series.append(V_at_zero)

    # Store parameter combination
    Psetpoints.append(Psetpoint)

    # Calculate voltage dip
    voltage_dip = 1 - df['V'].min()
    voltage_dips.append(voltage_dip)

    f_nadir = filtered_freqs.min()
    nadir_list.append(f_nadir)

    # Calculate recovery time
    df_after = df[df['Time'] > 0.6]

    recovery_time_V_95 = None
    for i in range(len(df_after)):
        if df_after.iloc[i]['V'] >= V_at_zero*0.95:
            start_time = df_after.iloc[i]['Time']
            end_time = start_time + 0.2
            window = df_after[(df_after['Time'] >= start_time) & (df_after['Time'] <= end_time)]
            if (window['V'] >= V_at_zero * 0.95).all():
                recovery_time_V_95 = start_time - fault_clearing_time
                break
    recovery_times_V_95.append(recovery_time_V_95 if recovery_time_V_95 is not None else float('nan'))


app.PrintPlain("Simulation sweep completed.")

# Create aggregated DataFrame
results_df = pd.DataFrame(Psetpoints, columns=['Psetpoint'])
results_df['V_Initial'] = V_initial_series
results_df['VoltageDip'] = voltage_dips
results_df['RecoveryTime_V_95'] = recovery_times_V_95
results_df['max_RoCoF'] = max_RoCoF_list
results_df['nadir'] = nadir_list

# Save aggregated results
results_df.to_csv(aggregated_file, index=False)

app.PrintPlain(f"Aggregated results saved to {aggregated_file}")

app.PrintPlain("Script run until the end.")
