import sys
import pandas as pd
import os
import matplotlib.pyplot as plt
import plotly.express as px


# PowerFactory setup
import powerfactory
app = powerfactory.GetApplication()
app.ClearOutputWindow()
app.PrintPlain("Starting to run the script.")

ActiveProject = app.GetActiveProject()
if not ActiveProject:
    app.PrintError('No project active !!!')
    sys.exit()
app.ResetCalculation()

# Get study case commands
ini = app.GetFromStudyCase('ComInc')
sim = app.GetFromStudyCase('ComSim')
Results = app.GetFromStudyCase('ComRes')

load = app.GetCalcRelevantObjects('*.ElmLod')
load = load[0]


# Prepare output folder
output_folder = r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Sensitivity Analysis\Interactions"
os.makedirs(output_folder, exist_ok=True)


# Lists to store results
param_combinations = []
max_P, min_P = [], []
max_Q, min_Q = [], []
max_V, min_V = [], []
max_I, min_I = [], []
max_f, min_f = [], []
voltage_dips = []
recovery_times = []

step = 0.1
values = [round(i * step, 2) for i in range(int(0.5 / step) + 1)]  # [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
# valuesPowerA = linspace(0,maxMotorA,10), definir total power, y de ahi obtener las fracciones

for Fma in values:
    for Fmb in values:
        for Fmc in values:
            for Fmd in values:
                Fel = round(1 - (Fma + Fmb + Fmc + Fmd), 2)
                if Fel < 0 or Fel > 1:
                    continue  # Skip invalid combinations

                # Set load parameters
                load.Fma = Fma
                load.Fmb = Fmb
                load.Fmc = Fmc
                load.Fmd = Fmd
                load.Fel = Fel

                ini.Execute()
                sim.Execute()

                # Export CSV with fractions in filename
                file_path = (
                        output_folder + f"\\SensitivityAnalysis_Fma_{Fma:.2f}_Fmb_{Fmb:.2f}_Fmc_{Fmc:.2f}_Fmd_{Fmd:.2f}_Fel_{Fel:.2f}.csv"
                )

                Results.f_name = file_path
                Results.Execute()

                # Read CSV and skip first row
                df = pd.read_csv(file_path, skiprows=1)
                df.columns = ['Time', 'V', 'P', 'Q', 'I', 'f']

                # Compute max/min values
                # max_P.append(df['P'].max());
                # min_P.append(df['P'].min())
                # max_Q.append(df['Q'].max());
                # min_Q.append(df['Q'].min())
                # max_V.append(df['V'].max());
                min_V.append(df['V'].min())
                # max_I.append(df['I'].max());
                # min_I.append(df['I'].min())
                # max_f.append(df['f'].max());
                # min_f.append(df['f'].min())

                # Store parameter combination
                param_combinations.append((Fma, Fmb, Fmc, Fmd, Fel))

                # Calculate voltage dip
                voltage_dip = 1 - df['V'].min()
                voltage_dips.append(voltage_dip)

                # Calculate recovery time
                df_after = df[df['Time'] > 1.01]
                recovery_time = None
                for i in range(len(df_after)):
                    if df_after.iloc[i]['V'] >= 0.99:
                        start_time = df_after.iloc[i]['Time']
                        end_time = start_time + 0.2
                        window = df_after[(df_after['Time'] >= start_time) & (df_after['Time'] <= end_time)]
                        if (window['V'] >= 0.99).all():
                            recovery_time = start_time
                            break
                recovery_times.append(recovery_time if recovery_time is not None else float('nan'))

app.PrintPlain("Simulation sweep completed.")

# Create aggregated DataFrame
results_df = pd.DataFrame(param_combinations, columns=['Fma', 'Fmb', 'Fmc', 'Fmd', 'Fel'])
# results_df['Max_P'] = max_P
# results_df['Min_P'] = min_P
# results_df['Max_Q'] = max_Q
# results_df['Min_Q'] = min_Q
# results_df['Max_V'] = max_V
# results_df['Min_V'] = min_V
# results_df['Max_I'] = max_I
# results_df['Min_I'] = min_I
# results_df['Max_f'] = max_f
# results_df['Min_f'] = min_f
results_df['VoltageDip'] = voltage_dips
results_df['RecoveryTime'] = recovery_times

# Save aggregated results
aggregated_file = output_folder + "\\AggregatedResults.csv"
results_df.to_csv(aggregated_file, index=False)
app.PrintPlain(f"Aggregated results saved to {aggregated_file}")


# --- Parallel Coordinates Plot for Voltage Dip ---
fig_dip = px.parallel_coordinates(
    results_df,
    dimensions=['Fma', 'Fmb', 'Fmc', 'Fmd', 'Fel'],
    color='VoltageDip',
    color_continuous_scale='Turbo',  # High-contrast color scale
    labels={'VoltageDip': 'Voltage Dip'},
    title='Parallel Coordinates: Voltage Dip vs Load Fractions'
)

fig_dip.show()

# --- Parallel Coordinates Plot for Recovery Time ---
fig_recovery = px.parallel_coordinates(
    results_df,
    dimensions=['Fma', 'Fmb', 'Fmc', 'Fmd', 'Fel'],
    color='RecoveryTime',
    color_continuous_scale='Plasma',  # High-contrast color scale
    labels={'RecoveryTime': 'Recovery Time (s)'},
    title='Parallel Coordinates: Recovery Time vs Load Fractions'
)

fig_recovery.show()


# Compute correlation matrix
corr = results_df[['Fma','Fmb','Fmc','Fmd','Fel','VoltageDip','RecoveryTime']].corr()

# Create heatmap
fig_corr = px.imshow(
    corr,
    text_auto=True,
    color_continuous_scale='Turbo',
    title='Correlation Matrix: Fractions vs Voltage Dip & Recovery Time'
)

# Styling: black background, white text
fig_corr.update_layout(
    plot_bgcolor='black',
    paper_bgcolor='black',
    font=dict(color='white'),
    coloraxis_colorbar=dict(title='Correlation')
)

fig_corr.show()  # Opens in browser like the parallel plots



app.PrintPlain("Script run until the end.")






