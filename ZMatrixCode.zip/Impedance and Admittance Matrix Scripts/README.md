# Script File Descriptions

Relevant considerations to execute the code:
- Files must be executed in the order they appear in this guideline.
- Files whose name begins with `0-[PF]` are **DIgSILENT PowerFactory** scripts and need to be executed from the program. Once the project is activated, go to the folder Library > Scripts and create a Python script element for each [PF] python file. Within this element, go to the tab Script and link the element to the desired Python script.
- After running all `0-[PF]` scripts inside DIgSILENT PowerFactory to generate the raw CSV files, the complete processing pipeline can be executed by running python `run_pipeline.py` from the repository root. Running this file will generate the output files `admittance_matrix.csv` and `impedance_matrix.csv` in the `data` folder.


Other considerations:
- The desired Study Case (e.g. 4708_2030KA_IP2024) must be activated in the Study Cases folder.
- [PF] files perform no filtering, no processing, no transformations, and no computations, they solely fetch raw PowerFactory data and write it directly to a CSV file.
- This workflow does not consider the grid of any country other than the Netherlands, or the impedances of the lines going to neighbouring countries.
- In the situations where no other viable alternative was found, this code relies on the solid formatting and naming of grid elements. For example, the terminals of a line element are retrieved directly from the corresponding PowerFactory elements, but if those were not available, the model uses the line name to infer the terminals (e.g. line BVW-OZN380 W is inferred to connect substation BVW380 to OZN380 by the name of the line itself). In order to avoid the influence of possible naming errors in the model, this is only done if strictly necessary.
---

### `0-[PF]ExtractSubstations.py`
Exports all PowerFactory `ElmSubstat` objects into `substations.csv`.  
The script retrieves each substation’s display name, short name (`sShort`), and area/zone metadata. It produces a clean and structured list of all substations relevant to the network model.

---

### `0-[PF]ExtractBranches.py`

Branches mostly correspond to overhead lines and cables that join the nodes (substations). They are composed of one or more line elements, terminals, and series reactors. However, PowerFactory aggregates all the necessary information into the parent branch element, so it is not necessary to retrieve the inner elements themselves.

Exports all PowerFactory `ElmBranch` objects into `branches.csv`.  
For every branch, the script records its name, physical length, positive‑sequence impedance magnitude (`Z1`), impedance angle (`phiz1`), and the associated area/zone. 

Note: reactor elements that do not belong to a branch parent element (in study case 4708_2030KA_IP2024) have all been checked and none is connected between any two substations, thus these are not relevant for developing the admittance matrix.

---

### `0-[PF]ExtractLines.py`

Not all overhead lines and cables are modelled within a Branch parent, some are independent line elements, which need to be handled separately from the Branch elements.

This script exports overhead lines and cables (`ElmLne`) to a CSV file named `lines.csv`.  
It retrieves raw line attributes, terminal/substation names, and Area/Zone references.

It applies one explicit path-based filter: only `ElmLne` objects whose immediate parent folder is `Branches` are kept and exported. If a line element sits directly within the Branches folder, it means that it is not contained in any branch element.  


From each kept line element, the script retrieves:

- `loc_name`
- `dline`
- `Z1`
- `phiz1`
- `cpArea.loc_name`
- `cpZone.loc_name`

For each line element that passes the filter, the script resolves terminals and substations:

- `bus1`: terminal 1 name  
- `bus1_substation`: substation name of terminal 1 (`cterm.cpSubstat.loc_name` attribute from PowerFactory)  
- `bus2`: terminal 2 name  
- `bus2_substation`: substation name of terminal 2  

If a terminal or substation is missing, the script writes `None`.



---

### `0-[PF]Extract3WindingTransformers.py`

This script runs inside DIgSILENT PowerFactory and exports all three‑winding transformers (ElmTr3) to the file `transformers_3W_PF.csv`, retrieving transformer attributes, bus references, and TypTr3 electrical characteristics.
It performs no filtering, no processing, no transformations, and no computations, the script solely fetches raw PowerFactory data and writes it directly to a CSV file.



From each transformer element, it retrieves:

- `loc_name`
- `typ_id`
- `outserv`
- `cpArea.loc_name`
- `cpZone.loc_name`
- `bushv`
- `busmv`


From the type element of each transformer, it retrieves:

- `utrn3_h`: rated primary voltage in kV
- `utrn3_m`: rated secondary voltage in kV
- `utrn3_l`: rated tertiary voltage in kV
- `uktr3_h`: HV-MV short-circuit voltage in %
- `pcut3_h`: HV-MV rated copper losses in kW
- `strn3_h`: HV rated apparent power in MVA
- `strn3_m`: MV rated apparent power in MVA

---

### `0-[PF]Extract2WindingTransformers.py`

This script runs inside DIgSILENT PowerFactory and exports all two‑winding transformers (ElmTr2) to the file `transformers_2W_PF.csv`. It performs no filtering, no processing, no transformations, and no computations, the script solely fetches raw PowerFactory data and writes it directly to a CSV file.


From each transformer element (`ElmTr2`), it retrieves:

- `loc_name`
- `typ_id` (type reference name)
- `outserv`
- `cpArea.loc_name`
- `cpZone.loc_name`
- `bushv`
- `buslv`

From the type element of each transformer (`TypTr2`), it retrieves:

- `utrn_h`: rated high‑voltage side voltage in kV
- `utrn_l`: rated low‑voltage side voltage in kV
- `uktr`: short‑circuit voltage in %
- `pcutr`: rated copper losses in kW
- `strn`: rated apparent power in MVA


---



### `1-Substations_Processing.py`


This script processes the raw substation export generated from PowerFactory (`substations.csv`) and produces a filtered, cleaned dataset named `substations_HV.csv`.

It performs three filtering stages:

1. **Geographical filter:** keeps only substations whose PowerFactory path (`pf_path`) contains the string `"Nederland"`.
2. **Voltage‑level filter:** keeps only substations whose `loc_name` contains one of the Dutch high‑voltage levels (`110`, `150`, `220`, or `380` kV).
3. **Data‑completeness filter:** removes substations where *all three* `sShort`, `cpArea.loc_name`, and `cpZone.loc_name` are blank or missing.

The resulting file contains only Dutch high‑voltage substations with valid metadata.

---

### `2-2TF_Processing.py`

Processes the raw 2‑winding transformer export (`transformers_2W_PF.csv`) from PowerFactory and writes a filtered result to `transformers_2W_PF_processed.csv`.


### What it reads
- **Transformers file**: `transformers_2W_PF.csv` (must include: `bushv`, `buslv`, `utrn_h (kV)`, `utrn_l (kV)`)
- **Substations reference**: `substations_HV.csv` (must include: `loc_name`)



### What it extracts
From the PF terminal path strings:
- **`hv_substation`**: name parsed from `bushv` (text before `.ElmSubstat`)
- **`lv_substation`**: name parsed from `buslv` (text before `.ElmSubstat`)

Both columns are inserted **between** `buslv` and `utrn_h (kV)` in the DataFrame.  
A normalized version of each (whitespace collapsed/trimmed) is created for matching.

### Filters applied
1. **Voltage threshold**  
   Keep only rows with (the actual limit should be 110 kV, but some transformers are rated a bit above or below that threshold, so 90 kV is selected in order to have a certain margin):
   - `utrn_h (kV) > 90`
   - `utrn_l (kV) > 90`
2. **Substation membership**  
   Keep only rows where both `hv_substation` and `lv_substation` (normalized) are present in `substations_HV.csv::loc_name`.
3. **Same‑name substations rule (with exceptions)**  
   Remove rows where `hv_substation` equals `lv_substation` (normalized), **except** when the name is:
   - `Europoort 150`: Exception because at Europoort 150 there is a two winding transformer in series with a line (ERP-TWG150 W) to Theemsweg 150. That transformer has Europoort 150 at both terminals but it must not be discarded.
   - `Utrecht Lage Weide 150`: Same situation as above.

The script prints counts for total, kept, filtered out, and quick diagnostics by reason.

### Final manual substation name correction

As a final post‑processing step, the script applies two explicit name corrections to eliminate transformer records that connect a substation to itself.

- If both transformer terminals are **Europoort 150**, the low‑voltage side is renamed to **Theemsweg 150**.
- If both transformer terminals are **Utrecht Lage Weide 150**, the low‑voltage side is renamed to **Oudenrijn 150**.

This adjustment is applied **after all filtering and impedance calculations** and only affects these known cases, ensuring no self‑connections remain in the exported transformer dataset.


### Output
- **File:** `transformers_2W_PF_processed.csv`


---

### `3-3W_TF_Processing.py`

This script post‑processes a raw PowerFactory export of **three‑winding transformers (ElmTr3)** and writes a cleaned and enriched dataset to `transformers_3W_PF_processed.csv`.

It filters the data to retain only transmission‑level transformers by requiring that **at least two of the three windings (HV, MV, LV)** have a rated voltage of **100 kV or higher**. From the PowerFactory object paths in the HV and MV terminals, it extracts clean **country** and **substation names**, removes formatting tags, and keeps only transformers where both sides are located in **Nederland**. Elements belonging to the **380kV Offshore** zone are explicitly excluded.

Using the HV winding as reference, the script computes **per‑unit resistance and reactance (Rpu, Xpu)** and corresponding **ohmic values (R\_ohm, X\_ohm)** from rated short‑circuit voltage, copper losses, rated power, and rated voltage.

An additional consistency column, **`Same substation different V`**, flags cases where the HV and MV terminals belong to the same substation name but operate at different voltage levels.

The output CSV combines the filtered transformer set with extracted substation metadata, computed impedances, and the voltage‑consistency indicator, producing a dataset suitable for impedance aggregation and grid‑level electrical analysis.






---

### `4-Lines_Filtering.py`


This script processes `lines.csv` and filters it using valid substations from `substations_HV.csv`.

It first removes irrelevant lines, which do not connect substations (containing OWIN, BATT, LOAD). It uses the `loc_name` column from `substations_HV.csv` to keep only the lines where `bus1_substation` or `bus2_substation` matches this list.

It uses the `sShort` column from `substations_HV.csv` to extract substation prefixes (letters) and voltage levels. These are used to interpret the `loc_name` of each line: the script extracts codes and voltages from the line name and matches them to substations based on prefix and voltage.

In order to check the file, it adds inferred substations (`bus1_from_names`, `bus2_from_names`), compares them with the original columns (`bus1_substation`, `bus2_substation`), and flags whether they match.

It outputs the cleaned and enriched dataset to `lines_filtered_by_substations.csv`.



Note: Lines for which different voltage levels are found in the two terminals are deleted because those are lines that are connected to a transformer, and their impedance can therefore be neglected.

---

### `5-Branches_2_vs_more_substations.py`

This script reads a PowerFactory export of **branch elements** and separates them into two datasets based on network connectivity: branches connecting **exactly two substations** and branches connecting **more than two substations**. It detects the CSV delimiter automatically, parses branch names to identify associated substations and voltage levels, and cleans ambiguous or list‑encoded substation references. Branches with invalid or missing impedance data are discarded.

Branches classified as two‑substation connections are written to `branches_2substations.csv`, while branches involving three or more substations are written to `branches_more2substations.csv`. Certain known branch name patterns are explicitly forced into the two‑substation category. The script preserves all electrical parameters and only standardizes and assigns substation columns (`substation1`–`substation4`) to produce clean, topology‑ready CSV files for subsequent grid analysis.

---

### `6-Branches_Y_to_Delta.py`

This script converts branches that connect **three substations in a star (Y) configuration** into an equivalent **delta (Δ) representation** based on their electrical impedances.

It reads a CSV file containing branches that connect **more than two substations**, extracts and standardizes branch naming information, and computes equivalent pairwise impedances suitable for network reduction and Z‑bus construction.

The script first parses each branch name to separate a common **branch parent identifier** from the explicitly listed **connected substations**, and extracts the voltage level (110, 150, 220, or 380 kV) from the branch name for labeling purposes. Electrical impedance values are converted from magnitude‑and‑angle form into complex numbers for calculation.

For each group of three branches sharing the same parent identifier, the script identifies the **common midpoint substation** and treats the configuration as a Y‑connected network. Provided the structure is unambiguous, it performs a **Y → Δ transformation**, computing three equivalent branch impedances between the outer substations.

The resulting Δ‑equivalent branches are written as new rows containing:
- the original branch parent,
- the identified midpoint substation,
- the two connected substations (including voltage suffixes),
- the equivalent impedance magnitude,
- and the equivalent impedance angle.

The final output, `branch_3ormore_y_to_delta.csv`, provides a reduced representation where multi‑terminal branches are replaced by equivalent two‑terminal connections, enabling direct use in pairwise impedance aggregation and grid‑level electrical analyses.

---

### `7-SubstationPairsBuilder.py`

This script processes multiple PowerFactory‑derived CSV files describing substations, branches, lines, and transformers, and computes the **pairwise per‑unit series impedance (R and X)** between all combinations of high‑voltage substations in the Dutch transmission grid.

It performs **data integration, impedance conversion, aggregation, and accumulation**, and produces a single CSV file, `substation_impedance_pairs.csv`, containing the total equivalent series resistance and reactance between every unordered substation pair.

The R and X values produced by this script are in per‑unit (p.u.), referenced to a base power of 1000 MVA and a voltage base equal to the nominal voltage level of the connection (110/150/220/380 kV).

The script operates in the following stages:



### Input data sources

The script reads the following CSV files:

- `substations_HV.csv`: high‑voltage substations with short and full names
- `branch_3ormore_y_to_delta.csv`: branches connecting three or more substations, already reduced to equivalent two‑terminal representations
- `branches_2substations.csv`: branches directly connecting two substations
- `lines_filtered_by_substations.csv`: transmission lines between substations
- `transformers_3W_PF_processed.csv`: processed three‑winding transformers
- `transformers_2W_PF_processed.csv`: processed two‑winding transformers

All impedances are converted to a **common base of 1000 MVA**.


### Substation preprocessing

- Loads all HV substations and builds a mapping between short names and full names.
- Generates **all unordered pairs of HV substations** using combinations.
- Initializes a table where each pair starts with zero resistance (R) and reactance (X).


### Electrical helper functions

The script defines utilities to:

- Extract voltage levels from substation names
- Identify common voltage levels between connected substations
- Convert impedance magnitude and angle to resistance and reactance
- Convert ohmic values to per‑unit values
- Accumulate impedances symmetrically for substation pairs


### Impedance accumulation by element type

For each network element type, the script:

#### 1. Multi‑terminal branches (≥3 substations)
- Converts equivalent impedance to R/X
- Uses the voltage level encoded in substation short names
- Accumulates per‑unit impedance between the affected substation pairs

#### 2. Two‑substation branches
- Extracts common voltage level from substation names
- Converts Z and phase angle to per‑unit R/X
- Adds contribution to the corresponding substation pair

#### 3. Transmission lines
- Identifies connected substations and their common voltage
- Converts line impedance to per‑unit R/X
- Accumulates impedance between substations

#### 4. Three‑winding transformers
- Uses the high‑voltage winding as impedance reference
- Converts HV‑side resistance and reactance to per‑unit
- Adds impedance between HV and MV substation terminals

#### 5. Two‑winding transformers
- Uses the high‑voltage side as the per‑unit base
- Converts transformer impedance to per‑unit
- Accumulates impedance between HV and LV substations



### Output

The final result is written to:

- `substation_impedance_pairs.csv`

Each row represents one unordered substation pair and contains:

- `substation1`
- `substation2`
- `pair_name`
- `R`: total equivalent per‑unit resistance
- `X`: total equivalent per‑unit reactance


The resulting file provides a **complete aggregated impedance matrix between all HV substations**, suitable for subsequent analyses such as Z‑bus construction, electrical distance metrics, or node criticality assessment.

---

### `8-Y_Z_matrices_builder.py`

This script constructs the **nodal admittance matrix (Y‑bus)** of the transmission grid from a file containing **pairwise per‑unit impedances** between substations, and then derives the corresponding **impedance matrix (Z‑bus)**.

It first reads `substation_impedance_pairs.csv`, collects all unique substation names, and initializes a square complex‑valued admittance matrix with substations as both rows and columns. For each substation pair, the script converts the series impedance \(R + jX\) into an admittance and inserts it into the Y‑bus by subtracting the admittance from the off‑diagonal entries and accumulating it on the two diagonals.

Substations with **no electrical connections** (rows and columns with zero total admittance) are removed from the matrix. A specified **reference (slack) bus**, `Eemshaven 380`, is then eliminated by dropping its row and column, yielding a reduced, invertible admittance matrix.

Finally, the script computes the **impedance matrix (Z‑bus)** by inverting the reduced Y‑bus and saves both the connected admittance matrix and the resulting impedance matrix to CSV files. The outputs are suitable for downstream analyses such as electrical distance calculations or node importance assessment.

The resulting matrices are stored in `admittance_matrix.csv` and `impedance_matrix.csv`.