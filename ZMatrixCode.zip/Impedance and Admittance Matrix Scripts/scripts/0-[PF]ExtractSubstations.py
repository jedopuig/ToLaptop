import powerfactory as pf
import pandas as pd
from pathlib import Path

app = pf.GetApplication()
app.PrintInfo("Starting to export substations (ElmSubstat) to CSV...")

# ----------------------------------------------------------
# LOAD MODEL OBJECTS
# ----------------------------------------------------------
subs = app.GetCalcRelevantObjects('*.ElmSubstat') or []

app.PrintInfo("Detected substations:")
app.PrintInfo(subs)

# ----------------------------------------------------------
# EXPORT SUBSTATIONS TO CSV
# ----------------------------------------------------------
# Repository root = parent of the folder where this script lives
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent   # assumes scripts live in repo-root/scripts/

# Common CSV output folder inside the repo
output_dir = REPO_ROOT / "data" / "csv"
output_dir.mkdir(parents=True, exist_ok=True)

output_file = output_dir / "substations.csv"

# Added new column: pf_path (from GetFullName)
columns = [
    "loc_name",
    "sShort",              # existing
    "pf_path",             # <-- NEW: full PF path
    "cpArea.loc_name",
    "cpZone.loc_name",
]

def get_attr_chain(obj, attr_path):
    """Safely resolve dotted attribute paths like cpArea.loc_name."""
    cur = obj
    for part in attr_path.split("."):
        if cur is None:
            return None
        cur = getattr(cur, part, None)
    return cur

rows = []

for s in subs:
    row = {}

    # Basic attributes
    row["loc_name"] = getattr(s, "loc_name", None)
    row["cpArea.loc_name"] = get_attr_chain(s, "cpArea.loc_name")
    row["cpZone.loc_name"] = get_attr_chain(s, "cpZone.loc_name")

    # Short name via GetAttribute
    try:
        short = s.GetAttribute("sShort")
        if not short:
            short = s.GetAttribute("sShort ")
    except:
        short = None
    row["sShort"] = short

    # NEW: PF full path (like in your line-export example)
    try:
        row["pf_path"] = s.GetFullName()  # plain human-readable path
    except:
        row["pf_path"] = None

    rows.append(row)

df = pd.DataFrame(rows, columns=columns)
df.to_csv(output_file, index=False, encoding="utf-8-sig")

app.PrintInfo(f"Substation list exported to: {output_file}")
app.PrintInfo(f"Total substations exported: {len(df)}")