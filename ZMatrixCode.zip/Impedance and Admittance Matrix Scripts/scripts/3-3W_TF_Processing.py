import pandas as pd
import numpy as np
import re
from pathlib import Path

# ----------------------------------------------------------
# SETTINGS
# ----------------------------------------------------------


# Script location
SCRIPT_DIR = Path(__file__).resolve().parent

# Repository root (scripts/ → repo-root/)
REPO_ROOT = SCRIPT_DIR.parent

# Shared CSV directory
DATA_DIR = REPO_ROOT / "data" / "csv"

input_file = DATA_DIR / "transformers_3W_PF.csv"
output_file = DATA_DIR / "transformers_3W_PF_processed.csv"


VOLTAGE_THRESHOLD = 100.0  # kV

# Exact header names (as confirmed)
COL_UH  = "utrn3_h (kV)"
COL_UM  = "utrn3_m (kV)"
COL_UL  = "utrn3_l (kV)"
COL_UK  = "uktr3_h (%)"
COL_PCU = "pcut3_h (kW)"
COL_SH  = "strn3_h (MVA)"
COL_SM  = "strn3_m (MVA)"

# ----------------------------------------------------------
# HELPERS
# ----------------------------------------------------------

def strip_tags(text: str) -> str:
    """Remove <l3> or any <...> tags that may wrap PF object paths."""
    if text is None:
        return None
    return re.sub(r"<[^>]*>", "", str(text))

def extract_before(text: str, marker: str):
    """
    Extract the element immediately before a given marker.
    Example: '...\\Nederland.ElmNet\\...' -> 'Nederland' for marker='.ElmNet'
    """
    if text is None:
        return None
    cleaned = strip_tags(text)
    m = re.search(rf"([^\\/:]+){re.escape(marker)}", cleaned)
    return m.group(1) if m else None

def extract_country(path_str: str):
    return extract_before(path_str, ".ElmNet")

def extract_substation(path_str: str):
    return extract_before(path_str, ".ElmSubstat")

# --- Parsing and comparison for "Same substation different V" ---

_name_voltage_re = re.compile(r"^\s*([^\d]+?)\s*(\d{2,3})\s*$")

def parse_name_and_voltage(s: str):
    """
    Parse strings like 'Bergum 220' -> ('bergum', 220)
    Returns (normalized_name, int_voltage) or (None, None) if it doesn't match.
    """
    if not isinstance(s, str):
        return (None, None)
    m = _name_voltage_re.match(s)
    if not m:
        return (None, None)
    name = m.group(1).strip().casefold()  # normalize name for comparison
    try:
        v = int(m.group(2))
    except Exception:
        v = None
    return (name if name else None, v)

def same_substation_different_voltage(a: str, b: str) -> str:
    """
    Returns "Yes" iff:
      - names are equal (case-insensitive, trimmed), and
      - both voltages are present and different.
    Else "No".
    """
    name_a, v_a = parse_name_and_voltage(a)
    name_b, v_b = parse_name_and_voltage(b)
    if name_a is None or name_b is None:
        return "No"
    if name_a != name_b:
        return "No"
    if v_a is None or v_b is None:
        return "No"
    return "Yes" if v_a != v_b else "No"

# ----------------------------------------------------------
# LOAD CSV
# ----------------------------------------------------------

df = pd.read_csv(input_file, encoding="utf-8-sig")

# ----------------------------------------------------------
# VOLTAGE FILTER: keep rows where ≥2 of (UH, UM, UL) ≥ 100 kV
# ----------------------------------------------------------

for col in [COL_UH, COL_UM, COL_UL]:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

present_voltage_cols = [c for c in [COL_UH, COL_UM, COL_UL] if c in df.columns]

if present_voltage_cols:
    count_ge = (df[present_voltage_cols] >= VOLTAGE_THRESHOLD).sum(axis=1)
    before_v = len(df)
    df = df[count_ge >= 2].reset_index(drop=True)
    print(f"Voltage filter: kept {len(df)} of {before_v} rows (>= {VOLTAGE_THRESHOLD} kV in at least two windings).")
else:
    print("WARNING: No rated voltage columns found. Skipping the voltage filter.")

# ----------------------------------------------------------
# INSERT bushv_* right after 'bushv'
# ----------------------------------------------------------

if "bushv" in df.columns:
    bushv_idx = df.columns.get_loc("bushv") + 1
    df.insert(bushv_idx, "bushv_country", df["bushv"].apply(extract_country))
    df.insert(bushv_idx + 1, "bushv_substation", df["bushv"].apply(extract_substation))
else:
    print("WARNING: 'bushv' column not found; skipping bushv_* insertions.")

# ----------------------------------------------------------
# INSERT busmv_* right after 'busmv'
# ----------------------------------------------------------

if "busmv" in df.columns:
    busmv_idx = df.columns.get_loc("busmv") + 1
    df.insert(busmv_idx, "busmv_country", df["busmv"].apply(extract_country))
    df.insert(busmv_idx + 1, "busmv_substation", df["busmv"].apply(extract_substation))
else:
    print("WARNING: 'busmv' column not found; skipping busmv_* insertions.")

# ----------------------------------------------------------
# KEEP ONLY Nederland on both sides
# ----------------------------------------------------------

if "bushv_country" in df.columns and "busmv_country" in df.columns:
    before_cty = len(df)
    df = df[(df["bushv_country"] == "Nederland") & (df["busmv_country"] == "Nederland")].reset_index(drop=True)
    print(f"Country filter: kept {len(df)} of {before_cty} rows with both sides in Nederland.")
else:
    print("WARNING: bushv_country / busmv_country columns missing; skipping country filter.")

# ----------------------------------------------------------
# REMOVE cpZone.loc_name == '380kV Offshore'
# ----------------------------------------------------------

if "cpZone.loc_name" in df.columns:
    before_zone = len(df)
    df = df[df["cpZone.loc_name"] != "380kV Offshore"].reset_index(drop=True)
    print(f"Zone filter: kept {len(df)} of {before_zone} rows after removing '380kV Offshore'.")
else:
    print("WARNING: 'cpZone.loc_name' not in columns; skipping zone filter.")

# ----------------------------------------------------------
# HV–MV IMPEDANCE (ONLY) — referred to HV
# S_base = strn3_h (MVA)
# ----------------------------------------------------------

# Ensure numeric inputs
for col in [COL_UK, COL_PCU, COL_SH, COL_UH]:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

# HV MVA base
S_base = df[COL_SH].where(df[COL_SH] > 0, np.nan)

# Per-unit values (add FIRST)
Z_pu = df[COL_UK] / 100.0
R_pu = df[COL_PCU] / (S_base * 1000.0)  # kW / kVA
X_pu = np.sqrt(np.clip(Z_pu**2 - R_pu**2, a_min=0.0, a_max=None))

df["Rpu_hm"] = R_pu
df["Xpu_hm"] = X_pu

# HV-referred ohmic values (add AFTER per-unit)
Z_base_HV = (df[COL_UH] ** 2) / S_base  # kV^2 / MVA = ohm
df["R_ohm_h"] = R_pu * Z_base_HV
df["X_ohm_h"] = X_pu * Z_base_HV

# ----------------------------------------------------------
# Insert "Same substation different V" after 'busmv_substation'
# ----------------------------------------------------------

if "busmv_substation" in df.columns and "bushv_substation" in df.columns:
    insert_idx = df.columns.get_loc("busmv_substation") + 1
    df.insert(
        insert_idx,
        "Same substation different V",
        [same_substation_different_voltage(a, b) for a, b in zip(df["bushv_substation"], df["busmv_substation"])]
    )
else:
    print("WARNING: Cannot add 'Same substation different V' because substation columns are missing.")

# ----------------------------------------------------------
# SAVE OUTPUT
# ----------------------------------------------------------

df.to_csv(output_file, index=False, encoding="utf-8-sig")

print(f"\nProcessed CSV created at:\n{output_file}")
print(f"Final rows: {len(df)}")
print("Added columns: bushv_country, bushv_substation, busmv_country, busmv_substation, 'Same substation different V', Rpu_hm, Xpu_hm, R_ohm_h, X_ohm_h")