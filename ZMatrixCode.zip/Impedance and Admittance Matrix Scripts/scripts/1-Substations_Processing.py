import pandas as pd
from pathlib import Path
import numpy as np

# ----------------------------------------------------------
# SETTINGS
# ----------------------------------------------------------


# Script location
SCRIPT_DIR = Path(__file__).resolve().parent

# Repository root (scripts/ → repo-root/)
REPO_ROOT = SCRIPT_DIR.parent

# Shared CSV directory
DATA_DIR = REPO_ROOT / "data" / "csv"

input_file = DATA_DIR / "substations.csv"
output_file = DATA_DIR / "substations_HV.csv"


# ----------------------------------------------------------
# LOAD CSV
# ----------------------------------------------------------

df = pd.read_csv(input_file, encoding="utf-8-sig")

# ----------------------------------------------------------
# FILTER: keep only rows where pf_path contains "Nederland"
# ----------------------------------------------------------

df = df[df["pf_path"].astype(str).str.contains("Nederland", na=False)]

# ----------------------------------------------------------
# FILTER: remove rows where pf_path contains "Offshore"
# ----------------------------------------------------------

df = df[~df["pf_path"].astype(str).str.contains("Offshore", case=False, na=False)]

# ----------------------------------------------------------
# FILTER: Keep only rows where loc_name contains 110, 150, 220, or 380
# ----------------------------------------------------------

pattern = r"(110|150|220|380)"
df = df[df["loc_name"].astype(str).str.contains(pattern, regex=True, na=False)]

# ----------------------------------------------------------
# FILTER: Remove row ONLY IF all 3 columns are blank
# ----------------------------------------------------------

def is_blank(val):
    """Returns True for empty string, whitespace-only string, or NaN."""
    if pd.isna(val):
        return True
    if isinstance(val, str) and val.strip() == "":
        return True
    return False

mask_remove = (
    df["sShort"].apply(is_blank)
    & df["cpArea.loc_name"].apply(is_blank)
    & df["cpZone.loc_name"].apply(is_blank)
)

df = df[~mask_remove].reset_index(drop=True)

# ----------------------------------------------------------
# SAVE OUTPUT
# ----------------------------------------------------------

df.to_csv(output_file, index=False, encoding="utf-8-sig")

print("Created file:", output_file)
print("Final rows:", len(df))