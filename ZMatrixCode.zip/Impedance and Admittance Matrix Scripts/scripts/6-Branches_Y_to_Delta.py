import pandas as pd
import numpy as np
import cmath
import re



# Script location
SCRIPT_DIR = Path(__file__).resolve().parent

# Repository root (scripts/ → repo-root/)
REPO_ROOT = SCRIPT_DIR.parent

# Shared CSV directory
DATA_DIR = REPO_ROOT / "data" / "csv"

input_file = DATA_DIR / "branches_more2substations.csv"
df = pd.read_csv(input_file)

output_file_delta = DATA_DIR / "branch_3ormore_y_to_delta.csv"


# ----------------------------------------------------------
# Extract pre-parentheses part and inside-parentheses part
# ----------------------------------------------------------
def split_loc_name(loc):
    m = re.search(r"^(.*?)\s*\(([^)]+)\)", loc)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    else:
        return loc.strip(), None

# ----------------------------------------------------------
# Extract voltage level from loc_name (110, 150, 220, 380)
# ----------------------------------------------------------
def extract_voltage(loc):
    # Find any of the known voltage numbers
    m = re.search(r"(110|150|220|380)", loc)
    return m.group(1) if m else ""

# ----------------------------------------------------------
# Convert magnitude+angle → complex
# ----------------------------------------------------------
def polar_to_complex(mag, angle_deg):
    return cmath.rect(mag, np.deg2rad(angle_deg))

# ----------------------------------------------------------
# Convert complex → magnitude+angle
# ----------------------------------------------------------
def complex_to_polar(z):
    return abs(z), np.rad2deg(cmath.phase(z))

# ----------------------------------------------------------
# Y → Δ conversion
# ----------------------------------------------------------
def y_to_delta(ZA, ZB, ZC):
    Z_ab = (ZA*ZB + ZB*ZC + ZC*ZA) / ZC
    Z_bc = (ZA*ZB + ZB*ZC + ZC*ZA) / ZA
    Z_ca = (ZA*ZB + ZB*ZC + ZC*ZA) / ZB
    return Z_ab, Z_bc, Z_ca

# ----------------------------------------------------------
# Load file
# ----------------------------------------------------------


# ----------------------------------------------------------
# Create new columns
# ----------------------------------------------------------
df["branch_parent"], df["connected_substations"] = zip(
    *df["loc_name"].map(split_loc_name)
)

# Extract voltage level from each row for later use
df["voltage"] = df["loc_name"].map(extract_voltage)


# ----------------------------------------------------------
# Create Y→Δ results
# ----------------------------------------------------------
rows_out = []

for bp, group in df.groupby("branch_parent"):

    if len(group) != 3:
        continue

    conns = group["connected_substations"].tolist()
    subs_pairs = [c.split("-") for c in conns]

    common = set(subs_pairs[0]).intersection(subs_pairs[1], subs_pairs[2])

    if len(common) != 1:
        continue

    midpoint = list(common)[0]

    if midpoint in bp:
        continue

    Z_complex = []
    terminals = []
    voltages = []   # also store voltage levels for each terminal

    for _, row in group.iterrows():
        sA, sB = row["connected_substations"].split("-")
        other = sA if sB == midpoint else sB
        terminals.append(other)
        voltages.append(row["voltage"])  # take voltage from that same row
        Z_complex.append(polar_to_complex(row["Z1"], row["phiz1"]))

    ZA, ZB, ZC = Z_complex
    A, B, C = terminals
    VA, VB, VC = voltages

    Z_ab, Z_bc, Z_ca = y_to_delta(ZA, ZB, ZC)

    # Add voltage level suffix to names
    A2 = f"{A}{VA}"
    B2 = f"{B}{VB}"
    C2 = f"{C}{VC}"

    for (s1, s2, Z) in [(A2, B2, Z_ab), (B2, C2, Z_bc), (C2, A2, Z_ca)]:
        mag, ang = complex_to_polar(Z)
        rows_out.append({
            "branch_parent": bp,
            "midpoint": midpoint,
            "substation1": s1,
            "substation2": s2,
            "Z1_equiv": mag,
            "phi_equiv": ang
        })

# ----------------------------------------------------------
# Save Y→Δ file
# ----------------------------------------------------------


df_delta = pd.DataFrame(rows_out)
df_delta.to_csv(output_file_delta, index=False)

print("Created:", output_file_delta)