import powerfactory as pf
import pandas as pd
from pathlib import Path
import re

app = pf.GetApplication()
app.PrintInfo("Starting to export line elements (ElmLne) to CSV...")

# ----------------------------------------------------------
# LOAD MODEL OBJECTS
# ----------------------------------------------------------
lines = app.GetCalcRelevantObjects('*.ElmLne') or []
app.PrintInfo(f"Detected {len(lines)} total line objects.")

# ----------------------------------------------------------
# OUTPUT SETTINGS
# ----------------------------------------------------------
# Repository root = parent of the folder where this script lives
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent   # assumes scripts live in repo-root/scripts/

# Common CSV output folder inside the repo
output_dir = REPO_ROOT / "data" / "csv"
output_dir.mkdir(parents=True, exist_ok=True)

output_file = output_dir / "lines.csv"

columns = [
    "loc_name",
    "bus1",
    "bus1_substation",
    "bus2",
    "bus2_substation",
    "dline",
    "Z1",
    "phiz1",
    "cpArea.loc_name",
    "cpZone.loc_name",
]

# Small helpers for attributes (not for filtering)
def get_attr_chain(obj, attr_path: str):
    cur = obj
    for part in attr_path.split("."):
        if cur is None:
            return None
        cur = getattr(cur, part, None)
    return cur

def get_terminal_info(bus_attr):
    try:
        if not bus_attr:
            return None, None
        term = bus_attr.cterm
        if not term:
            return None, None
        term_name = term.loc_name
        substat = term.cpSubstat.loc_name if term.cpSubstat else None
        return term_name, substat
    except Exception:
        return None, None

# ----------------------------------------------------------
# MAIN LOOP with INLINE, EXPLICIT FILTER
# ----------------------------------------------------------
rows = []
kept = 0
removed = 0

ZERO_WIDTH = re.compile(r"[\u200B-\u200F\u202A-\u202E\u2066-\u2069]")

app.PrintInfo("----- Decisions for ALL ElmLne objects -----")
for ln in lines:
    try:
        full = ln.GetFullName()
    except Exception:
        full = ""

    path_raw = full if isinstance(full, str) else ""
    s = path_raw.replace("/", "\\").strip().strip("'").strip('"')
    s = ZERO_WIDTH.sub("", s)

    for sep in ("／", "∕", "⁄", "∖", "﹨", "＼"):
        s = s.replace(sep, "\\")
    s = re.sub(r"\\{2,}", r"\\", s)

    keep_this = False
    parent_raw = ""
    parent_base = ""
    last_token = ""

    last_idx = s.rfind("\\")
    if last_idx == -1:
        removed += 1
        continue

    left = s[:last_idx]
    last_token = s[last_idx + 1:]

    parent_idx = left.rfind("\\")
    parent_raw = left[parent_idx + 1:] if parent_idx != -1 else left

    parent_base = parent_raw.strip().rstrip(" .")
    if "." in parent_base:
        parent_base = parent_base.split(".", 1)[0]
    parent_base_lc = parent_base.lower()

    if parent_base_lc == "branches":
        keep_this = True

    if not keep_this:
        removed += 1
        continue

    kept += 1

    row = {}
    row["loc_name"] = getattr(ln, "loc_name", None)
    row["cpArea.loc_name"] = get_attr_chain(ln, "cpArea.loc_name")
    row["cpZone.loc_name"] = get_attr_chain(ln, "cpZone.loc_name")

    bus1_name, bus1_substat = get_terminal_info(ln.bus1)
    row["bus1"] = bus1_name
    row["bus1_substation"] = bus1_substat

    bus2_name, bus2_substat = get_terminal_info(ln.bus2)
    row["bus2"] = bus2_name
    row["bus2_substation"] = bus2_substat

    try:
        row["dline"] = ln.GetAttribute("dline")
    except Exception:
        row["dline"] = getattr(ln, "dline", None)

    try:
        row["Z1"] = ln.GetAttribute("Z1")
    except Exception:
        row["Z1"] = getattr(ln, "Z1", None)

    try:
        row["phiz1"] = ln.GetAttribute("phiz1")
    except Exception:
        row["phiz1"] = getattr(ln, "phiz1", None)

    rows.append(row)

app.PrintInfo("---------------------------------------------------------------")

# ----------------------------------------------------------
# WRITE CSV (with sorting: same-substation rows at the bottom)
# ----------------------------------------------------------
df = pd.DataFrame(rows, columns=columns)

# Flag rows where both substations are non-null AND equal
df["_same_substation"] = (
    df["bus1_substation"].notna()
    & df["bus2_substation"].notna()
    & df["bus1_substation"].eq(df["bus2_substation"])
)

# Sort so False (different substations) come first, True (same) go last
df = df.sort_values(by="_same_substation", ascending=True, kind="stable")

# Drop helper column before exporting
df = df.drop(columns=["_same_substation"])

df.to_csv(output_file, index=False, encoding="utf-8-sig")

app.PrintInfo(f"Line list exported to: {output_file}")
app.PrintInfo(f"Total lines KEPT (direct children of 'Branches'): {kept}")
app.PrintInfo(f"Total lines REMOVED: {removed}")