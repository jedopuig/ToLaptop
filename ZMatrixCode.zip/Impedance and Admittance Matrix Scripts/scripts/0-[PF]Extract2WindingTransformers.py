import powerfactory as pf
import pandas as pd
from pathlib import Path

app = pf.GetApplication()
app.PrintInfo("Starting to export 2-winding transformers (ElmTr2) to CSV...")

# ----------------------------------------------------------
# LOAD OBJECTS
# ----------------------------------------------------------
tr2 = app.GetCalcRelevantObjects("*.ElmTr2") or []
app.PrintInfo(f"Detected 2-winding transformers: {len(tr2)}")

# ----------------------------------------------------------
# EXPORT SETTINGS
# ----------------------------------------------------------

# Repository root = parent of the folder where this script lives
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent   # assumes scripts live in repo-root/scripts/

# Common CSV output folder inside the repo
output_dir = REPO_ROOT / "data" / "csv"
output_dir.mkdir(parents=True, exist_ok=True)

output_file = output_dir / "transformers_2W_PF.csv"


# CSV columns (all raw attributes retrieved)
columns = [
    # ElmTr2 attributes
    "loc_name",
    "typ_id",
    "outserv",
    "cpArea.loc_name",
    "cpZone.loc_name",

    # Terminals (HV/LV)
    "bushv",
    "buslv",

    # TypTr2 attributes
    "utrn_h (kV)",
    "utrn_l (kV)",
    "uktr (%)",
    "pcutr (kW)",
    "strn (MVA)",
]

# Helper: safe dotted attribute getter
def get_attr_chain(obj, attr_path):
    cur = obj
    for part in attr_path.split("."):
        if cur is None:
            return None
        cur = getattr(cur, part, None)
    return cur

# Helper: safe attribute getter that tries GetAttribute first
def pf_attr(obj, name):
    if obj is None:
        return None
    try:
        return obj.GetAttribute(name)
    except:
        return getattr(obj, name, None)

rows = []

# ----------------------------------------------------------
# MAIN LOOP — RAW EXPORT ONLY
# ----------------------------------------------------------
for tr in tr2:
    row = {}

    # ElmTr2 attributes
    row["loc_name"] = getattr(tr, "loc_name", None)
    row["outserv"] = pf_attr(tr, "outserv")

    # TypTr2 reference name
    try:
        row["typ_id"] = tr.typ_id.loc_name if tr.typ_id else None
    except:
        row["typ_id"] = None

    # Area/Zone
    row["cpArea.loc_name"] = get_attr_chain(tr, "cpArea.loc_name")
    row["cpZone.loc_name"] = get_attr_chain(tr, "cpZone.loc_name")

    # Transformer terminals (HV/LV)
    row["bushv"] = pf_attr(tr, "bushv")
    row["buslv"] = pf_attr(tr, "buslv")

    # ------------------------------------------------------
    # TypTr2 attributes
    # ------------------------------------------------------
    typ = getattr(tr, "typ_id", None)

    row["utrn_h (kV)"] = pf_attr(typ, "utrn_h")
    row["utrn_l (kV)"] = pf_attr(typ, "utrn_l")
    row["uktr (%)"]    = pf_attr(typ, "uktr")
    row["pcutr (kW)"]  = pf_attr(typ, "pcutr")
    row["strn (MVA)"]  = pf_attr(typ, "strn")

    rows.append(row)

# Write CSV
df = pd.DataFrame(rows, columns=columns)
df.to_csv(output_file, index=False, encoding="utf-8-sig")

app.PrintInfo(f"2-winding transformer list exported to: {output_file}")
app.PrintInfo(f"Total exported: {len(df)}")