import pandas as pd
from pathlib import Path
import re

# ---------- Configuration ----------
BASE_DIR = Path(
    r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Node Importance\Zbus Matrix\NL Grid\Whole Grid"
)
IN_TXF = BASE_DIR / "transformers_2W_PF.csv"
IN_SUBS = BASE_DIR / "substations_HV.csv"
OUT_TXF = BASE_DIR / "transformers_2W_PF_processed.csv"

# ---------- Helpers ----------
def load_csv_best_effort(path, must_have_cols=None):
    attempts = [
        dict(sep=",", encoding="utf-8-sig"),
        dict(sep="\t", encoding="utf-8-sig"),
        dict(sep=",", encoding="utf-8"),
        dict(sep="\t", encoding="utf-8"),
    ]
    last_err = None
    for opt in attempts:
        try:
            df = pd.read_csv(path, **opt)
            if must_have_cols:
                missing = [c for c in must_have_cols if c not in df.columns]
                if missing:
                    last_err = f"Missing columns {missing} with {opt}"
                    continue
            return df
        except Exception as e:
            last_err = e
    raise RuntimeError(f"Could not read {path} with common formats; last error: {last_err}")

def norm_name(s):
    if not isinstance(s, str):
        return ""
    return re.sub(r"\s+", " ", s).strip()

def to_float(x):
    try:
        return float(x)
    except Exception:
        return None

# ---------- Load input files ----------
print(f"[INFO] Reading: {IN_TXF}")
txf = load_csv_best_effort(
    IN_TXF,
    must_have_cols=[
        "bushv", "buslv", "utrn_h (kV)", "utrn_l (kV)"
    ],
)

print(f"[INFO] Reading: {IN_SUBS}")
subs = load_csv_best_effort(IN_SUBS, must_have_cols=["loc_name"])

# ---------- SAFETY: remove any duplicate-named columns ----------
if txf.columns.duplicated().any():
    txf = txf.loc[:, ~txf.columns.duplicated()]

# ---------- Extract clean substation names ----------
def extract_station(s):
    if not isinstance(s, str):
        return ""
    s = s.replace("<l3>", "").replace("</l3>", "")
    m = re.search(r"\\([^\\]+)\.ElmSubstat", s)
    return m.group(1).strip() if m else ""

hv_clean = txf["bushv"].astype(str).map(extract_station)
lv_clean = txf["buslv"].astype(str).map(extract_station)

# ---------- Insert new columns ----------
for col in ("hv_substation", "lv_substation"):
    if col in txf.columns:
        txf.drop(columns=[col], inplace=True)

insert_pos = txf.columns.get_loc("buslv") + 1
txf.insert(insert_pos, "hv_substation", hv_clean)
txf.insert(insert_pos + 1, "lv_substation", lv_clean)

# ---------- Normalize station names ----------
txf["hv_substation_norm"] = txf["hv_substation"].map(norm_name)
txf["lv_substation_norm"] = txf["lv_substation"].map(norm_name)

subs_set = set(subs["loc_name"].astype(str).map(norm_name).tolist())

# ---------- Numeric filter ----------
txf["utrn_h_num"] = txf["utrn_h (kV)"].apply(to_float)
txf["utrn_l_num"] = txf["utrn_l (kV)"].apply(to_float)

cond_voltage = (txf["utrn_h_num"] > 90.0) & (txf["utrn_l_num"] > 90.0)

# ---------- Membership filter ----------
cond_membership = txf["hv_substation_norm"].isin(subs_set) & txf["lv_substation_norm"].isin(subs_set)

# ---------- Exceptions for same-name substations ----------
exceptions = {"Europoort 150", "Utrecht Lage Weide 150"}

cond_not_same = (
    (txf["hv_substation_norm"] != txf["lv_substation_norm"]) |
    (txf["hv_substation_norm"].isin(exceptions))
)

# ---------- Apply combined filter ----------
before_cnt = len(txf)
txf_filtered = txf[cond_voltage & cond_membership & cond_not_same].copy()
after_cnt = len(txf_filtered)


# =====================================================================
# ---------- Calculate per-unit and ohmic transformer impedances ----------
# =====================================================================

# Ensure required columns exist
required_cols = ["utrn_h (kV)", "strn (MVA)", "uktr (%)", "pcutr (kW)"]
for col in required_cols:
    if col not in txf_filtered.columns:
        txf_filtered[col] = None

# Compute R_pu, X_pu, R_ohm, X_ohm
def compute_impedance(row):
    try:
        V_kv = float(row["utrn_h (kV)"])
        S_MVA = float(row["strn (MVA)"])
        uk = float(row["uktr (%)"]) / 100.0
        pcu_kw = float(row["pcutr (kW)"])

        S = S_MVA * 1_000_000
        V = V_kv * 1000

        # Per-unit R
        R_pu = (pcu_kw / 1000.0) / S_MVA

        # Per-unit X
        X_pu = (uk**2 - R_pu**2) ** 0.5 if uk > R_pu else None

        Z_base = V * V / S

        R_ohm = R_pu * Z_base if R_pu is not None else None
        X_ohm = X_pu * Z_base if X_pu is not None else None

        return pd.Series([R_pu, X_pu, R_ohm, X_ohm])

    except:
        return pd.Series([None, None, None, None])

txf_filtered[["R_pu", "X_pu", "R_ohm", "X_ohm"]] = txf_filtered.apply(compute_impedance, axis=1)

# =====================================================================


# ---------- Drop helper columns ----------
drop_cols = ["hv_substation_norm", "lv_substation_norm", "utrn_h_num", "utrn_l_num"]
txf_filtered.drop(columns=[c for c in drop_cols if c in txf_filtered.columns], inplace=True)

print(f"[INFO] Transformers total: {before_cnt}")
print(f"[INFO] Kept (filters applied): {after_cnt}")
print(f"[INFO] Filtered out: {before_cnt - after_cnt}")


# =====================================================
# ---------- FINAL MANUAL NAME CORRECTIONS ----------
# =====================================================

# Case 1: Europoort 150 -> replace one side with Theemsweg 150
mask_europoort = (
    (txf_filtered["hv_substation"] == "Europoort 150") &
    (txf_filtered["lv_substation"] == "Europoort 150")
)
txf_filtered.loc[mask_europoort, "lv_substation"] = "Theemsweg 150"

# Case 2: Utrecht Lage Weide 150 -> replace one side with Oudenrijn 150
mask_utrecht = (
    (txf_filtered["hv_substation"] == "Utrecht Lage Weide 150") &
    (txf_filtered["lv_substation"] == "Utrecht Lage Weide 150")
)
txf_filtered.loc[mask_utrecht, "lv_substation"] = "Oudenrijn 150"

# ---------- Save output ----------
BASE_DIR.mkdir(parents=True, exist_ok=True)
txf_filtered.to_csv(OUT_TXF, index=False, encoding="utf-8-sig")
print(f"[DONE] Wrote: {OUT_TXF}")