import pandas as pd
import numpy as np
import itertools
import os
import re

# =====================================================
# Paths
# =====================================================

# Script location
SCRIPT_DIR = Path(__file__).resolve().parent

# Repository root (scripts/ → repo-root/)
REPO_ROOT = SCRIPT_DIR.parent

# Shared CSV directory
DATA_DIR = REPO_ROOT / "data" / "csv"

SUBSTATION_FILE     = DATA_DIR / "substations_HV.csv"
BRANCH_3PLUS_FILE   = DATA_DIR / "branch_3ormore_y_to_delta.csv"
BRANCH_2SUB_FILE    = DATA_DIR / "branches_2substations.csv"
LINES_FILE          = DATA_DIR / "lines_filtered_by_substations.csv"
TRANSF_3W_FILE      = DATA_DIR / "transformers_3W_PF_processed.csv"
TRANSF_2W_FILE      = DATA_DIR / "transformers_2W_PF_processed.csv"
OUTPUT_FILE         = DATA_DIR / "substation_impedance_pairs.csv"


S_BASE_MVA = 1000.0

# =====================================================
# Helper functions
# =====================================================
def extract_voltage_from_short(short_name):
    m = re.search(r"(\d+)$", str(short_name))
    if not m:
        raise ValueError(f"No voltage found in {short_name}")
    return float(m.group(1))


def extract_common_voltage_from_names(name1, name2):
    valid = {"110", "150", "220", "380"}
    nums1 = set(re.findall(r"\d+", str(name1)))
    nums2 = set(re.findall(r"\d+", str(name2)))
    common = nums1 & nums2 & valid
    if len(common) != 1:
        return None
    return float(common.pop())


def z_to_rx_ohm(Z, phi_deg):
    phi = np.deg2rad(phi_deg)
    return Z * np.cos(phi), Z * np.sin(phi)


def rx_ohm_to_pu(R, X, V_kV):
    Z_base = (V_kV ** 2) / S_BASE_MVA
    return R / Z_base, X / Z_base


def add_to_pairs(pairs_df, s1, s2, R_pu, X_pu):
    mask = (
        ((pairs_df["substation1"] == s1) & (pairs_df["substation2"] == s2)) |
        ((pairs_df["substation1"] == s2) & (pairs_df["substation2"] == s1))
    )
    if mask.any():
        pairs_df.loc[mask, ["R", "X"]] += [R_pu, X_pu]


# =====================================================
# Load substations (HV)
# =====================================================
subs = pd.read_csv(SUBSTATION_FILE)
short_to_full = dict(zip(subs["sShort"], subs["loc_name"]))

# =====================================================
# Create all unordered HV substation pairs
# =====================================================
pairs = list(itertools.combinations(subs["loc_name"], 2))
pairs_df = pd.DataFrame(pairs, columns=["substation1", "substation2"])
pairs_df["pair_name"] = pairs_df["substation1"] + " - " + pairs_df["substation2"]
pairs_df["R"] = 0.0
pairs_df["X"] = 0.0

# =====================================================
# 1) branch_3ormore_y_to_delta.csv
# =====================================================
for _, r in pd.read_csv(BRANCH_3PLUS_FILE).iterrows():
    if r["substation1"] not in short_to_full or r["substation2"] not in short_to_full:
        continue
    s1 = short_to_full[r["substation1"]]
    s2 = short_to_full[r["substation2"]]
    R_ohm, X_ohm = z_to_rx_ohm(r["Z1_equiv"], r["phi_equiv"])
    V_kV = extract_voltage_from_short(r["substation1"])
    add_to_pairs(pairs_df, s1, s2, *rx_ohm_to_pu(R_ohm, X_ohm, V_kV))

# =====================================================
# 2) branches_2substations.csv
# =====================================================
for _, r in pd.read_csv(BRANCH_2SUB_FILE).iterrows():
    V_kV = extract_common_voltage_from_names(r["substation1"], r["substation2"])
    if V_kV is None:
        continue
    R_ohm, X_ohm = z_to_rx_ohm(r["Z1"], r["phiz1"])
    add_to_pairs(
        pairs_df,
        r["substation1"],
        r["substation2"],
        *rx_ohm_to_pu(R_ohm, X_ohm, V_kV),
    )

# =====================================================
# 3) lines_filtered_by_substations.csv
# =====================================================
for _, r in pd.read_csv(LINES_FILE).iterrows():
    V_kV = extract_common_voltage_from_names(r["bus1_substation"], r["bus2_substation"])
    if V_kV is None:
        continue
    R_ohm, X_ohm = z_to_rx_ohm(r["Z1"], r["phiz1"])
    add_to_pairs(
        pairs_df,
        r["bus1_substation"],
        r["bus2_substation"],
        *rx_ohm_to_pu(R_ohm, X_ohm, V_kV),
    )

# =====================================================
# 4) transformers_3W_PF_processed.csv
# =====================================================
for _, r in pd.read_csv(TRANSF_3W_FILE).iterrows():
    if pd.isna(r["utrn3_h (kV)"]):
        continue
    R_pu, X_pu = rx_ohm_to_pu(
        r["R_ohm_h"],
        r["X_ohm_h"],
        r["utrn3_h (kV)"],
    )
    add_to_pairs(
        pairs_df,
        r["bushv_substation"],
        r["busmv_substation"],
        R_pu,
        X_pu,
    )

# =====================================================
# 5) transformers_2W_PF_processed.csv
# =====================================================
for _, r in pd.read_csv(TRANSF_2W_FILE).iterrows():
    if pd.isna(r["utrn_h (kV)"]):
        continue

    # Use HV side as base
    V_kV = r["utrn_h (kV)"]
    R_pu, X_pu = rx_ohm_to_pu(
        r["R_ohm"],
        r["X_ohm"],
        V_kV,
    )

    add_to_pairs(
        pairs_df,
        r["hv_substation"],
        r["lv_substation"],
        R_pu,
        X_pu,
    )

# =====================================================
# Save result
# =====================================================
pairs_df.to_csv(OUTPUT_FILE, index=False)
print(f"Created: {OUTPUT_FILE}")
