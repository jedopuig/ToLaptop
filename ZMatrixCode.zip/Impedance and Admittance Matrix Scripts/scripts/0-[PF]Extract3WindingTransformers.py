import powerfactory as pf
import pandas as pd
from pathlib import Path
import re

app = pf.GetApplication()
app.PrintInfo("Starting to export 3-winding transformers (ElmTr3) to CSV...")

# ----------------------------------------------------------
# SETTINGS & PATHS
# ----------------------------------------------------------

# Repository root = parent of the folder where this script lives
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent   # assumes scripts live in repo-root/scripts/

# Common CSV output folder inside the repo
output_dir = REPO_ROOT / "data" / "csv"
output_dir.mkdir(parents=True, exist_ok=True)

output_file = output_dir / "transformers_3W_PF.csv"


# ----------------------------------------------------------
# HELPERS
# ----------------------------------------------------------
def get_attr_chain(obj, attr_path):
    cur = obj
    for part in attr_path.split("."):
        if cur is None:
            return None
        cur = getattr(cur, part, None)
    return cur

def pf_attr(obj, name):
    if obj is None:
        return None
    try:
        return obj.GetAttribute(name)
    except Exception:
        return getattr(obj, name, None)

def resolve_typtr3_for_transformer(tr, application):
    if getattr(tr, "typ_id", None):
        return tr.typ_id
    name = getattr(tr, "loc_name", None)
    if name:
        try:
            candidates = application.GetCalcRelevantObjects(f"{name}.TypTr3") or []
            if candidates:
                return candidates[0]
        except Exception:
            pass
    return None

# ----------------------------------------------------------
# LOAD TRANSFORMERS
# ----------------------------------------------------------
tr3 = app.GetCalcRelevantObjects('*.ElmTr3') or []
app.PrintInfo(f"Detected 3-winding transformers: {len(tr3)}")

# ----------------------------------------------------------
# EXPORT TO CSV
# ----------------------------------------------------------
base_dir.mkdir(parents=True, exist_ok=True)

columns = [
    "loc_name",
    "typ_id",
    "outserv",
    "cpArea.loc_name",
    "cpZone.loc_name",

    "bushv",
    "busmv",

    "utrn3_h (kV)", "utrn3_m (kV)", "utrn3_l (kV)",
    "uktr3_h (%)",
    "pcut3_h (kW)",
    "strn3_h (MVA)", "strn3_m (MVA)",
]

rows = []

for tr in tr3:
    row = {}

    row["loc_name"] = getattr(tr, "loc_name", None)

    try:
        row["typ_id"] = tr.typ_id.loc_name if tr.typ_id else None
    except Exception:
        row["typ_id"] = None

    row["outserv"] = pf_attr(tr, "outserv")

    row["cpArea.loc_name"] = get_attr_chain(tr, "cpArea.loc_name")
    row["cpZone.loc_name"] = get_attr_chain(tr, "cpZone.loc_name")

    row["bushv"] = pf_attr(tr, "bushv")
    row["busmv"] = pf_attr(tr, "busmv")

    typ = resolve_typtr3_for_transformer(tr, app)

    row["utrn3_h (kV)"] = pf_attr(typ, "utrn3_h")
    row["utrn3_m (kV)"] = pf_attr(typ, "utrn3_m")
    row["utrn3_l (kV)"] = pf_attr(typ, "utrn3_l")

    row["uktr3_h (%)"] = pf_attr(typ, "uktr3_h")
    row["pcut3_h (kW)"] = pf_attr(typ, "pcut3_h")

    row["strn3_h (MVA)"] = pf_attr(typ, "strn3_h")
    row["strn3_m (MVA)"] = pf_attr(typ, "strn3_m")

    rows.append(row)

df = pd.DataFrame(rows, columns=columns)
df.to_csv(output_file, index=False, encoding="utf-8-sig")

app.PrintInfo(f"Export complete: {output_file}")
app.PrintInfo(f"Total exported (no filtering applied): {len(rows)}")