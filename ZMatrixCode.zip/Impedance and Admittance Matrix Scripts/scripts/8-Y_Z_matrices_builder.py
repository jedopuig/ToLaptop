import pandas as pd
import numpy as np

# ----------------------------------------------------------
# Paths
# ----------------------------------------------------------
from pathlib import Path

# Script location
SCRIPT_DIR = Path(__file__).resolve().parent

# Repository root (scripts/ → repo-root/)
REPO_ROOT = SCRIPT_DIR.parent

# Shared CSV directory
DATA_DIR = REPO_ROOT / "data" / "csv"

INPUT_FILE     = DATA_DIR / "substation_impedance_pairs.csv"
Y_OUTPUT_FILE  = DATA_DIR / "admittance_matrix.csv"
Z_OUTPUT_FILE  = DATA_DIR / "impedance_matrix.csv"

REFERENCE_BUS = "Eemshaven 380"

# ----------------------------------------------------------
# Load data
# ----------------------------------------------------------
df = pd.read_csv(INPUT_FILE)

# ----------------------------------------------------------
# Collect all unique substations
# ----------------------------------------------------------
substations = sorted(set(df["substation1"]).union(df["substation2"]))

# Create empty admittance matrix (complex)
Y = pd.DataFrame(
    data=0.0 + 0.0j,
    index=substations,
    columns=substations
)

# ----------------------------------------------------------
# Fill admittance matrix
# ----------------------------------------------------------
for _, row in df.iterrows():
    s1 = row["substation1"]
    s2 = row["substation2"]
    R = row["R"]
    X = row["X"]

    if s1 == s2:
        continue

    if R == 0 and X == 0:
        y = 0.0 + 0.0j
    else:
        y = 1 / complex(R, X)

    Y.loc[s1, s2] -= y
    Y.loc[s2, s1] -= y
    Y.loc[s1, s1] += y
    Y.loc[s2, s2] += y

# ----------------------------------------------------------
# Remove isolated substations (no connections)
# ----------------------------------------------------------
connected = Y.abs().sum(axis=1) > 0
Y_reduced = Y.loc[connected, connected]

# ----------------------------------------------------------
# Set reference bus (remove from Y-bus)
# ----------------------------------------------------------
if REFERENCE_BUS not in Y_reduced.index:
    raise ValueError(f"Reference bus '{REFERENCE_BUS}' not found in Y-bus.")

Y_ref_removed = Y_reduced.drop(index=REFERENCE_BUS, columns=REFERENCE_BUS)

# ----------------------------------------------------------
# Compute impedance matrix (Z-bus)
# ----------------------------------------------------------
Z = pd.DataFrame(
    np.linalg.inv(Y_ref_removed.values),
    index=Y_ref_removed.index,
    columns=Y_ref_removed.columns
)

# ----------------------------------------------------------
# Save results
# ----------------------------------------------------------
Y_reduced.to_csv(Y_OUTPUT_FILE)
Z.to_csv(Z_OUTPUT_FILE)

print("✅ Admittance matrix created (isolated nodes removed):")
print(Y_OUTPUT_FILE)
print(f"Size: {Y_reduced.shape[0]} x {Y_reduced.shape[1]}")

print("\n✅ Impedance matrix (Z-bus) created:")
print(Z_OUTPUT_FILE)
print(f"Reference bus: {REFERENCE_BUS}")
print(f"Z-bus size: {Z.shape[0]} x {Z.shape[1]}")
