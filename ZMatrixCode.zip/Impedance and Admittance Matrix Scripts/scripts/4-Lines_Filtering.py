import pandas as pd
import re
from pathlib import Path
from collections import defaultdict

# ----------------------------------------------------------
# PATHS
# ----------------------------------------------------------

# Script location
SCRIPT_DIR = Path(__file__).resolve().parent

# Repository root (scripts/ → repo-root/)
REPO_ROOT = SCRIPT_DIR.parent

# Shared CSV directory
DATA_DIR = REPO_ROOT / "data" / "csv"

lines_file  = DATA_DIR / "lines.csv"
subs_file   = DATA_DIR / "substations_HV.csv"
output_file = DATA_DIR / "lines_filtered_by_substations.csv"

# ----------------------------------------------------------
# LOAD INPUTS
# ----------------------------------------------------------
df_lines = pd.read_csv(lines_file, encoding="utf-8-sig")
df_subs = pd.read_csv(subs_file, encoding="utf-8-sig")

if "loc_name" not in df_subs.columns:
    raise ValueError("substations_HV.csv must contain loc_name")

# ----------------------------------------------------------
# FILTER 0: Drop rows whose loc_name contains OWIN, BATT, or LOAD (case-insensitive)
# ----------------------------------------------------------
pattern = r"OWIN|BATT|LOAD"
df_lines = df_lines[
    ~df_lines["loc_name"].astype(str).str.contains(pattern, case=False, na=False)
].reset_index(drop=True)

# ----------------------------------------------------------
# NORMALIZATION FUNCTION (for comparison only)
# ----------------------------------------------------------
def norm(s):
    if pd.isna(s):
        return None
    return " ".join(str(s).strip().split()).lower()

# Build normalized valid substation names
valid_subs_normalized = set(df_subs["loc_name"].map(norm).dropna().tolist())

# ----------------------------------------------------------
# FILTER 1: Keep line row only if bus1_substation or bus2_substation matches
# ----------------------------------------------------------
def keep_row(row):
    b1 = norm(row.get("bus1_substation"))
    b2 = norm(row.get("bus2_substation"))
    return (b1 in valid_subs_normalized) or (b2 in valid_subs_normalized)

df_lines = df_lines[df_lines.apply(keep_row, axis=1)].reset_index(drop=True)

# ----------------------------------------------------------
# PREPARE SUBSTATION LOOKUPS (PREFIX-BASED)
# ----------------------------------------------------------
def letters_prefix(s: str):
    if not isinstance(s, str):
        return ""
    m = re.match(r"([A-Za-z]+)", s.strip())
    return m.group(1).upper() if m else ""

def extract_voltage(s: str):
    if not isinstance(s, str):
        return None
    m = re.search(r"(\d{2,3})\s*$", s.strip())
    return int(m.group(1)) if m else None

subs_by_prefix = defaultdict(list)
for _, r in df_subs.iterrows():
    ss = r["sShort"]
    px = letters_prefix(ss)
    if px:
        subs_by_prefix[px].append({
            "sShort": ss,
            "loc_name": r["loc_name"],
            "voltage": extract_voltage(ss)
        })

VALID_VOLTS = {110, 150, 220, 380}

# ----------------------------------------------------------
# PARSE line loc_name for codes + voltages
# ----------------------------------------------------------
def extract_codes(text: str):
    if not isinstance(text, str):
        return []
    codes = [m.group(0).upper() for m in re.finditer(r"[A-Za-z]{2,}", text)]
    seen, out = set(), []
    for c in codes:
        if c not in seen:
            seen.add(c)
            out.append(c)
    return out

def extract_volts(text: str):
    if not isinstance(text, str):
        return set()
    found = set(int(x) for x in re.findall(r"(\d{2,3})", text))
    return found.intersection(VALID_VOLTS)

# ----------------------------------------------------------
# PICK BEST SUBSTATION FOR A CODE
# ----------------------------------------------------------
def pick(code, volts_in_name):
    candidates = subs_by_prefix.get(code, [])
    if not candidates:
        return None
    candidates_by_v = [c for c in candidates if c["voltage"] in volts_in_name]
    if len(candidates_by_v) == 1:
        return candidates_by_v[0]["loc_name"]
    if len(candidates_by_v) > 1:
        return candidates_by_v[0]["loc_name"]
    return candidates[0]["loc_name"]

# ----------------------------------------------------------
# BUILD NEW COLUMNS: bus1_from_names, bus2_from_names
# ----------------------------------------------------------
bus1_names = []
bus2_names = []

for _, row in df_lines.iterrows():
    name = row["loc_name"]
    codes = extract_codes(name)
    volts = extract_volts(name)

    matched_subs = []
    for code in codes:
        sub = pick(code, volts)
        if sub and sub not in matched_subs:
            matched_subs.append(sub)
        if len(matched_subs) >= 2:
            break

    s1 = matched_subs[0] if len(matched_subs) >= 1 else None
    s2 = matched_subs[1] if len(matched_subs) >= 2 else None
    bus1_names.append(s1)
    bus2_names.append(s2)

df_lines["bus1_from_names"] = bus1_names
df_lines["bus2_from_names"] = bus2_names

# ----------------------------------------------------------
# NEW COLUMN: Matching_substations (order does not matter)
# ----------------------------------------------------------
def match_sets(row):
    actual = {row.get("bus1_substation"), row.get("bus2_substation")}
    predicted = {row.get("bus1_from_names"), row.get("bus2_from_names")}

    actual = {x for x in actual if pd.notna(x) and x != ""}
    predicted = {x for x in predicted if pd.notna(x) and x != ""}

    return "Yes" if actual == predicted and len(actual) > 0 else "No"

df_lines["Matching_substations"] = df_lines.apply(match_sets, axis=1)

# ----------------------------------------------------------
# Voltage extraction and voltage‑mismatch filtering
# ----------------------------------------------------------
VALID_VOLTAGES = {110, 150, 220, 380}

def extract_voltage_from_name(s):
    if not isinstance(s, str):
        return None
    for v in VALID_VOLTAGES:
        if str(v) in s:
            return v
    return None

df_lines["v1"] = df_lines["bus1_substation"].apply(extract_voltage_from_name)
df_lines["v2"] = df_lines["bus2_substation"].apply(extract_voltage_from_name)

# ✅ REMOVE rows with mismatched voltages
df_lines = df_lines[df_lines["v1"] == df_lines["v2"]].reset_index(drop=True)

# ----------------------------------------------------------
# SAVE RESULT
# ----------------------------------------------------------
df_lines.to_csv(output_file, index=False, encoding="utf-8-sig")

print(f"Final rows: {len(df_lines)}")
print(f"Output written to: {output_file}")