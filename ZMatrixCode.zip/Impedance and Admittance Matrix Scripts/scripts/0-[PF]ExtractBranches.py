import powerfactory as pf
import pandas as pd
from pathlib import Path

app = pf.GetApplication()
app.PrintInfo("Starting to export branches (ElmBranch) to CSV...")

# ----------------------------------------------------------
# LOAD MODEL OBJECTS
# ----------------------------------------------------------
branches = app.GetCalcRelevantObjects('*.ElmBranch') or []

# ----------------------------------------------------------
# CSV OUTPUT
# ----------------------------------------------------------
# Repository root = parent of the folder where this script lives
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent   # assumes scripts live in repo-root/scripts/

# Common CSV output folder inside the repo
output_dir = REPO_ROOT / "data" / "csv"
output_dir.mkdir(parents=True, exist_ok=True)

output_file = output_dir / "branches.csv"

columns = [
    "loc_name",
    "length",
    "Z1",
    "phiz1",
    "cpArea.loc_name",
    "cpZone.loc_name",
    "substation1",
    "substation2",
    "substation1_only1substation",
    "substation2_only1substation",
]

def get_attr_chain(obj, attr_path):
    cur = obj
    for part in attr_path.split("."):
        if cur is None:
            return None
        cur = getattr(cur, part, None)
    return cur

# ----------------------------------------------------------
# Extract substations directly from a line element
# ----------------------------------------------------------
def get_substations_from_line(line):
    """Return (sub1, sub2) safely from an ElmLne or ElmSind object."""
    if not line:
        return None, None

    cls = line.GetClassName()
    if cls not in ("ElmLne", "ElmSind"):
        return None, None

    # bus1
    try:
        t1 = line.bus1.cterm if (line.bus1 and line.bus1.cterm) else None
        sub1 = t1.cpSubstat.loc_name if (t1 and t1.cpSubstat) else None
    except:
        sub1 = None

    # bus2
    try:
        t2 = line.bus2.cterm if (line.bus2 and line.bus2.cterm) else None
        sub2 = t2.cpSubstat.loc_name if (t2 and t2.cpSubstat) else None
    except:
        sub2 = None

    return sub1, sub2


rows = []

for br in branches:
    row = {}

    # Basic attributes
    row["loc_name"] = getattr(br, "loc_name", None)
    row["cpArea.loc_name"] = get_attr_chain(br, "cpArea.loc_name")
    row["cpZone.loc_name"] = get_attr_chain(br, "cpZone.loc_name")

    try: row["length"] = br.GetAttribute("length")
    except: row["length"] = getattr(br, "length", None)

    try: row["Z1"] = br.GetAttribute("Z1")
    except: row["Z1"] = getattr(br, "Z1", None)

    try: row["phiz1"] = br.GetAttribute("phiz1")
    except: row["phiz1"] = getattr(br, "phiz1", None)

    # ----------------------------------------------------------
    # CONDITION:
    # Count ElmLne + ElmSind elements in this branch
    # ----------------------------------------------------------
    contents = br.GetContents() or []
    line_elems = [e for e in contents if e.GetClassName() in ("ElmLne", "ElmSind")]
    n_lines = len(line_elems)

    # ----------------------------------------------------------
    # CASE 1: ONLY ONE LINE ELEMENT IN BRANCH
    # ----------------------------------------------------------
    if n_lines == 1:
        line = line_elems[0]
        sub1, sub2 = get_substations_from_line(line)

        row["substation1"] = sub1
        row["substation2"] = sub2

        row["substation1_only1substation"] = "Yes" if sub1 else "No"
        row["substation2_only1substation"] = "Yes" if sub2 else "No"

        rows.append(row)
        continue

    # ----------------------------------------------------------
    # CASE 2: TWO OR MORE (ElmLne / ElmSind)
    # ----------------------------------------------------------

    # ---------- Terminal 1 ----------
    p0 = getattr(br, "p_conn0", None)
    sub1a, sub1b = get_substations_from_line(p0)

    subs1 = [x for x in (sub1a, sub1b) if x]
    if len(subs1) == 1:
        row["substation1"] = subs1[0]
        row["substation1_only1substation"] = "Yes"
    elif len(subs1) >= 2:
        row["substation1"] = subs1
        row["substation1_only1substation"] = "No"
    else:
        row["substation1"] = None
        row["substation1_only1substation"] = "No"

    # ---------- Terminal 2 ----------
    p1 = getattr(br, "p_conn1", None)
    sub2a, sub2b = get_substations_from_line(p1)

    subs2 = [x for x in (sub2a, sub2b) if x]
    if len(subs2) == 1:
        row["substation2"] = subs2[0]
        row["substation2_only1substation"] = "Yes"
    elif len(subs2) >= 2:
        row["substation2"] = subs2
        row["substation2_only1substation"] = "No"
    else:
        row["substation2"] = None
        row["substation2_only1substation"] = "No"

    rows.append(row)

# ----------------------------------------------------------
# SAVE
# ----------------------------------------------------------
df = pd.DataFrame(rows, columns=columns)
df.to_csv(output_file, index=False, encoding="utf-8-sig")

app.PrintInfo(f"Branch list exported to: {output_file}")
app.PrintInfo(f"Total branches exported: {len(df)}")