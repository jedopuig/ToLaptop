import csv
import os
import ast
import re

# --------------------------------------------------------
# CONFIGURE PATHS
# --------------------------------------------------------

# Script location
SCRIPT_DIR = Path(__file__).resolve().parent

# Repository root (scripts/ → repo-root/)
REPO_ROOT = SCRIPT_DIR.parent

# Shared CSV directory
DATA_DIR = REPO_ROOT / "data" / "csv"

branches_path    = DATA_DIR / "branches.csv"
substations_path = DATA_DIR / "substations_HV.csv"

output_2   = DATA_DIR / "branches_2substations.csv"
output_gt2 = DATA_DIR / "branches_more2substations.csv"


# --------------------------------------------------------
# Detect delimiter
# --------------------------------------------------------
def detect_delimiter(path):
    with open(path, "r", encoding="utf-8", newline="") as f:
        sample = f.read(2048)
        return ";" if sample.count(";") > sample.count(",") else ","

branches_delim = detect_delimiter(branches_path)
subs_delim = detect_delimiter(substations_path)

# --------------------------------------------------------
# Helper functions
# --------------------------------------------------------
def letters_only(s):
    return re.sub(r'[^A-Za-z]', '', s or '')

def tokenize_loc_name(loc):
    loc = re.sub(r"\(.*?\)", "", loc)
    parts = re.split(r'[-_ ]+', loc)
    return [letters_only(p) for p in parts if letters_only(p)]

def extract_voltage(loc):
    volts = []
    if "380" in loc: volts.append(380)
    if "220" in loc: volts.append(220)
    if "150" in loc: volts.append(150)
    if "110" in loc: volts.append(110)
    return max(volts) if volts else None

def is_list_like(val):
    if not val:
        return False
    v = val.strip()
    return v.startswith("[") and v.endswith("]")

def parse_list(val):
    try:
        obj = ast.literal_eval(val)
        return obj if isinstance(obj, list) else None
    except:
        return None

def clean_substations_if_lists(s1, s2):
    list1 = parse_list(s1)
    list2 = parse_list(s2)
    if not list1 or not list2:
        return None

    common = list(set(list1).intersection(list2))
    if len(common) != 1:
        return None

    c = common[0]
    if c in list1: list1.remove(c)
    if c in list2: list2.remove(c)
    if len(list1) == 1 and len(list2) == 1:
        return list1[0], list2[0]
    return None

# --------------------------------------------------------
# Load sShort letters-only list
# --------------------------------------------------------
sShort_letters = []
sShort_map_letters_to_full = {}

with open(substations_path, "r", encoding="utf-8", newline="") as subsfile:
    reader = csv.DictReader(subsfile, delimiter=subs_delim)
    subs_fieldnames = [h.strip().replace("\ufeff", "") for h in reader.fieldnames]
    rename_subs = dict(zip(reader.fieldnames, subs_fieldnames))

    for raw in reader:
        row = {rename_subs[k]: v for k, v in raw.items()}
        full = row.get("sShort", "")
        letters = letters_only(full)
        if letters and letters not in sShort_letters:
            sShort_letters.append(letters)
        sShort_map_letters_to_full[letters] = full

# --------------------------------------------------------
# Process branches
# --------------------------------------------------------
gt2_rows = []
two_rows_clean = []

with open(branches_path, "r", encoding="utf-8", newline="") as infile:
    reader = csv.DictReader(infile, delimiter=branches_delim)
    original_fieldnames = [fn.strip().replace("\ufeff", "") for fn in reader.fieldnames]

    # Remove unwanted columns from fieldnames
    unwanted_cols = ["substation1_only1substation", "substation2_only1substation"]
    fieldnames = [fn for fn in original_fieldnames if fn not in unwanted_cols]

    rename = dict(zip(reader.fieldnames, fieldnames))

    # Ensure 4 substation columns exist and are side by side
    base_cols = ["substation1", "substation2", "substation3", "substation4"]
    for col in base_cols:
        if col not in fieldnames:
            fieldnames.append(col)

    for raw in reader:
        # map row, ignoring unwanted columns
        row = {rename.get(k, k): v for k, v in raw.items()}
        for bad in unwanted_cols:
            row.pop(bad, None)

        loc = row.get("loc_name", "").strip()

        # --------------------------------------------------------
        # FORCE CERTAIN BRANCHES INTO branches_2substations.csv
        # --------------------------------------------------------
        forced_prefixes = (
            "AMH-SMH-CST380",
            "WAMH-SMH-CST380",
            "ZGO"
        )

        if any(loc.startswith(p) for p in forced_prefixes):
            row["substation1"] = "Amaliahaven 380"
            row["substation2"] = "Simonshaven 380"
            row["substation3"] = ""
            row["substation4"] = ""

            Z1 = row.get("Z1", "").strip()
            phiz1 = row.get("phiz1", "").strip()
            if Z1 and phiz1:
                two_rows_clean.append(row)
            continue

        # continue normal logic
        loc = row.get("loc_name", "").strip()
        hyph_count = loc.count("-")

        # RULE 1: EXACTLY ONE HYPHEN → always a 2-substation branch
        if hyph_count == 1:
            goes_to_2 = True

        else:
            # RULE 2: sShort logic
            tokens = tokenize_loc_name(loc)
            match_count = sum(1 for t in tokens if t in sShort_letters)
            goes_to_2 = (match_count == 2)

        # --------------------------------------------------------
        # CASE A — MORE THAN 2 SUBSTATIONS
        # --------------------------------------------------------
        if not goes_to_2:

            Z1 = row.get("Z1", "").strip()
            phiz1 = row.get("phiz1", "").strip()

            # remove invalid rows
            if not Z1 or not phiz1:
                continue

            voltage = extract_voltage(loc)
            tokens = tokenize_loc_name(loc)
            matched_letters = [t for t in tokens if t in sShort_letters]

            # generate station names with shared voltage
            final_subs = []
            for t in matched_letters:
                if voltage:
                    final_subs.append(f"{t}{voltage}")
                else:
                    final_subs.append(sShort_map_letters_to_full[t])

            for i in range(1, 5):
                key = f"substation{i}"
                row[key] = final_subs[i-1] if i <= len(final_subs) else ""

            if len(final_subs) < 4:
                row["substation4"] = ""

            gt2_rows.append(row)
            continue

        # --------------------------------------------------------
        # CASE B — TWO SUBSTATIONS (unchanged)
        # --------------------------------------------------------
        Z1 = row.get("Z1", "").strip()
        phiz1 = row.get("phiz1", "").strip()
        s1 = row.get("substation1", "").strip()
        s2 = row.get("substation2", "").strip()

        if not Z1 or not phiz1 or not s1 or not s2:
            continue

        if s1 == s2:
            continue

        if is_list_like(s1) and is_list_like(s2):
            cleaned = clean_substations_if_lists(s1, s2)
            if cleaned:
                row["substation1"], row["substation2"] = cleaned
                if row["substation1"] == row["substation2"]:
                    continue
            else:
                continue

        two_rows_clean.append(row)

# --------------------------------------------------------
# Write outputs
# --------------------------------------------------------
with open(output_2, "w", encoding="utf-8", newline="") as f2:
    writer = csv.DictWriter(f2, fieldnames=fieldnames)
    writer.writeheader()
    for r in two_rows_clean:
        writer.writerow(r)

with open(output_gt2, "w", encoding="utf-8", newline="") as fg:
    writer = csv.DictWriter(fg, fieldnames=fieldnames)
    writer.writeheader()
    for r in gt2_rows:
        writer.writerow(r)

print("✔ Done!\nCreated:\n -", output_2, "\n -", output_gt2)
