import subprocess
import sys
from pathlib import Path

# ----------------------------------------------------------
# Repository setup
# ----------------------------------------------------------
REPO_ROOT = Path(__file__).resolve().parent
SCRIPTS_DIR = REPO_ROOT / "scripts"

# Ordered list of scripts to run (NON-PF only)
PIPELINE = [
    "1-Substations_Processing.py",
    "2-2TF_Processing.py",
    "3-3W_TF_Processing.py",
    "4-Lines_Filtering.py",
    "5-Branches_2_vs_more_substations.py",
    "6-Branches_Y_to_Delta.py",
    "7-SubstationPairsBuilder.py",
    "8-Y_Z_matrices_builder.py",
]

# ----------------------------------------------------------
# Run pipeline
# ----------------------------------------------------------
for script in PIPELINE:
    script_path = SCRIPTS_DIR / script

    print(f"\n▶ Running {script}")
    result = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=str(SCRIPTS_DIR),
    )

    if result.returncode != 0:
        print(f"\n❌ Pipeline stopped: {script} failed")
        sys.exit(1)

print("\n✅ Pipeline completed successfully")
