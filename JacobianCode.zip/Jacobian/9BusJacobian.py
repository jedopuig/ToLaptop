import re
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix

# --------------------------------------------------------------
# READ .MTL AS SPARSE MATRIX AND CONVERT TO DENSE
# --------------------------------------------------------------
def read_mtl_to_dense(path: Path):
    rows, cols, data = [], [], []

    triplet = re.compile(
        r'^\s*([+-]?\d+)\s+([+-]?\d+)\s+([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][+-]?\d+)?)\s*$'
    )

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = triplet.match(line)
            if not m:
                continue

            r = int(m.group(1)) - 1
            c = int(m.group(2)) - 1
            v = float(m.group(3).replace("D", "E"))
            rows.append(r)
            cols.append(c)
            data.append(v)

    if not rows:
        raise ValueError("No numeric rows detected")

    nrows = max(rows) + 1
    ncols = max(cols) + 1

    return coo_matrix((data, (rows, cols)), shape=(nrows, ncols)).toarray()


# --------------------------------------------------------------
# MAIN — extract J blocks + compute terminal impact
# --------------------------------------------------------------
def main():

    jac_path = Path(
        r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents"
        r"\Aggregated Load\Node Importance\Jacobian Matrix\IEEE 9 BUS\Jacobian.mtl"
    )

    print("Loading Jacobian...")
    A = read_mtl_to_dense(jac_path)
    print("Jacobian shape:", A.shape)

    # ----------------------------------------------------------
    # PARTITION: 63 states, rest are algebraic (201 total)
    # ----------------------------------------------------------
    Ns = 63
    Na = A.shape[0] - Ns   # 201 - 63 = 138

    # ----------------------------------------------------------
    # Extract DAE Jacobian submatrices
    # ----------------------------------------------------------
    Jxx = A[:Ns, :Ns]
    Jxv = A[:Ns, Ns:Ns+Na]      # 63 x 138
    Jvx = A[Ns:Ns+Na, :Ns]
    Jvv = A[Ns:Ns+Na, Ns:Ns+Na]

    print("Jxv shape:", Jxv.shape)

    # ----------------------------------------------------------
    # Variables 64–89 in the *full* Jacobian correspond to:
    # full index range = 64..89  (1-based), → 63..88 (0-based)
    # Within Jxv (columns start at full index 64 = 1-based),
    # Jxv local index = col_1b - 64
    # ----------------------------------------------------------
    full_start = 64   # 1-based inclusive
    full_end   = 89   # 1-based inclusive

    # convert full Jacobian column indices to local Jxv indices
    local_start = full_start - (Ns + 1)  # 64 - 64 = 0
    local_end   = full_end   - (Ns + 1)  # 89 - 64 = 25

    # Must be exactly 26 columns (13 terminals × 2)
    print(f"Local Jxv column range = {local_start}..{local_end}")

    Jxv_sub = Jxv[:, local_start:local_end+1]  # 63x26
    print("Sub Jxv shape:", Jxv_sub.shape)

    # ----------------------------------------------------------
    # COMPUTE IMPACT PER TERMINAL
    # Terminals are grouped in pairs (Re, Im):
    #   (64,65), (66,67), …, (88,89)
    # local pairs:
    #   (0,1), (2,3), …, (24,25)
    # impact = sum(abs(Jxv_re)) + sum(abs(Jxv_im))
    # ----------------------------------------------------------
    n_cols = Jxv_sub.shape[1]
    n_terms = n_cols // 2

    impacts = []
    for k in range(n_terms):
        col_re = 2*k
        col_im = 2*k + 1
        imp = np.sum(np.abs(Jxv_sub[:, col_re])) + np.sum(np.abs(Jxv_sub[:, col_im]))

        # retrieve original global column indices
        col_re_global = full_start + 2*k
        col_im_global = col_re_global + 1

        impacts.append((imp, col_re_global, col_im_global))

    # ----------------------------------------------------------
    # Sort by descending impact
    # ----------------------------------------------------------
    impacts.sort(key=lambda x: -x[0])

    print("\n=== MOST IMPACTFUL TERMINAL VOLTAGES (Variables 64–89) ===")
    for rank, (imp, col_re, col_im) in enumerate(impacts, start=1):
        print(f"{rank:2d}. Impact = {imp:.6e}    Columns = ({col_re},{col_im})")


if __name__ == "__main__":
    main()

print()