# JacobianReader.py
# Loads a PowerFactory .mtl Jacobian, computes Jxv-based node importance,
# prints total-Jacobian column ↔ bus mapping, and plots the top-5 buses (10 lines: Re/Im).

import os
import re
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix, csr_matrix
import matplotlib.pyplot as plt


# -----------------------------
# 1) Reader for PowerFactory .mtl (sparse triplets)
# -----------------------------
def read_powerfactory_mtl(file_path, shape=None, one_based_indexing=True,
                          comment_pattern=r'^[#%!;]|^(Row\b|Col\b|Value\b)'):
    """
    Reads a DIgSILENT/PowerFactory sparse matrix exported to a text .mtl file into a SciPy CSR matrix.

    Expected file format (typical):
        <row> <col> <value>
        1     1      1.0
        1     542   -0.0034
        2     1      0.2398
        ...

    Parameters
    ----------
    file_path : str | Path
        Full path to the .mtl file (text).
    shape : tuple[int, int] | None
        Optional (n_rows, n_cols). If None, inferred as max(row, col).
    one_based_indexing : bool
        True if file rows/cols are 1-based (PF default). Converted to 0-based for Python.
    comment_pattern : str
        Regex marking comment/header lines to skip.

    Returns
    -------
    scipy.sparse.csr_matrix
        Loaded sparse matrix in CSR form with duplicates summed.
    """
    file_path = Path(file_path)

    rows, cols, data = [], [], []

    triplet = re.compile(
        r'^\s*([+-]?\d+)\s+([+-]?\d+)\s+([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s*$'
    )
    comment_re = re.compile(comment_pattern)

    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for raw in f:
            s = raw.strip()
            if not s or comment_re.search(s):
                continue

            m = triplet.match(s)
            if not m:
                parts = s.split()
                if len(parts) < 3:
                    continue
                r_str, c_str, v_str = parts[0], parts[1], parts[2]
                try:
                    r = int(r_str); c = int(c_str); v = float(v_str)
                except ValueError:
                    continue
            else:
                r = int(m.group(1)); c = int(m.group(2)); v = float(m.group(3))

            if one_based_indexing:
                r -= 1; c -= 1

            rows.append(r); cols.append(c); data.append(v)

    if not rows:
        raise ValueError(f"No numeric triplets found in file: {file_path}")

    if shape is None:
        nrows = max(rows) + 1
        ncols = max(cols) + 1
        shape = (nrows, ncols)

    coo = coo_matrix((np.array(data, dtype=float), (np.array(rows), np.array(cols))), shape=shape)
    csr = coo.tocsr()
    csr.sum_duplicates()
    return csr


# -----------------------------
# 2) Node-importance from Jxv
# -----------------------------
def compute_dynamic_node_importance(A: csr_matrix,
                                    n_states: int,
                                    v_start_col_0b: int,
                                    v_end_col_0b: int):
    """
    Computes per-bus importance from Jxv:
        I_k = sqrt( ||J[:, Re_k]||_2^2 + ||J[:, Im_k]||_2^2 )
    where rows are only the 'n_states' dynamic rows.

    Parameters
    ----------
    A : csr_matrix
        Full Jacobian (square).
    n_states : int
        Number of dynamic state variables (rows 0..n_states-1).
    v_start_col_0b : int
        0-based index of first voltage column (Re of bus 1).
    v_end_col_0b : int
        0-based EXCLUSIVE end index of voltage columns.

    Returns
    -------
    importance : np.ndarray shape (n_buses,)
        Dynamic importance per bus.
    """
    # Extract rows and columns for Jxv block (sparse)
    Jxv = A[:n_states, v_start_col_0b:v_end_col_0b].tocsc()

    n_cols = Jxv.shape[1]
    if n_cols % 2 != 0:
        raise ValueError(f"Voltage column count ({n_cols}) is not even; expected Re/Im pairs.")

    # Efficient column-wise squared norms
    J_csr = Jxv.tocsr()
    J_sq = J_csr.multiply(J_csr)
    col_sq_sums = np.array(J_sq.tocsc().sum(axis=0)).ravel()

    # Combine Re/Im pairs per bus
    importance = np.sqrt(col_sq_sums[0::2] + col_sq_sums[1::2])
    return importance


# -----------------------------
# 3) Column ↔ bus mapping utilities
# -----------------------------
def total_col_to_bus_1b(col_total_1b: int, v_start_col_1b: int = 2083):
    """
    Map a 1-based TOTAL Jacobian column index -> (bus_number_1b, component),
    where component is 'Re' or 'Im'.

    Example:
      col_total_1b = 2083 -> (1, 'Re')
      col_total_1b = 2084 -> (1, 'Im')
      col_total_1b = 2085 -> (2, 'Re'), etc.
    """
    idx_from_vstart = col_total_1b - v_start_col_1b
    if idx_from_vstart < 0:
        raise ValueError("Column is before the start of voltage block.")
    bus_0b = idx_from_vstart // 2
    comp = 'Re' if (idx_from_vstart % 2 == 0) else 'Im'
    return bus_0b + 1, comp  # 1-based bus number


def bus_to_total_cols_1b(bus_number_1b: int, v_start_col_1b: int = 2083):
    """
    Map a 1-based BUS number -> (col_re_1b, col_im_1b) in TOTAL Jacobian (1-based).
    """
    bus_0b = bus_number_1b - 1
    col_re_1b = v_start_col_1b + 2 * bus_0b
    col_im_1b = col_re_1b + 1
    return col_re_1b, col_im_1b


# -----------------------------
# 4) Main
# -----------------------------
def main():
    # ---- PATH TO YOUR JACOBIAN ----
    jac_path = Path(r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Node Importance\Jacobian Matrix\Jacobian.mtl")
    if not jac_path.exists():
        raise FileNotFoundError(f"File not found: {jac_path}")

    # ---- LOAD MATRIX ----
    A = read_powerfactory_mtl(jac_path, shape=None, one_based_indexing=True)
    print(f"Loaded Jacobian: shape={A.shape}, nnz={A.nnz}")

    # ---- KNOWN INDICES FROM YOUR MODEL ----
    n_states = 2082                 # rows 0..2081
    v_start_col_1b = 2083           # total Jacobian columns (1-based) where voltages begin
    v_start_col_0b = v_start_col_1b - 1  # -> 2082
    v_end_col_1b = 8568             # inclusive (from your description)
    v_end_col_0b = v_end_col_1b     # make exclusive by not subtracting 1 (since Python slicing excludes end)
    # Sanity: J[:, 2082:8568] (0-based) == J[:, 2083..8568] (1-based inclusive)

    if v_end_col_0b > A.shape[1]:
        raise ValueError("v_end_col exceeds matrix width. Check your indices and exported matrix.")

    # ---- COMPUTE IMPORTANCE ----
    importance = compute_dynamic_node_importance(
        A, n_states=n_states, v_start_col_0b=v_start_col_0b, v_end_col_0b=v_end_col_0b
    )
    n_buses = importance.size
    print(f"Computed importance for {n_buses} buses (voltage columns).")

    # ---- TOP SELECTION ----
    # Rank buses by descending importance
    order = np.argsort(-importance)

    # Show top 10 buses with total-Jacobian column numbers for Re/Im
    top_show = 10
    print("\nTop buses by dynamic importance (‖[J_re J_im]‖₂ over states):")
    for rank, bus_idx_0b in enumerate(order[:top_show], start=1):
        bus_num_1b = bus_idx_0b + 1
        col_re_1b, col_im_1b = bus_to_total_cols_1b(bus_num_1b, v_start_col_1b=v_start_col_1b)
        print(f"{rank:2d}. Bus {bus_num_1b:5d}  importance = {importance[bus_idx_0b]:.6e}  "
              f"(cols: Re={col_re_1b}, Im={col_im_1b})")

    # ---- PLOT: TOP 5 BUSES => 10 LINES (Re & Im) ----
    top5_buses_0b = order[:5]
    x = np.arange(1, n_states + 1)  # 1..2082 for x-axis as requested

    plt.figure(figsize=(13, 6))
    color_cycle = plt.rcParams['axes.prop_cycle'].by_key().get('color', ['C0','C1','C2','C3','C4','C5'])

    for i, bus_idx_0b in enumerate(top5_buses_0b):
        bus_num_1b = bus_idx_0b + 1
        # total Jacobian columns (0-based)
        col_re_0b = v_start_col_0b + 2 * bus_idx_0b
        col_im_0b = col_re_0b + 1
        # total Jacobian columns (1-based, for labels)
        col_re_1b = col_re_0b + 1
        col_im_1b = col_im_0b + 1

        # Extract the two sparse columns across the first n_states rows
        col_re_vals = A[:n_states, col_re_0b].toarray().ravel()
        col_im_vals = A[:n_states, col_im_0b].toarray().ravel()

        color = color_cycle[i % len(color_cycle)]
        # Plot Re (solid) and Im (dashed) for this bus
        plt.plot(x, col_re_vals, color=color, lw=1.5,
                 label=f"Bus {bus_num_1b} Re (col {col_re_1b})")
        plt.plot(x, col_im_vals, color=color, lw=1.5, ls='--',
                 label=f"Bus {bus_num_1b} Im (col {col_im_1b})")

    plt.title("Top-5 Buses: Jxv Columns vs. State Index\n(10 lines: Re solid, Im dashed)", fontsize=13)
    plt.xlabel("State variable index (1..2082)")
    plt.ylabel("Jacobian entry (d f / d v)")
    plt.grid(True, alpha=0.3)
    plt.legend(ncol=2, fontsize=9)
    plt.tight_layout()

    # Save figure alongside the .mtl
    fig_path = jac_path.parent / "Top5_Bus_Jxv_Lines.png"
    plt.savefig(fig_path, dpi=180)
    print(f"\nSaved plot -> {fig_path}")

    # ---- SAVE IMPORTANCE VECTOR FOR REUSE ----
    out_imp = jac_path.parent / "node_importance.npy"
    np.save(out_imp, importance)
    print(f"Saved importance array -> {out_imp}")


if __name__ == "__main__":
    main()