import re
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix


# --------------------------------------------------------------
# READ .MTL AS SPARSE MATRIX AND CONVERT TO DENSE
# --------------------------------------------------------------
def read_mtl_to_dense(path: Path):
    rows, cols, data = [], [], []

    # Numeric triplet: row col value
    triplet = re.compile(
        r'^\s*([+-]?\d+)\s+([+-]?\d+)\s+([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][+-]?\d+)?)\s*$'
    )

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = triplet.match(line)
            if not m:
                continue

            # Convert from 1-based PF indexing -> 0-based Python
            r = int(m.group(1)) - 1
            c = int(m.group(2)) - 1
            v = float(m.group(3).replace("D", "E"))

            rows.append(r)
            cols.append(c)
            data.append(v)

    if not rows:
        raise ValueError("No numeric triplets found in MTL file.")

    nrows = max(rows) + 1
    ncols = max(cols) + 1

    A_sparse = coo_matrix((data, (rows, cols)), shape=(nrows, ncols))
    return A_sparse.toarray()



# --------------------------------------------------------------
# MAIN — PRINT ROWS 68 AND 69 WITH COLUMN INDEX LABELS
# --------------------------------------------------------------
def main():

    jac_path = Path(
        r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents"
        r"\Aggregated Load\Node Importance\Jacobian Matrix\IEEE 9 BUS\Jacobian.mtl"
    )

    print("Loading Jacobian...")
    A = read_mtl_to_dense(jac_path)
    print("Jacobian shape:", A.shape)

    # -------------------------
    # Print header row with column indices (1-based)
    # -------------------------
    print("\n=== COLUMN INDICES ===")
    col_indices = " ".join([f"{c+1:10d}" for c in range(A.shape[1])])
    print(col_indices)
    print()

    # -------------------------
    # Rows 68 and 69 (1-based) -> 67, 68 in Python
    # -------------------------
    rows_to_show = [67, 68]

    for r in rows_to_show:
        print(f"=== ROW {r+1} (1-based) ===")
        row_values = " ".join([f"{A[r, c]:10.4e}" for c in range(A.shape[1])])
        print(row_values)
        print()


if __name__ == "__main__":
    main()