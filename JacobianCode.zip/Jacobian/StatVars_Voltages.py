import re
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix

# --------------------------------------------------------------
# READ .MTL AS SPARSE MATRIX AND CONVERT TO DENSE
# --------------------------------------------------------------
def read_mtl_to_dense(path: Path):
    rows, cols, data = [], [], []

    # Numeric triplet: row col value
    triplet = re.compile(
        r'^\s*([+-]?\d+)\s+([+-]?\d+)\s+([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][+-]?\d+)?)\s*$'
    )

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = triplet.match(line)
            if not m:
                continue

            r = int(m.group(1)) - 1
            c = int(m.group(2)) - 1
            v = float(m.group(3).replace("D", "E"))

            rows.append(r)
            cols.append(c)
            data.append(v)

    if not rows:
        raise ValueError("No numeric triplets found in the MTL file.")

    nrows = max(rows) + 1
    ncols = max(cols) + 1

    A_sparse = coo_matrix((data, (rows, cols)), shape=(nrows, ncols))
    return A_sparse.toarray()



# --------------------------------------------------------------
# MAIN — EXTRACT Jxx, Jxv, Jvx, Jvv AND SUM COLUMNS
# --------------------------------------------------------------
def main():

    jac_path = Path(
        r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents"
        r"\Aggregated Load\Node Importance\Jacobian Matrix\IEEE 9 BUS\Jacobian.mtl"
    )

    print("Loading Jacobian...")
    A = read_mtl_to_dense(jac_path)
    print("Full Jacobian shape:", A.shape)   # Should be (201, 201)

    # ----------------------------------------------------------
    # Partition index
    # ----------------------------------------------------------
    Ns = 63                 # number of dynamic states
    Na = A.shape[0] - Ns    # algebraic variables (201 - 63 = 138)

    # ----------------------------------------------------------
    # Extract submatrices
    # ----------------------------------------------------------
    Jxx = A[:Ns, :Ns]                 # (63 × 63)
    Jxv = A[:Ns, Ns:Ns+Na]            # (63 × 138)
    Jvx = A[Ns:Ns+Na, :Ns]            # (138 × 63)
    Jvv = A[Ns:Ns+Na, Ns:Ns+Na]       # (138 × 138)

    # ----------------------------------------------------------
    # Compute column sums (row vectors)
    # ----------------------------------------------------------
    sum_Jxx = np.sum(Jxx, axis=0)    # length = 63
    sum_Jxv = np.sum(Jxv, axis=0)    # length = 138
    sum_Jvx = np.sum(Jvx, axis=0)    # length = 63
    sum_Jvv = np.sum(Jvv, axis=0)    # length = 138

    # ----------------------------------------------------------
    # Print results
    # ----------------------------------------------------------
    print("\n=== COLUMN SUMS OF Jxx (63 values) ===")
    print(sum_Jxx)

    print("\n=== COLUMN SUMS OF Jxv (138 values) ===")
    print(sum_Jxv)

    print("\n=== COLUMN SUMS OF Jvx (63 values) ===")
    print(sum_Jvx)

    print("\n=== COLUMN SUMS OF Jvv (138 values) ===")
    print(sum_Jvv)


if __name__ == "__main__":
    main()