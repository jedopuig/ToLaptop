# Diagnose_Jacobian_TwoColumns.py
# Robust streaming parser that scans only the needed columns/rows directly from the .mtl text,
# independent of SciPy or matrix construction.

import re
from pathlib import Path

# --- CONFIG ---
MTL_PATH = Path(r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Node Importance\Jacobian Matrix\Jacobian.mtl")
STATE_ROWS_1B = (1, 2082)   # inclusive in 1-based indexing
COL_RE_1B = 5913
COL_IM_1B = 5914

# --- Tolerance to consider "non-zero"
NZ_EPS = 1e-15

# --- Numeric triplet regex (flexible): row col value
# Accept spaces/tabs, optional commas, standard scientific notation
TRIPLET = re.compile(
    r'^\s*([+-]?\d+)[\s,]+([+-]?\d+)[\s,]+([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][+-]?\d+)?)\s*$'
)

def parse_value(val_str: str) -> float:
    # Support 'D' exponent (Fortran) by replacing with 'E'
    v = val_str.replace('D', 'E').replace('d', 'e')
    return float(v)

def main():
    if not MTL_PATH.exists():
        raise FileNotFoundError(f"File not found: {MTL_PATH}")

    # 1-based to 0-based bounds for states
    rmin_0b = STATE_ROWS_1B[0] - 1
    rmax_0b = STATE_ROWS_1B[1] - 1

    target_cols_1b = {COL_RE_1B: "Re", COL_IM_1B: "Im"}
    found_triplets_total = 0
    found_triplets_any_numeric = 0

    # Storage for the two target columns within the state row window
    rows_re = []
    vals_re = []
    rows_im = []
    vals_im = []

    with open(MTL_PATH, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = TRIPLET.match(line)
            if not m:
                continue  # skip any non-numeric line
            found_triplets_any_numeric += 1

            r_1b = int(m.group(1))
            c_1b = int(m.group(2))
            try:
                v = parse_value(m.group(3))
            except ValueError:
                continue

            # Filter to our two columns only
            if c_1b not in target_cols_1b:
                continue

            # Only rows 1..2082 (states)
            if not (STATE_ROWS_1B[0] <= r_1b <= STATE_ROWS_1B[1]):
                continue

            found_triplets_total += 1

            if c_1b == COL_RE_1B:
                rows_re.append(r_1b)
                vals_re.append(v)
            elif c_1b == COL_IM_1B:
                rows_im.append(r_1b)
                vals_im.append(v)

    # REPORT
    print(f"\nScanned file: {MTL_PATH}")
    print(f"Total numeric triplets encountered (any row/col): {found_triplets_any_numeric}")
    print(f"Triplets in target rows/cols (rows 1..{STATE_ROWS_1B[1]}, cols {COL_RE_1B}/{COL_IM_1B}): {found_triplets_total}")

    # RE column report
    print(f"\n=== COLUMN {COL_RE_1B} (Re) — rows 1..{STATE_ROWS_1B[1]} ===")
    if not rows_re:
        print("No entries found in this range.")
    else:
        # Print all entries found (sparse — only nonzero positions are listed by .mtl)
        nz_count_re = sum(abs(v) > NZ_EPS for v in vals_re)
        l1_re = sum(abs(v) for v in vals_re)
        print(f"Found {len(vals_re)} triplets (sparse). Nonzero (|v|>{NZ_EPS}): {nz_count_re}, L1-sum: {l1_re:.12e}")
        # Print all (row, value)
        for r, v in zip(rows_re, vals_re):
            print(f"row {r:4d}: {v:.12e}")

    # IM column report
    print(f"\n=== COLUMN {COL_IM_1B} (Im) — rows 1..{STATE_ROWS_1B[1]} ===")
    if not rows_im:
        print("No entries found in this range.")
    else:
        nz_count_im = sum(abs(v) > NZ_EPS for v in vals_im)
        l1_im = sum(abs(v) for v in vals_im)
        print(f"Found {len(vals_im)} triplets (sparse). Nonzero (|v|>{NZ_EPS}): {nz_count_im}, L1-sum: {l1_im:.12e}")
        for r, v in zip(rows_im, vals_im):
            print(f"row {r:4d}: {v:.12e}")

    # DIAGNOSTICS / HINTS
    print("\n--- Diagnostics ---")
    if found_triplets_any_numeric == 0:
        print("• No numeric triplets were parsed. This file may not be a numeric sparse export. You may be opening the variable-to-index listing instead of the matrix.")
    if found_triplets_total == 0 and found_triplets_any_numeric > 0:
        print(f"• The file has numeric triplets, but none for rows 1..{STATE_ROWS_1B[1]} in columns {COL_RE_1B}/{COL_IM_1B}.")
        print("  Possible reasons: wrong column indices; matrix smaller than expected; or those columns are truly zero within state rows.")
    if rows_re or rows_im:
        print("• At least one of the requested columns has entries in the state-row window.")
    print("------------------------------------------------------------------")

if __name__ == "__main__":
    main()