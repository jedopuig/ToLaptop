# JacobianReader.py
# Self-contained: includes the .mtl reader + node-importance computation from Jxv.

import os
import re
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix, csr_matrix
import matplotlib.pyplot as plt


def read_powerfactory_mtl(file_path, shape=None, one_based_indexing=True, comment_pattern=r'^[#%!;]|^(Row\b|Col\b|Value\b)'):
    """
    Reads a DIgSILENT / PowerFactory sparse matrix exported to a text .mtl file into a SciPy sparse matrix.

    Expected file format (typical):
        <row> <col> <value>
        1     1      1.0
        1     542   -0.0034
        2     1      0.2398
        ...

    The function:
        - Skips headers and comment lines
        - Parses integer row/col and float value
        - Supports 1-based indexing (default for PF export) with optional switch
        - Infers shape if not provided
        - Returns CSR matrix for efficient algebra

    Parameters
    ----------
    file_path : str | Path
        Full path to the .mtl file.
    shape : tuple[int, int] | None
        Optional (n_rows, n_cols). If None, inferred as max(row, col).
    one_based_indexing : bool
        True if file rows/cols are 1-based (PowerFactory default). Set False if already 0-based.
    comment_pattern : str
        Regex marking comment/header lines to skip.

    Returns
    -------
    scipy.sparse.csr_matrix
        The loaded sparse matrix in CSR format with duplicates summed.
    """
    file_path = Path(file_path)

    rows = []
    cols = []
    data = []

    # Match a numeric triplet line: row col value (supports scientific notation)
    triplet = re.compile(
        r'^\s*([+-]?\d+)\s+([+-]?\d+)\s+([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s*$'
    )
    comment_re = re.compile(comment_pattern)

    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for raw in f:
            s = raw.strip()
            if not s:
                continue
            # skip comment/header-like lines
            if comment_re.search(s):
                continue

            m = triplet.match(s)
            if not m:
                # Fallback: lenient split
                parts = s.split()
                if len(parts) < 3:
                    continue
                r_str, c_str, v_str = parts[0], parts[1], parts[2]
                try:
                    r = int(r_str)
                    c = int(c_str)
                    v = float(v_str)
                except ValueError:
                    continue
            else:
                r = int(m.group(1))
                c = int(m.group(2))
                v = float(m.group(3))

            if one_based_indexing:
                r -= 1
                c -= 1

            rows.append(r)
            cols.append(c)
            data.append(v)

    if not rows:
        raise ValueError(f"No numeric triplets found in file: {file_path}")

    if shape is None:
        nrows = max(rows) + 1
        ncols = max(cols) + 1
        shape = (nrows, ncols)

    coo = coo_matrix((np.array(data, dtype=float), (np.array(rows), np.array(cols))), shape=shape)
    csr = coo.tocsr()
    csr.sum_duplicates()  # in case the file contains duplicate entries
    return csr


def compute_dynamic_node_importance(A: csr_matrix,
                                    n_states: int,
                                    v_start_col: int,
                                    v_end_col: int,
                                    pair_columns=True):
    """
    Compute node importance from the Jxv block of the full Jacobian A.

    Parameters
    ----------
    A : csr_matrix
        Full Jacobian (states + algebraic). Shape ~ (n_states + n_algebraic) square.
    n_states : int
        Number of dynamic state variables (rows to keep).
    v_start_col : int
        First column index (0-based) of the algebraic voltage block.
    v_end_col : int
        Last column index (0-based, EXCLUSIVE) of the algebraic voltage block.
    pair_columns : bool
        If True, assumes every 2 consecutive columns correspond to (Re, Im) of a single bus.
        Computes importance as sqrt(sum_i (J_re^2 + J_im^2)) across states.
        If False, returns per-column importance instead.

    Returns
    -------
    importance : np.ndarray
        If pair_columns=True: shape (n_buses,)
        If pair_columns=False: shape (n_voltage_columns,)
    """
    # Extract Jxv (rows: states, cols: algebraic voltage vars)
    Jxv = A[:n_states, v_start_col:v_end_col].tocsc()

    if not pair_columns:
        # Per algebraic variable (column) importance = column 2-norm over rows (states)
        # Efficient sparse column norms:
        # Convert to CSR, square entries, sum per column (via transpose trick)
        J = Jxv.tocsr()
        sq = J.multiply(J)  # element-wise square; still sparse
        # Sum per column: transpose to CSC and sum axis=0
        col_sums = np.array(sq.tocsc().sum(axis=0)).ravel()
        return np.sqrt(col_sums)

    # Pair columns: (Re, Im) per bus
    n_cols = Jxv.shape[1]
    if n_cols % 2 != 0:
        raise ValueError(f"Voltage columns count {n_cols} is not even; cannot pair (Re, Im) per bus.")

    n_buses = n_cols // 2
    importance = np.zeros(n_buses)

    # Efficient computation without dense conversion:
    # ||[J_re J_im]||_2 over rows equals sqrt(sum_i (J_re[i]^2 + J_im[i]^2))
    # For each bus, compute squared norms of both columns and add.
    # We'll compute per-column squared norms first, then add per pair.

    # Column-wise squared 2-norms for Jxv
    J_csr = Jxv.tocsr()
    J_sq = J_csr.multiply(J_csr)  # element-wise square
    col_sq_sums = np.array(J_sq.tocsc().sum(axis=0)).ravel()  # sum per column

    # Combine Re/Im pairs
    importance = np.sqrt(col_sq_sums[0::2] + col_sq_sums[1::2])
    return importance


def main():
    # ---- PATH TO YOUR JACOBIAN ----
    jac_path = Path(r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Node Importance\Jacobian Matrix\Jacobian.mtl")
    if not jac_path.exists():
        raise FileNotFoundError(f"File not found: {jac_path}")

    # ---- LOAD MATRIX ----
    A = read_powerfactory_mtl(jac_path, shape=None, one_based_indexing=True)
    print(f"Loaded Jacobian: shape={A.shape}, nnz={A.nnz}")

    # ---- PARAMETERS (ADAPT IF DIFFERENT) ----
    n_states = 2082
    # Columns for algebraic voltage variables (0-based):
    v_start_col = 2082      # inclusive
    v_end_col = 8568        # exclusive

    # Quick sanity checks
    if A.shape[0] != A.shape[1]:
        print("[WARN] Jacobian is not square. Are you sure this is the full J matrix?")
    if v_end_col > A.shape[1]:
        raise ValueError("v_end_col exceeds matrix width. Check your indices and exported matrix.")

    # ---- COMPUTE NODE IMPORTANCE (paired Re/Im) ----
    importance = compute_dynamic_node_importance(
        A, n_states=n_states, v_start_col=v_start_col, v_end_col=v_end_col, pair_columns=True
    )

    n_buses = importance.size
    print(f"Computed importance for {n_buses} buses.")

    # ---- REPORT TOP-K ----
    top_k = 10
    order = np.argsort(-importance)[:top_k]
    print("\nTop buses by dynamic importance (‖[J_re J_im]‖₂ over states):")
    for rank, idx in enumerate(order, start=1):
        print(f"{rank:2d}. Bus {idx:5d}  importance = {importance[idx]:.6e}")

    # ---- SAVE RESULTS ----
    out_dir = jac_path.parent
    np.save(out_dir / "node_importance.npy", importance)
    print(f"\nSaved importance array -> {out_dir / 'node_importance.npy'}")

    # Optional: also save the CSR matrix (fast reload)
    np.savez_compressed(out_dir / "Jacobian_csr.npz",
                        data=A.data, indices=A.indices, indptr=A.indptr, shape=A.shape)

    # ---- PLOT ----
    try:
        plt.figure(figsize=(12, 5))
        plt.plot(importance, lw=1)
        plt.title("Dynamic Node Importance from Jxv (‖[J_re J_im]‖₂ over states)")
        plt.xlabel("Bus index (0-based by export order)")
        plt.ylabel("Importance (2-norm)")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()
    except Exception as e:
        print(f"[WARN] Plotting failed: {e}")


if __name__ == "__main__":
    main()