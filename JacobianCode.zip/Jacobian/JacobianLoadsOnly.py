# Jacobian_NodeImportance_Both_Scaled.py
# Performs two rankings of voltage-terminal importance:
# (A) All terminals, using ALL 2082 state rows (Jxv)
# (B) LOAD-only, using only algebraic rows with "LOAD" in the name (indices >= 2083)
# For BOTH: plots Top-5 using x=1..2082 (state rows), Re=solid, Im=dashed, one color per bus.
# Legend includes full terminal names + exact 1-based Jacobian column indices, positioned at bottom-right.
# Y-axis is auto-scaled based on actual plotted values with a small margin.

import re
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------
# 0) Read .mtl -> CSR sparse matrix
# ---------------------------------------------------------------------
def read_powerfactory_mtl(file_path, shape=None, one_based_indexing=True):
    rows, cols, data = [], [], []
    triplet = re.compile(r'^\s*(\d+)\s+(\d+)\s+([-+eE0-9.]+)\s*$')

    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = triplet.match(line)
            if not m:
                continue
            r, c, v = int(m.group(1)), int(m.group(2)), float(m.group(3))
            if one_based_indexing:  # convert to 0-based for Python
                r -= 1; c -= 1
            rows.append(r); cols.append(c); data.append(v)

    if not rows:
        raise ValueError(f"No numeric triplets parsed from {file_path}")
    if shape is None:
        shape = (max(rows) + 1, max(cols) + 1)

    return coo_matrix((data, (rows, cols)), shape=shape).tocsr()


# ---------------------------------------------------------------------
# 1) Parse VariableToIdx_Jacobian.txt → {index_1b: {"path":..., "comp":ur/ui}}
# ---------------------------------------------------------------------
def load_variable_map(varfile_path):
    varmap = {}
    # Format: "<idx> <full path>  "ur"|"ui""
    pattern = re.compile(r'^(\d+)\s+(.*?)\s+"(ur|ui)"$')
    with open(varfile_path, "r", encoding="utf-8") as f:
        for line in f:
            s = line.strip()
            m = pattern.match(s)
            if not m:
                continue
            idx_1b = int(m.group(1))
            path = m.group(2)
            comp = m.group(3)
            varmap[idx_1b] = {"path": path, "comp": comp}
    if not varmap:
        raise ValueError(f"No variables parsed from {varfile_path}")
    return varmap


# ---------------------------------------------------------------------
# 2) Compute importance from ALL 2082 state rows (Jxv block)
#     I_k = sqrt( ||J[:, Re_k]||_2^2 + ||J[:, Im_k]||_2^2 )
# ---------------------------------------------------------------------
def compute_importance_states(A, n_states, v_start_1b, v_end_1b):
    v_start_0b = v_start_1b - 1
    v_end_0b   = v_end_1b       # exclusive
    # Jxv: rows = 0..n_states-1, cols = [v_start_0b:v_end_0b]
    Jxv = A[:n_states, v_start_0b:v_end_0b].tocsc()
    n_cols = Jxv.shape[1]
    if n_cols % 2 != 0:
        raise ValueError("Voltage columns count must be even (Re/Im pairing).")
    # Column-wise squared 2-norms efficiently
    J_sq = Jxv.multiply(Jxv)
    col_sq = np.array(J_sq.sum(axis=0)).ravel()
    # Pair (Re, Im)
    importance = np.sqrt(col_sq[0::2] + col_sq[1::2])
    return importance


# ---------------------------------------------------------------------
# 3) Compute importance using ONLY selected row indices (e.g., LOAD rows)
# ---------------------------------------------------------------------
def compute_importance_on_rows(A, row_indices_0b, v_start_1b, v_end_1b):
    v_start_0b = v_start_1b - 1
    v_end_0b   = v_end_1b       # exclusive

    J = A[row_indices_0b, v_start_0b:v_end_0b].tocsc()
    n_cols = J.shape[1]
    if n_cols % 2 != 0:
        raise ValueError("Voltage columns count must be even (Re/Im pairing).")

    J_sq = J.multiply(J)
    col_sq = np.array(J_sq.sum(axis=0)).ravel()
    importance = np.sqrt(col_sq[0::2] + col_sq[1::2])
    return importance


# ---------------------------------------------------------------------
# 4) Extract 0-based row indices where name contains "LOAD" and idx ≥ v_start_1b
# ---------------------------------------------------------------------
def extract_load_rows(varmap, v_start_1b):
    rows_0b = []
    for idx_1b, meta in varmap.items():
        if idx_1b >= v_start_1b and "LOAD" in meta["path"].upper():
            rows_0b.append(idx_1b - 1)
    rows_0b.sort()
    return rows_0b


# ---------------------------------------------------------------------
# 5) Helpers to map bus index → total columns and names
#    bus_0b = 0..(n_buses-1), total 1-based indices for Re/Im:
#    col_re_1b = v_start_1b + 2*bus_0b, col_im_1b = col_re_1b + 1
# ---------------------------------------------------------------------
def columns_for_bus_1b(bus_0b, v_start_1b=2083):
    col_re_1b = v_start_1b + 2*bus_0b
    col_im_1b = col_re_1b + 1
    return col_re_1b, col_im_1b


# ---------------------------------------------------------------------
# 6) Plot helper (x=1..N_STATES, Re=solid, Im=dashed, full names in legend)
#     • Auto-scales y-limits to the min/max of all plotted series with a 5% margin
#     • Legend placed at bottom-right (lower right)
# ---------------------------------------------------------------------
def plot_top5_vs_states(A, varmap, top5_bus_0b, fig_title, out_png_path,
                        n_states, v_start_1b):

    x_states = np.arange(1, n_states + 1)  # 1..2082
    plt.figure(figsize=(14, 6))
    palette = plt.get_cmap('tab10')(np.arange(10))  # distinct colors

    yvals = []  # collect all plotted Y data

    for i, bus_0b in enumerate(top5_bus_0b):
        color = palette[i % 10]

        col_re_1b = v_start_1b + 2 * bus_0b
        col_im_1b = col_re_1b + 1
        col_re_0b = col_re_1b - 1
        col_im_0b = col_im_1b - 1

        vals_re = A[:n_states, col_re_0b].toarray().ravel()
        vals_im = A[:n_states, col_im_0b].toarray().ravel()

        yvals.extend(vals_re.tolist())
        yvals.extend(vals_im.tolist())

        name_re = varmap.get(col_re_1b, {"path": "(unknown)"})["path"]
        name_im = varmap.get(col_im_1b, {"path": "(unknown)"})["path"]

        plt.plot(x_states, vals_re, color=color, lw=1.6,
                 label=f"[{col_re_1b}] {name_re} (Re)")
        plt.plot(x_states, vals_im, color=color, lw=1.6, ls='--',
                 label=f"[{col_im_1b}] {name_im} (Im)")

    # -------------------------
    # FIXED, SENSIBLE AUTO-SCALING
    # -------------------------
    yvals = np.array(yvals)
    maxabs = np.max(np.abs(yvals))

    if maxabs == 0:
        # Force reasonable y-range
        plt.ylim(-1e-6, 1e-6)
    else:
        ymin = float(np.min(yvals))
        ymax = float(np.max(yvals))
        span = ymax - ymin

        # Avoid collapsed scale
        if span < maxabs * 0.02:  # less than ±1%
            margin = maxabs * 0.02
            plt.ylim(-margin, margin)
        else:
            # standard margins
            plt.ylim(ymin - 0.05 * span, ymax + 0.05 * span)

    plt.title(fig_title)
    plt.xlabel("State variable index (1..2082)")
    plt.ylabel("Jacobian entry ∂f/∂v")
    plt.grid(True, alpha=0.3)

    plt.legend(loc='lower right', fontsize=8, ncol=1, framealpha=0.95)
    plt.tight_layout()
    plt.savefig(out_png_path, dpi=180)
    print(f"Saved figure: {out_png_path}")


# ---------------------------------------------------------------------
# 7) MAIN
# ---------------------------------------------------------------------
def main():
    # --- Paths ---
    jac_path = Path(r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Node Importance\Jacobian Matrix\Jacobian.mtl")
    varfile  = Path(r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Node Importance\Jacobian Matrix\VariableToIdx_Jacobian.txt")

    # --- Known dimensions/regions ---
    N_STATES   = 2082            # rows 1..2082 (0..2081)
    V_START_1B = 2083            # first voltage column in total Jacobian (1-based)
    V_END_1B   = 8568            # last voltage column (1-based, inclusive) → exclusive in slicing

    # --- Load data ---
    A = read_powerfactory_mtl(jac_path)
    print(f"Loaded Jacobian: shape={A.shape}, nnz={A.nnz}")
    varmap = load_variable_map(varfile)
    print(f"Parsed {len(varmap)} variable mappings.")

    if V_END_1B > A.shape[1]:
        raise ValueError("V_END_1B exceeds Jacobian width. Check indices / export.")

    # ============================================================
    # (A) ALL-STATE RANKING (Jxv using rows 1..2082)
    # ============================================================
    importance_all = compute_importance_states(A, N_STATES, V_START_1B, V_END_1B)
    order_all = np.argsort(-importance_all)

    print("\nTop 10 terminals (ALL states) with real 1-based Jacobian column numbers:")
    for rank, bus_0b in enumerate(order_all[:10], start=1):
        col_re_1b, col_im_1b = columns_for_bus_1b(bus_0b, v_start_1b=V_START_1B)
        name_re = varmap.get(col_re_1b, {"path": "(unknown)", "comp": "ur"})["path"]
        name_im = varmap.get(col_im_1b, {"path": "(unknown)", "comp": "ui"})["path"]
        imp     = importance_all[bus_0b]
        print(f"{rank:2d}. imp={imp:.6e}")
        print(f"    Re [{col_re_1b}]: {name_re}")
        print(f"    Im [{col_im_1b}]: {name_im}")

    # Plot Top-5 for ALL-state ranking (auto-scaled, legend bottom-right)
    out_png_all = jac_path.parent / "Top5_IMPORTANCE_AllStates_FULLNAMES_SCALED.png"
    plot_top5_vs_states(
        A, varmap, order_all[:5],
        fig_title="Top-5 terminals by dynamic importance (ALL states)\nReal=solid, Imag=dashed; one color per terminal",
        out_png_path=out_png_all,
        n_states=N_STATES, v_start_1b=V_START_1B
    )

    # ============================================================
    # (B) LOAD-ONLY RANKING (rows from varfile containing 'LOAD' & idx>=2083)
    # ============================================================
    load_rows_0b = extract_load_rows(varmap, v_start_1b=V_START_1B)
    print(f"\nFound {len(load_rows_0b)} LOAD-related algebraic rows.")

    if len(load_rows_0b) == 0:
        print("No LOAD rows found; skipping LOAD-only ranking.")
        return

    importance_load = compute_importance_on_rows(A, load_rows_0b, V_START_1B, V_END_1B)
    order_load = np.argsort(-importance_load)

    print("\nTop 10 terminals by LOAD-only ranking with real 1-based Jacobian column numbers:")
    for rank, bus_0b in enumerate(order_load[:10], start=1):
        col_re_1b, col_im_1b = columns_for_bus_1b(bus_0b, v_start_1b=V_START_1B)
        name_re = varmap.get(col_re_1b, {"path": "(unknown)", "comp": "ur"})["path"]
        name_im = varmap.get(col_im_1b, {"path": "(unknown)", "comp": "ui"})["path"]
        imp     = importance_load[bus_0b]
        print(f"{rank:2d}. imp={imp:.6e}")
        print(f"    Re [{col_re_1b}]: {name_re}")
        print(f"    Im [{col_im_1b}]: {name_im}")

    # Plot Top-5 for LOAD-only ranking (auto-scaled, legend bottom-right)
    out_png_load = jac_path.parent / "Top5_IMPORTANCE_LoadRows_FULLNAMES_SCALED.png"
    plot_top5_vs_states(
        A, varmap, order_load[:5],
        fig_title="Top-5 terminals by importance (LOAD-only rows used for ranking)\nPlotted vs ALL states; Real=solid, Imag=dashed",
        out_png_path=out_png_load,
        n_states=N_STATES, v_start_1b=V_START_1B
    )

    # Save arrays for later use
    np.save(jac_path.parent / "importance_allstates.npy", importance_all)
    np.save(jac_path.parent / "importance_loadrows.npy", importance_load)
    print("\nSaved importance vectors: 'importance_allstates.npy' and 'importance_loadrows.npy'")


if __name__ == "__main__":
    main()