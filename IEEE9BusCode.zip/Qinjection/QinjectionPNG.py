
import io
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

# ========= INPUT =========
DATA = """BusIndex\tBus 4_U\tBus 5_U\tBus 6_U\tBus 7_U\tBus 8_U\tBus 9_U
4\t1\t0.771142177\t0.752162016\t0.216037975\t0.215487439\t0.199417843
5\t0.375652281\t1\t0.297230112\t0.248562436\t0.198153278\t0.113192403
6\t0.357599113\t0.290684598\t1\t0.11474217\t0.166926217\t0.228815272
7\t0.224684914\t0.52959157\t0.251527605\t1\t0.71426918\t0.262217367
8\t0.135394716\t0.256462141\t0.220301589\t0.432537178\t1\t0.343886734
9\t0.215777178\t0.25468019\t0.519059667\t0.273923934\t0.592467018\t1
"""

# If reading from CSV instead:
# df = pd.read_csv("your_table.csv").set_index("BusIndex").astype(float)
df = pd.read_csv(io.StringIO(DATA), sep=r"\s*\t\s*", engine="python").set_index("BusIndex").astype(float)

# ========= COLOR MAP (white -> blue) =========
TARGET_BLUE = "#1f53a7"  # adjust to your exact tone if needed
cmap = LinearSegmentedColormap.from_list("white_to_blue", ["#ffffff", TARGET_BLUE], N=256)

# ========= MASK DIAGONAL (keep white) =========
vals = df.values
n = vals.shape[0]
mask = np.eye(n, dtype=bool)
masked_vals = np.ma.array(vals, mask=mask)

# ========= PLOT (rectangular cells) =========
# Wider than tall to reduce individual cell height
fig, ax = plt.subplots(figsize=(9, 4))  # increase width or decrease height to make cells shorter

# Use aspect='auto' so image stretches with the axes (rectangular cells)
im = ax.imshow(masked_vals, cmap=cmap, vmin=0.0, vmax=1.0, aspect="auto")

# Ticks & labels
ax.set_xticks(np.arange(df.shape[1]))
ax.set_yticks(np.arange(df.shape[0]))
ax.set_xticklabels(df.columns, rotation=45, ha="right")
ax.set_yticklabels(df.index.astype(str))

# Grid lines for table look
ax.set_xticks(np.arange(df.shape[1]+1)-0.5, minor=True)
ax.set_yticks(np.arange(df.shape[0]+1)-0.5, minor=True)
ax.grid(which="minor", color="black", linewidth=1)
ax.tick_params(which="minor", bottom=False, left=False)

# Remove outer spines
for sp in ax.spines.values():
    sp.set_visible(False)

# Annotations
for i in range(n):
    for j in range(df.shape[1]):
        ax.text(j, i, ("1" if i == j else f"{vals[i, j]:.6f}"),
                ha="center", va="center", color="black")

# Colorbar legend
cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
cbar.set_label("Off‑diagonal value (0 → 1)")

plt.tight_layout()

# ========= SAVE =========
OUTFILE = r"C:\Users\308892\OneDrive - TenneT TSO B.V\Desktop\table_heatmap.png"   # change path/filename if needed
plt.savefig(OUTFILE, dpi=300, bbox_inches="tight")
print(f"Saved: {OUTFILE}")

