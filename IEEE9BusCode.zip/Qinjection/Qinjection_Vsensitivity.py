import sys  # import sys module in order to call sys.path.append()

sys.path.append(
    "C:\\Program Files\\DIgSILENT\\PowerFactory 2025\\Python\\3.12")  # adding path to the PowerFactory - module
import powerfactory  # importing the pf-module

app = powerfactory.GetApplication()  # calling app Application object
import pandas as pd  # it is recommended to use pandas

O = app.GetActiveProject()  # getting the active project only to check if there is a project active
if not O:
    app.PrintError('No project active !!!')
    sys.exit()
app.ResetCalculation()  # start always from the same PowerFactory state
app.ClearOutputWindow()  # clear Output Window (OPTIONAL)

# Set up load flow command for all simulations ]#(put everything to zero for task 5,6,7,8)
ldf = app.GetFromStudyCase('ComLdf')  # getting the load flow command
ldf.iopt_net = 0  # choose balanced load flow with 0
ldf.iopt_pq = 1  # 1 task 8 ## don't take voltage dependency of loads into account with 0
ldf.iopt_at = 0  # disable automatic tap adjustment of transformers with 0
ldf.iopt_asht = 0  # disable automatic shunt adjustment with 0
ldf.iopt_lim = 1  # 1 task 8 ## don't consider Reactive Power limits with 0
ldf.iopt_apdist = 0  # Active Power Control: 0 - "as Dispatched"
ldf.iopt_plim = 1  # 1 task 8 ##  don't consider active power limits with 0

# Get all loads and all buses
loads = app.GetCalcRelevantObjects('*.ElmLod')  # get all '*.ElmLod' objects
orig_buses = app.GetCalcRelevantObjects('*.ElmTerm', 0, 1)  # get all '*.ElmTerm' objects

# filter out all non-busbars (iUsage is 0): if all buses are modeled as Busbar elements (i.e. not as e.g. Single Busbar System), the line is superfluous
buses = []
for bus in orig_buses:
    if bus.iUsage == 0:
        buses.append(bus)

# A quicker way of doing this is commented out below. Uncomment this and comment previous lines to see if it works the same
# buses = [bus for bus in orig_buses if bus.iUsage == 0]  # filter out all non-busbars (iUsage is 0): if all buses are modeled as
# Busbar elements (i.e. not as e.g. Single Busbar System), the line is superfluous

# Set the load powers of all loads to the nominal value (Step 1)

for load in loads:
    load.scale0 = 1

with open('pv_data_3.csv', 'w') as f:
    f.write('')  # This clears the file if it already exists

header = []

for bus in buses:
    header.append(bus.GetAttribute('loc_name'))
header.append("Total Load Power")
data = pd.DataFrame(columns=header)

flag = ldf.Execute()
while not flag:
    voltages = []
    total_load_power = [0]
    for bus in buses:
        voltages.append(bus.GetAttribute('m:u'))
        total_load_power[0] = total_load_power[0] + bus.GetAttribute('m:Pload')

    new_row = pd.Series(voltages + total_load_power, index=data.columns)
    data = pd.concat([data, pd.DataFrame([new_row])], ignore_index=True)
    for load in loads:
        load.scale0 = load.GetAttribute('scale0') + 0.001
    flag = ldf.Execute()

    # Format numerical values for CSV output
data = data.applymap(lambda x: f"{x:.6f}" if isinstance(x, float) else x)

# Save DataFrame to CSV file
data.to_csv('pv_data_3.csv', sep=';', index=False)

# Reset the model back to its original state
for load in loads:
    load.scale0 = 1  # Reconfirm all loads set back to nominal, if needed

app.ResetCalculation()  # Reset PowerFactory model state
app.PrintPlain("Simulation complete. CSV file saved and model reset.")