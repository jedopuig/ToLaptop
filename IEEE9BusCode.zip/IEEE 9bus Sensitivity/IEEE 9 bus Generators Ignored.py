import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# 1. System base values
# ============================================================
S_base = 100e6
V_base = 230e3
Z_base = V_base**2 / S_base

# ============================================================
# 2. Transformers (convert to pu on system base)
# ============================================================
transformers = [
    (2, 7, 0.125, 200e6),
    (1, 4, 0.144, 250e6),
    (3, 9, 0.0879,150e6)
]

Zxf = {}
for fb, tb, x_old, S_old in transformers:
    x_new = x_old * (S_base / S_old)
    Zxf[(fb, tb)] = 1j * x_new
    Zxf[(tb, fb)] = 1j * x_new

# ============================================================
# 3. Transmission lines (convert ohm → pu)
# ============================================================
lines = [
    (4,5, 5.29,   44.965),
    (4,6, 8.993,  48.668),
    (5,7, 16.928, 85.169),
    (7,8, 4.4965, 38.088),
    (8,9, 6.2951, 53.3232),
    (6,9, 20.631, 89.93)
]

Zline = {}
for fb, tb, R, X in lines:
    Zline[(fb, tb)] = (R + 1j*X) / Z_base
    Zline[(tb, fb)] = Zline[(fb, tb)]

# ============================================================
# 4. Full Ybus (9×9)
# ============================================================
n = 9
Ybus = np.zeros((n, n), dtype=complex)

# Transformer contributions
for (fb, tb), Z in Zxf.items():
    y = 1/Z
    Ybus[fb-1, tb-1] -= y
    Ybus[tb-1, fb-1] -= y
    Ybus[fb-1, fb-1] += y
    Ybus[tb-1, tb-1] += y

# Line contributions
for (fb, tb), Z in Zline.items():
    y = 1/Z
    Ybus[fb-1, tb-1] -= y
    Ybus[tb-1, fb-1] -= y
    Ybus[fb-1, fb-1] += y
    Ybus[tb-1, tb-1] += y

print("\n=== FULL 9x9 Ybus ===\n")
print(Ybus)

# ============================================================
# 5. Remove buses 1 (slack), 2, and 3
# ============================================================
# buses to keep = 4,5,6,7,8,9 → zero‑indexed = 3,4,5,6,7,8
keep = [3,4,5,6,7,8]

Yred = Ybus[np.ix_(keep, keep)]

print("\n=== REDUCED Ybus (buses 1,2,3 removed) ===\n")
print(Yred)

print("\nDeterminant of reduced Ybus:")
print(np.linalg.det(Yred))

# ============================================================
# 6. Adjacency matrices
# ============================================================
A = -Yred.copy()
np.fill_diagonal(A, 0)

A_abs = np.abs(A)
np.fill_diagonal(A_abs, 0)

print("\n=== Complex adjacency A ===\n")
print(A)

print("\n=== Magnitude adjacency |A| ===\n")
print(A_abs)

# ============================================================
# 7. Eigenvalues and eigenvectors
# ============================================================
eigvals_A, eigvecs_A = np.linalg.eig(A)
eigvals_Aabs, eigvecs_Aabs = np.linalg.eig(A_abs)

idx_A = np.argmax(np.abs(eigvals_A))
idx_Aabs = np.argmax(np.abs(eigvals_Aabs))

print("\n=== Dominant Eigenpair of A ===")
print("Eigenvalue:", eigvals_A[idx_A])
print("Eigenvector:\n", eigvecs_A[:, idx_A])

print("\n=== Dominant Eigenpair of |A| ===")
print("Eigenvalue:", eigvals_Aabs[idx_Aabs])
print("Eigenvector:\n", eigvecs_Aabs[:, idx_Aabs])

# ============================================================
# 8. Polar plots for eigenvalues
# ============================================================
fig = plt.figure(figsize=(14, 6))

# --- eigenvalues of complex A ---
ax1 = fig.add_subplot(121, polar=True)
ax1.set_title("Eigenvalues of Complex Adjacency A")

angles_A = np.angle(eigvals_A)
radius_A = np.abs(eigvals_A)

ax1.scatter(angles_A, radius_A, s=70, c='dodgerblue')
for i in range(len(eigvals_A)):
    ax1.annotate(str(keep[i]+1), (angles_A[i], radius_A[i]))

# --- eigenvalues of magnitude adjacency ---
ax2 = fig.add_subplot(122, polar=True)
ax2.set_title("Eigenvalues of |A| (Magnitude Adjacency)")

angles_Aabs = np.angle(eigvals_Aabs)
radius_Aabs = np.abs(eigvals_Aabs)

ax2.scatter(angles_Aabs, radius_Aabs, s=70, c='darkorange')
for i in range(len(eigvals_Aabs)):
    ax2.annotate(str(keep[i]+1), (angles_Aabs[i], radius_Aabs[i]))

plt.show()