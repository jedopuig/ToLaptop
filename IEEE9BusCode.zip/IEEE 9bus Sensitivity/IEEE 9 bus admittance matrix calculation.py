import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# ============================================================
# 1. System base values
# ============================================================
S_base = 100e6
V_base = 230e3
Z_base = V_base ** 2 / S_base

# ============================================================
# 2. Transformers
# ============================================================
transformers = [
    (2, 7, 0.125, 200e6),
    (1, 4, 0.144, 250e6),
    (3, 9, 0.0879, 150e6)
]

Zxf = {}
for fb, tb, x_old, S_old in transformers:
    x_new = x_old * (S_base / S_old)
    Zxf[(fb, tb)] = 1j * x_new
    Zxf[(tb, fb)] = 1j * x_new

# ============================================================
# 3. Transmission lines
# ============================================================
lines = [
    (4, 5, 5.29, 44.965),
    (4, 6, 8.993, 48.668),
    (5, 7, 16.928, 85.169),
    (7, 8, 4.4965, 38.088),
    (8, 9, 6.2951, 53.3232),
    (6, 9, 20.631, 89.93)
]

Zline = {}
for fb, tb, R, X in lines:
    Z_pu = (R + 1j * X) / Z_base
    Zline[(fb, tb)] = Z_pu
    Zline[(tb, fb)] = Z_pu

# ============================================================
# 4. Build Ybus
# ============================================================
n = 9
Ybus = np.zeros((n, n), dtype=complex)

for (fb, tb), Z in Zxf.items():
    y = 1 / Z
    Ybus[fb - 1, tb - 1] -= y
    Ybus[tb - 1, fb - 1] -= y
    Ybus[fb - 1, fb - 1] += y
    Ybus[tb - 1, tb - 1] += y

for (fb, tb), Z in Zline.items():
    y = 1 / Z
    Ybus[fb - 1, tb - 1] -= y
    Ybus[tb - 1, fb - 1] -= y
    Ybus[fb - 1, fb - 1] += y
    Ybus[tb - 1, tb - 1] += y

# ============================================================
# 5. Remove slack bus (Bus 1)
# ============================================================
slack_bus = 1
bus_map = [i for i in range(1, n + 1) if i != slack_bus]

Yred = np.delete(Ybus, slack_bus - 1, axis=0)
Yred = np.delete(Yred, slack_bus - 1, axis=1)

# ============================================================
# 6. Compute Zbus
# ============================================================
if np.linalg.cond(Yred) > 1e12:
    print("Warning: Yred is ill-conditioned")
    Zbus = None
else:
    Zbus = np.linalg.inv(Yred)


# ============================================================
# 7. Plot function for complex values with Euclidean norm only
# ============================================================
def plot_matrix_with_norm(matrix, bus_map, title):
    n = len(bus_map)
    matrix_display = matrix.copy()

    # Off-diagonal for metrics
    matrix_no_diag = matrix.copy()
    np.fill_diagonal(matrix_no_diag, 0)

    # Euclidean norm (off-diagonal)
    euclidean_norms = np.sqrt(np.sum(np.abs(matrix_no_diag) ** 2, axis=1))

    # Create extended matrix with Euclidean norm as extra column
    extended_matrix = np.hstack([matrix_display, euclidean_norms.reshape(-1, 1)])
    col_labels = [f"Bus {b}" for b in bus_map] + ["Euclid"]

    # Plot
    fig, ax = plt.subplots(figsize=(12, 6))
    im = ax.imshow(np.abs(extended_matrix), cmap='viridis', aspect='auto')

    # Annotate cells with complex values
    for i in range(n):
        for j in range(extended_matrix.shape[1]):
            val = extended_matrix[i, j]
            if j < n:  # matrix values
                text = f"{val.real:.2f}+{val.imag:.2f}j"
            else:  # Euclidean norm
                text = f"{val:.2f}"
            ax.text(j, i, text, ha="center", va="center", color="w", fontsize=8)

    ax.set_xticks(np.arange(extended_matrix.shape[1]))
    ax.set_yticks(np.arange(n))
    ax.set_xticklabels(col_labels, rotation=45)
    ax.set_yticklabels([f"Bus {b}" for b in bus_map])
    ax.set_title(title)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout()
    plt.show()


# ============================================================
# 8. Plot Ybus (complex values + Euclidean norm only)
# ============================================================
plot_matrix_with_norm(Yred, bus_map, "Ybus Complex Values + Euclidean Norm")

# ============================================================
# 9. Plot Zbus (complex values + Euclidean norm only)
# ============================================================
plot_matrix_with_norm(Zbus, bus_map, "Zbus Complex Values + Euclidean Norm")


# ============================================================
# 10. Build Ybus adjacency matrix
# ============================================================

# Start from Yred (after slack bus removed)
A = -Yred.copy()          # change sign of off-diagonal
np.fill_diagonal(A, 0)   # zero out diagonals

# ============================================================
# Remove isolated nodes: Bus 2 and Bus 3
# ============================================================
# Note: bus_map corresponds to Yred rows/columns
# bus_map = [2,3,4,5,6,7,8,9]  after removing slack bus 1
# So to remove Bus 2 and 3, remove rows/cols at index 0 and 1
remove_indices = [0, 1]  # Bus 2 and 3 in bus_map
A_reduced = np.delete(A, remove_indices, axis=0)
A_reduced = np.delete(A_reduced, remove_indices, axis=1)

# Remaining buses for labels
remaining_buses = [b for i, b in enumerate(bus_map) if i not in remove_indices]

# ============================================================
# Plot adjacency matrix
# ============================================================
fig, ax = plt.subplots(figsize=(8,6))
im = ax.imshow(np.abs(A_reduced), cmap='viridis', aspect='auto')

# Annotate with complex values
n = len(remaining_buses)
for i in range(n):
    for j in range(n):
        val = A_reduced[i, j]
        text = f"{val.real:.2f}+{val.imag:.2f}j"
        ax.text(j, i, text, ha="center", va="center", color="w", fontsize=8)

# Bus labels
ax.set_xticks(range(n))
ax.set_yticks(range(n))
ax.set_xticklabels([f"Bus {b}" for b in remaining_buses], rotation=45)
ax.set_yticklabels([f"Bus {b}" for b in remaining_buses])

ax.set_title("Ybus-based Adjacency Matrix (Diagonals=0, Sign Changed, Buses 2&3 Removed)")
plt.colorbar(im, ax=ax)
plt.tight_layout()
plt.show()