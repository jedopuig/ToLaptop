import os
import pandas as pd
import numpy as np

folder = r"C:\Users\308892\OneDrive - TenneT TSO B.V\Documents\Aggregated Load\Node Importance\Zbus Matrix\IEEE 9bus Sensitivity"

files = [
    "Bus4_x10P.csv",
    "Bus5_x10P.csv",
    "Bus6_x10P.csv",
    "Bus7_x10P.csv",
    "Bus8_x10P.csv",
    "Bus9_x10P.csv"
]

results = []

for filename in files:
    path = os.path.join(folder, filename)

    # Check if file exists
    if not os.path.exists(path):
        print(f"File not found: {path}")
        continue

    print(f"Processing: {filename}")

    # Try reading CSV (handles EU decimal commas)
    try:
        df = pd.read_csv(path, decimal=',')
    except Exception as e:
        print(f"Error reading {filename}: {e}")
        continue

    # Identify time column (assumes first column)
    time_col = df.columns[0]

    # Convert ALL columns to numeric (robust)
    df = df.apply(pd.to_numeric, errors='coerce')

    # Drop rows where time is invalid
    df = df.dropna(subset=[time_col])

    if df.empty:
        print(f"No valid data in {filename}")
        continue

    # Filter time range
    df_sub = df[(df[time_col] >= 2.2) & (df[time_col] <= 20)].copy()

    if df_sub.empty:
        print(f"No data in time range for {filename}")
        continue

    # Extract time values
    time_values = df_sub[time_col].to_numpy()

    # Ensure time is strictly increasing (important for gradient)
    if np.any(np.diff(time_values) == 0):
        print(f"Duplicate time values in {filename}, skipping")
        continue

    derivatives = {}

    # Compute derivatives correctly with respect to time
    for col in df_sub.columns[1:]:
        values = df_sub[col].to_numpy()

        # Skip columns with all NaNs
        if np.all(np.isnan(values)):
            continue

        dcol = np.gradient(values, time_values)

        # Use nanmean to ignore NaNs safely
        derivatives[col] = np.nanmean(dcol)

    # Extract bus name
    disturbance_bus = filename.split("_")[0]

    entry = {"Disturbance Bus": disturbance_bus}
    entry.update(derivatives)

    results.append(entry)

# Create final DataFrame
output_df = pd.DataFrame(results)

print("\nFinal Results:")
print(output_df)

# Optional: save to CSV
output_path = os.path.join(folder, "summary_derivatives.csv")
output_df.to_csv(output_path, index=False)

print(f"\nResults saved to: {output_path}")