import numpy as np
import matplotlib.pyplot as plt

# -------------------------------------------------------------
# 1. Impedance matrix Z
# -------------------------------------------------------------
Z = np.array([
    [0.0029+0.0948j, 0.0014+0.0137j, 0.0003+0.0108j, -0.5955+0.8336j, -0.4961+0.5887j, -0.4637+0.6482j, -0.1958+0.2792j, -0.1963+0.2727j, -0.1765+0.2896j],
    [0.0014+0.0137j, 0.0097+0.1659j, 0.0022+0.0194j, 0.1914+0.4245j, 0.2895+0.7571j, 0.2124+0.4794j, 0.5962+1.4138j, 0.4024+1.0619j, 0.2427+0.5601j],
    [0.0003+0.0108j, 0.0022+0.0194j, 0.0033+0.0983j, -0.1905+0.3126j, -0.2363+0.3174j, -0.3693+0.5667j, -0.2828+0.3910j, -0.4761+0.6209j, -0.7009+1.0047j],
    [-0.5955+0.8336j, 0.1914+0.4245j, -0.1905+0.3126j, 3.3452+34.4781j, 4.5727+25.6260j, 2.6192+26.8191j, 1.0137+11.4850j, 1.1381+11.3022j, 0.2717+11.4617j],
    [-0.4961+0.5887j, 0.2895+0.7571j, -0.2363+0.3174j, 4.5727+25.6260j, 11.5517+51.0618j, 3.7317+21.2633j, 2.9252+19.8546j, 2.9215+16.4094j, 1.4399+12.3096j],
    [-0.4637+0.6482j, 0.2124+0.4794j, -0.3693+0.5667j, 2.6192+26.8191j, 3.7317+21.2633j, 8.7984+57.2761j, 1.2243+12.9245j, 1.8061+16.1012j, 1.1431+21.1578j],
    [-0.1958+0.2792j, 0.5962+1.4138j, -0.2828+0.3910j, 1.0137+11.4850j, 2.9252+19.8546j, 1.2243+12.9245j, 4.2614+37.7491j, 4.1817+27.8042j, 1.5477+15.0342j],
    [-0.1963+0.2727j, 0.4024+1.0619j, -0.4761+0.6209j, 1.1381+11.3022j, 2.9215+16.4094j, 1.8061+16.1012j, 4.1817+27.8042j, 8.1836+47.6974j, 3.1917+24.2982j],
    [-0.1765+0.2896j, 0.2427+0.5601j, -0.7009+1.0047j, 0.2717+11.4617j, 1.4399+12.3096j, 1.1431+21.1578j, 1.5477+15.0342j, 3.1917+24.2982j, 3.2764+38.2313j]
], dtype=complex)

# -------------------------------------------------------------
# 2. Compute row metrics (Euclidean & geometric norms)
# -------------------------------------------------------------
n = Z.shape[0]
Z_abs = np.abs(Z)

# Zero diagonal for metrics
Z_no_diag = Z_abs.copy()
np.fill_diagonal(Z_no_diag, 0)

# Euclidean norms (row-wise)
euclidean_norms = np.sqrt(np.sum(Z_no_diag**2, axis=1))

# Geometric mean (row-wise, excluding diagonal)
geom_means = np.prod(Z_no_diag, axis=1)**(1/(n-1))

# -------------------------------------------------------------
# 3. Build extended matrix for plotting
# -------------------------------------------------------------
extended_matrix = np.hstack([Z_no_diag, euclidean_norms.reshape(-1,1), geom_means.reshape(-1,1)])

# Column labels
col_labels = [f"Bus {i+1}" for i in range(n)] + ["Euclid", "GeomMean"]
row_labels = [f"Bus {i+1}" for i in range(n)]

# -------------------------------------------------------------
# 4. Plot heatmap
# -------------------------------------------------------------
fig, ax = plt.subplots(figsize=(12, 6))
im = ax.imshow(extended_matrix, cmap='viridis', aspect='auto')

# Annotate cells
for i in range(n):
    for j in range(n+2):
        text = f"{extended_matrix[i,j]:.2f}"
        ax.text(j, i, text, ha="center", va="center", color="w", fontsize=8)

ax.set_xticks(np.arange(n+2))
ax.set_yticks(np.arange(n))
ax.set_xticklabels(col_labels, rotation=45)
ax.set_yticklabels(row_labels)

ax.set_title("Zbus Absolute Values + Row Metrics")
plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
plt.tight_layout()
plt.show()